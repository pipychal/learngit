#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP

#for looper in {1,2,3,4,5,6,7,8,9}:
#    print(looper ,"times 8=",looper * 2)

import time
for i in range(1,50,2):
    print (i)
    time.sleep(2)