#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
import random
secret = random.randint(0,99)
guess = 0
tries = 0
#print("LLLLLLL")
while guess != secret and tries < 10:
    guess = input("What's your guess?,zhou yi hao.please input your number:")
    if guess < secret:
        print("Sorry,It is too low.come on")
    elif guess > secret:
        print("Sorry,It is too high,try again please:")
    tries = tries + 1

if guess == secret:
    print("Well done.You got it.Congratulations")
else:
    print("No more guess")