#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
'''
count = 5
count += 1
print(count)
a = 28.22
c = 28
b = int(c)
d = float(c)
print(d)
f = "hello world"
print(type(f))
print(type(c))
print(type(a))
'''
