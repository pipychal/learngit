#!/usr/bin/python
# -*- coding:utf-8 -*-
# 有一个3G 大小的文件；文件的每行一个 string ， 内容为酒店的 id 和一个图片的名字，使用“\t”分割
# 事例： ht_1023134 + '\t' + hisahdjkd3e323435243.jpg
#     表示的是一个酒店包含的一张图片，统计含有图片数量为 [20,无穷大] 的酒店 id ， 含有图片数量为 [10,20]的酒店id,
#     含有图片数量为 [5,10] 的酒店id ， 图片数量为 [0,5] 的酒店id, 并将结果输出到文件中。
# 文件格式为：
#   0-5 + "\t" + id1 + "\t" + id2 + ...
#   0-10 + "\t" + id1 + "\t" + id2 + ...
#   10-20 + "\t" + id1 + "\t" + id2 + ...
#   20-无穷大 + "\t" + id1 + "\t" + id2 + ...



import random
import datetime
import string
import multiprocessing
import os


def mkdir(path):
    # 引入模块
    # 去除首位空格
    path = path.strip()
    # 去除尾部 \ 符号
    path = path.rstrip("\\")
    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists = os.path.exists(path)
    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path)

        print path + ' 创建成功'
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print path + ' 目录已存在'
        return False

#10进制转换36进制(已经修改成全部数字的形式)
def hex36(num):
    # 正常36进制字符应为'0123456789abcdefghijklmnopqrstuvwxyz'，这里我打乱了顺序
    # key='t5hrwop6ksq9mvfx8g3c4dzu01n72yeabijl'
    key='0123456789'
    a = []
    while num != 0:
        a.append(key[num%9])
        num = num / 9
    a.reverse()
    out = ''.join(a)
    return out

def make_random_letter():
    s = string.ascii_lowercase
    r = random.choice(s)+random.choice(s)+random.choice(s)+random.choice(s)
    return r

def make_random_number():
    #36进制位数对应10进制数范围参考：
    #1位：0-35
    #2位：36-1295
    #3位：1296-46655
    #4位：46656-1679615
    #5位：1679616-60466175
    #6位：60466176-2176782335
    # 只要秒数大于60466175，就可以转换出6位的36进制数，这里从2015年1月1日开始计算，约70年后会变成7位
    d1=datetime.datetime(2015,1,1)
    d2=datetime.datetime.now()
    #获取秒数
    s=(d2-d1).days*24*60*60
    #获取微秒数
    ms=d2.microsecond
    #随机两位字符串
    id1=hex36(random.randint(36, 1295))
    #转换秒数
    id2=hex36(s)
    #转换微秒数，加46656是为了保证达到4位36进制数
    id3=hex36(ms+46656)
    mId=id1+id2+id3
    return mId[::-1]

def make_pic_id():
    return make_random_letter()+make_random_number()

def write_info_to_file(file_name):
    os.chdir(os.getcwd() + "\\data")
    with open(file_name, 'w') as f:
        for index in range(0, 10000000):
            hotel_id = make_pic_id()
            f.write("ht_" + hotel_id + "\t" + hotel_id + '.jpg' + "\n")

def file_merge(file_name):
    with open(file_name, 'w') as f:
        os.chdir(os.getcwd() + "\\data")
        folder_file_names = os.listdir(os.getcwd())
        print folder_file_names
        for folder_file_name in folder_file_names:
            for line in open(folder_file_name):
                f.writelines(line)
            f.write('\n')


if __name__ == '__main__':
    begin = datetime.datetime.now()
    process_num = 64 #打开的进程数
    pool = multiprocessing.Pool(processes=process_num)
    mkdir(os.getcwd()+"\\data")
    for num in range(0, process_num):
        file_name = "hotel"+str(num)+".txt"
        pool.apply_async(write_info_to_file, (file_name, ))
    pool.close()
    pool.join()
    file_merge("hotel.txt")
    end = datetime.datetime.now()
    print ("耗时：%s" % (end-begin))