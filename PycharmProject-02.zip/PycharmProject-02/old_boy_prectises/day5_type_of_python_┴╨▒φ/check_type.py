#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
type(2*3)

a,b,c = 1,2,3  # 意思是：a=1 ,b=2 ,c=3