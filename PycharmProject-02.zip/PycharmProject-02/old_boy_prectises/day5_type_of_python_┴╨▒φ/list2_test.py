#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:2017-02-21

# （一）包含：1 列表的长度；2 列表的相加 ；3 一个列表的多次表达； 4 元素于列表中的迭代

# 1 # 打印列表的 长度。
#a = len([1,2,3,4,5])     # len() 是内置函数；作用：调用列表的长度 ；在这儿，我把这个列表的长度赋值给 a 这个变量替代。
#print(a)                # 得出一个 列表的长度 （即值的个数） ；打印 变量 a ，即打印列表的长度值（个数）

#  2 # 两个列表 b 和 c 相加
#b = [1,2,3,4,5]
#c = [6,7,8,9,10]
#d = b+c
#print(d)

#  3 # 一个列表 b 多次使用
#e = [1,2,3,4,5]*3
#f = ['Hi!']*4
# print(e,f)

#  4 # 元素是否存在于列表之中。迭代。
#g = input([0,1,2,3,4,5,6,7,8,9])
#print(g)
#for i in g:print i

#  4 # 列表的包含关系。  ##     有待提高。。。
#b = [0,1,2,3]
#c = [0,1,2,3,4,5,6,7,8,9,10]
#d = b in c
#print(d)
#any([b==c[2:2+len(b)] for i in range(0,len(c)-len(b)+1)])

#（二）：列表的特殊情况---> 元祖 （即是：不可变的 “列表”） 。

#!/usr/bin/python
import operator
#list1, list2 = [123, 'xyz'], [456, 'abc']    # 列表和取值的表达方式 1
list1 = [123, 'xyz']                         # 列表和取值的表达方式 2  （包括 list1,2,3）
list2 = [456, 'abc']
list3 = list2 + [786]

#print(cmp(list1, list2),cmp(list2, list1),cmp(list2, list3))     # 2.x版本用法：打印的取值方式 1  ；返回结果是 1
#print cmp(list1, list2);                                        #  2.x版本用法：打印的取值方式 2 （ 包含如下 三个cmp(x,y)） 用 “分号”隔开
#print cmp(list2, list1);
#print cmp(list2, list3)

#print(operator.eq(list1,list2))                                  # 3.x版本用法：打印的取值方式 ；但前提是必须导入 perator 模块；返回结果 False 和 True