#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP

msg = "我爱你"
print(msg)
print(msg.encode()).decode("utf-8")