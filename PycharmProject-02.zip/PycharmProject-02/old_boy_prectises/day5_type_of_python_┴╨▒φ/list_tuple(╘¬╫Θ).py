#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:2017-02-21

# （一）包含：1 列表的长度；2 列表的相加 ；3 一个列表的多次表达； 4 元素于列表中的迭代

# 1 # 打印列表的 长度。
#a = len([1,2,3,4,5])     # len() 是内置函数；作用：调用列表的长度 ；在这儿，我把这个列表的长度赋值给 a 这个变量替代。
#print(a)                # 得出一个 列表的长度 （即值的个数） ；打印 变量 a ，即打印列表的长度值（个数）

#  2 # 两个列表 b 和 c 相加
#b = [1,2,3,4,5]
#c = [6,7,8,9,10]
#d = b+c
#print(d)

#  3 # 一个列表 b 多次使用
#e = [1,2,3,4,5]*3
#f = ['Hi!']*4
# print(e,f)

#  4 # 元素是否存在于列表之中。迭代。
#g = input([0,1,2,3,4,5,6,7,8,9])
#print(g)
#for i in g:print i

#  4 # 列表的包含关系。  ##     有待提高。。。
#b = [0,1,2,3]
#c = [0,1,2,3,4,5,6,7,8,9,10]
#d = b in c
#print(d)
#any([b==c[2:2+len(b)] for i in range(0,len(c)-len(b)+1)])

###### Python列表函数&方法；Python包含以下函数:
# （函数）# # python 函数 1 ： cmp() 方法用于比较两个列表的元素
import operator
#list1, list2 = [123, 'xyz'], [456, 'abc']    # 列表和取值的表达方式 1
#list1 = [123, 'xyz']                         # 列表和取值的表达方式 2  （包括 list1,2,3）
#list2 = [456, 'abc']
#list3 = list2 + [786]

#print cmp(list1, list2),cmp(list2, list1),cmp(list2, list3)     # 2.x版本用法：打印的取值方式 1  ；返回结果是 1
#print cmp(list1, list2);                                        #  2.x版本用法：打印的取值方式 2 （ 包含如下 三个cmp(x,y)） 用 “分号”隔开
#print cmp(list2, list1);
#print cmp(list2, list3)

#print(operator.eq(list1,list2))                                  # 3.x版本用法：打印的取值方式 ；但前提是必须导入 perator 模块；返回结果 False 和 True

# （函数）# # python 函数 2 ：len(list)   列表元素个数
#list1, list2 = [123, 'xyz', 'zara'], [456, 'abc']
#print("First list length : ", len(list1))              # 列表长度是 2 个值的长度
#print("Second list length : ", len(list2))

# （函数）# # python 函数 3 ：max() 方法返回列表元素中的最大值。
# 语法 max()方法语法： max(list)
#  参数   list -- 要返回最大值的列表。
#list1, list2 = [123, 'xyz', 'zara', 'abc'], [456, 700, 200]
#print("Max value element : ", max(list1))
#print( "Max value element : ", max(list2))

# （函数）# # python 函数 4 ：min(list)   返回列表元素最小值
#语法 min()方法语法： min(list)
# 参数 list -- 要返回最小值的列表。
#list1, list2 = [123, 'xyz', 'zara', 'abc'], [456, 700, 200]
#print("min value element : ", min(list1))
#print("min value element : ", min(list2))

# # （函数）# # python 函数 5 ：
# list() 方法用于将“元组”转换为 “列表”   -----返回值，返回列表。
#  语法 list()方法语法： list( seq )
#  参数 list -- 要转换为列表的元组。
#aTuple = (123, 'xyz', 'zara', 'abc')
#aList = list(aTuple)
#print( "列表元素是:",aList)

#===================================================================================
####Python包含以下方法:
#序号	方法
#1	list.append(obj)
#在列表末尾添加新的对象
#2	list.count(obj)
#统计某个元素在列表中出现的次数
#3	list.extend(seq)
#在列表末尾一次性追加另一个序列中的多个值（用新列表扩展原来的列表）
#4	list.index(obj)
#从列表中找出某个值第一个匹配项的索引位置
#5	list.insert(index, obj)
#将对象插入列表
#6	list.pop(obj=list[-1])
#移除列表中的一个元素（默认最后一个元素），并且返回该元素的值
#7	list.remove(obj)
#移除列表中某个值的第一个匹配项
#8	list.reverse()
#反向列表中元素
#9	list.sort([func])
#对原列表进行排序;该方法没有返回值，但是会对列表的对象进行排序。
#===================================================================================

#（二）：列表的特殊情况---> 元祖 （即是：不可变的 “列表”；但可查）（也提示看你代码的人，别改） 。
#   注：元组与列表是非常类似的，区别在于元组的元素值不能修改，元组是放在“括号”中，列表是放于“方括号”中。
# 元组运算符---------->>> 与字符串一样，元组之间可以使用 + 号和 * 号进行运算。这就意味着他们可以组合和复制，运算后会生成一个新的元组。
# 元组索引，截取；因为元组也是一个序列，所以我们可以访问元组中的指定位置的元素，也可以截取索引中的一段元素，如下所示：元组：
name_tuple = ('alex','jack')
# name_tuple.count()            # 元组有两种方法 count  和  index
# name_tuple.index()

# 1 ：访问元组：元组可以使用下标索引来访问元组中的值，如下实例:
#tup1 = ('physics', 'chemistry', 1997, 2000)
#tup2 = (1, 2, 3, 4, 5, 6, 7 )
#print ("tup1[0]: ", tup1[0])
#print ("tup2[1:5]: ", tup2[1:5])

# 2 ：修改元组：元组中的元素值是不允许修改的，但我们可以对元组进行连接组合，如下实例:
#tup1 = (12, 34.56)
#tup2 = ('abc', 'xyz')
        # 以下“修改元组元素”操作是“非法的”。
        # tup1[0] = 100
# 创建一个新的元组；但我们可以对元组进行连接组合
#tup3 = tup1 + tup2
#print (tup3)

# 3 ：删除元组；元组中的元素值是不允许删除的，但我们可以使用 del 语句来删除整个元组，如下实例:
#tup = ('physics', 'chemistry', 1997, 2000)
#print (tup)
#del (tup)
#print ("After deleting tup : ")
#print (tup)

# 4 ：无关闭分隔符；任意无符号的对象，以逗号隔开，默认为元组，如下实例：
# print ('abc', -4.24e93, 18+6.6j, 'xyz')
# x, y = (1, 2)
# print ("Value of x , y : ", x,y)

#   元组内置函数
#        Python元组包含了以下内置函数
#   序号	方法及描述
#       1	cmp(tuple1, tuple2)
#   比较两个元组元素。
#       2	len(tuple)
#   计算元组元素个数。
#       3	max(tuple)
#   返回元组中元素最大值。
#       4	min(tuple)
#   返回元组中元素最小值。
#       5	tuple(seq)
#  将列表转换为元组。