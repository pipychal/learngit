#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date: 2017-02-15
# # 列表是有序的，因为它有 “下标” ，通过下标来取值；字典无下标，但可以通过 key-value 来取值
# (一) ：列表的 切片（有六种形式）
#names = ["zhangsan","lisi","wangwu","zhaoliu","heqi","wangba","guojiu","quanshi","liushiyi","huangshier"]  #从第一位是 0 ；第二位是 2 ，以此类推...
#print(names)                            # 1:把列表里的值 全部打印出来
#print(names[0],names[5])                # 2:取第一位和第六位；取具体的某个位置的值
#print(names[0:5])                       # 3:切片（正向）；故首不顾尾；换句话说就是：包含 开头的位但不包含结束的位置 ;从第一位开始取直到取到的位置（但不包括该位置）
#print(names[-2])                        # 4:切片；正数是从前面 0 1 2 ... 开始  ；负数是从最后往前数，例如：最后（倒数）一位的表示方法是 -1  ；最后（倒数）第二位的表示方法是 -2 ... 以此类推
#print(names[-5:-1])                     # 5:切片（反向）；故首不顾尾；和“正向切片取位相反；但是取值顺序还是正向”；但是不可以这么表示： print(names[-1:-5]) 这个切记；但是这么表示娶不到最后一位；怎么办，如下 6:
#print(names[-5:])                       # 6:切片（反向）；为了拿到最后一位数值；冒号后不填写任数值即可；
#print(names)

# （二）：插入和 扩展 有三种形式 ;
#names.append("shanshan")                # 1; 追加到后面
#names.insert(1,"zhazha")                # 2: 在 2 位置；zhazha 插入 2 位；把 lisi 挤到 3 位
#names.insert(5,"hhh")                  # 同 上2
#names[1] = "sisi"                       # 3: 换位 ； 把 2 位 的 lisi 换成 sisi

#扩展：
# b = [1,2,3]
# names.extend(b)
# print(names)

# （三）：删除 有三种形式：
#names.remove("zhangsan")               # 1 : 变量.remove("相应位置的值")
#del names[1]                           # 2 : del + 变量[相应位置的位号]   等同于  names.pop(1)
#names.pop()                             # 3 :  括号内不加任何值；就是默认删除 names 变量的值的最后一个值（这里是 huangshier ）
#print(names)
### =====================================================================================================================
# 复制：分为 “深度复制”（等同于拷贝同大小的一份） 和 “浅复制”(只是复制 第一层 )
#  复制这个 不常用；但要记住。。。列表的存储存在内存地址里；
'''
实现 浅 copy 的三种方法：实现的结果都一样;创建联合账号。（现实很少用；我们会用外键）
p1=copy.copy(person)
p2=person[:]
p3=list[person]
'''
# person=['name',['s',100]
# person=['name',['saving',100]
# p1=person[:]
# p2=person[:]
# print(p1)
# print(p2)
#
# p1[0]='alex'
# p2[0]='fengjie'

# names = ["zhangsan","lisi","wangwu",["zhaoliu","zhaozhao"],"heqi","wangba","guojiu"]
# name2 = names.copy()     # 拷贝一份 names 变量的值 给 name2  ；python2.7是没有copy() 这个方法； python3.X以上就有了
# print(names)
# print(name2)
# names[2] = "王五"
# names[3][1] ="liuliu"
# print(names)

# 本文介绍了对象的赋值和拷贝，以及它们之间的差异：
#    Python中对象的赋值都是进行对象引用（内存地址）传递
#    -- 1 -- 使用copy.copy()，可以进行对象的浅拷贝，它复制了对象，但对于对象中的元素，依然使用原始的引用.
#    -- 2 -- 如果需要复制一个容器对象，以及它里面的所有元素（包含元素的子元素），可以使用copy.deepcopy()进行深拷贝
#    -- 3 -- 对于非容器类型（如数字、字符串、和其他’原子’类型的对象）没有被拷贝一说
#    -- 4 -- 如果元祖变量只包含原子类型对象，则不能深拷贝，看下面的例子

# 列表循环打印： 用  for 循环语句

names = ["zhangsan","lisi","wangwu",["zhaoliu","zhaozhao"],"heqi","wangba","guojiu"]
#print(names[0:-1:2])    # 切片和循环使用
print(names[0:-1:2])
for i in names:
    print(i)



