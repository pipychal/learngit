#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date: 2017-02-17
#  写两个东西； 其一是：购物价格清单列表； 其二是：

product_list = [
    ('Iphone',5800),
    ('Mac',9800),
    ('Bike',800),
    ('Watch',10600),
    ('Coffee',31),
    ('Alex Python',70),
]
salary = input("Input your salary:")
if salary.isdigit():
    salary = int(salary)
    while True:
        for item in product_list:                   # 另一种方法表示： for index,item in enumerate(product_list)
            print(product_list.index(item),item)    #  另一种方法表示：print(index,item)
        break
