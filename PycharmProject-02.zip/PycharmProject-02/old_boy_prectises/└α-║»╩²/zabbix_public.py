#!/usr/bin/env python
#coding:utf-8
#author:hlw

from pyzabbix import ZabbixAPI, ZabbixAPIException
import sqlite3,time,xlwt,os

ZABBIX_SERVER = 'http://180.163.112.202:8611/zabbix/'
ZABBIX_USER = 'Admin'
ZABBIX_PWD = '12345^&*().com'

try:
    zapi = ZabbixAPI(ZABBIX_SERVER)
    zapi.login(ZABBIX_USER, ZABBIX_PWD)
except ZabbixAPIException as e:
    print(e)

try:
	os.remove('/root/zabbix_api/zabbix_public.xls')
except:
	pass

conn = sqlite3.connect('/root/zabbix_api/sse.db')
cur = conn.cursor()
cur.execute("select * from public where 应用类型=(?) and 机器类型=(?) and 服务类型=(?)",(u'发布',u'虚拟机',u'应用托管'))
hostnames = (line[5] for line in cur.fetchall())
cur.close()
conn.close()

def gethostid():
	hostsinfo = []
	for hostname in hostnames:
		try:
			host = zapi.host.get(filter={'host':hostname})[0]
		except:
			pass
		else:	
			hostid = host['hostid']
			name = host['name'].split('-')
			if len(name) == 5:
				city = name[0]
				cabinet = name[1]
				info = name[2]
				broker = name[3]
				ip = name[4]
				hostinfo = [hostid,city,cabinet,hostname,info,broker,ip]
				hostsinfo.append(hostinfo)
	return hostsinfo

def getitem():
	y = 1
	tab_list = ['city','cabinet','hostname','info','broker','ip','tcpcount','cpu','mem_used','time','max_disk']
	workbook =xlwt.Workbook(encoding = 'utf=8')
	worksheet = workbook.add_sheet('sheet1')
	for x in range(len(tab_list)):
		worksheet.write(0,x,tab_list[x])	
	re1 = 'tcp.port.count[7709]'
	re11 = 'tcp.port.count[8601]'
	re12 = 'tcp.port.count[22223]'
	re13 = 'tcp.port.count[9020]'
	re14 = 'tcp.port.count[7721]'
	re15 = 'tcp.port.count[32041]'
	re16 = 'tcp.port.count[7711]'
	re2 = 'system.cpu.util[,idle]'
	re3 = "vm.memory.size[available]"
	re4 = "vm.memory.size[total]"
	re5 = "vfs.fs.size[/,pfree]"
	re6 = "vfs.fs.size[/boot,pfree]"
	re7 = "vfs.fs.size[/mds,pfree]"
	tcp_count = ''
	cpu = ''
	mem_ava = ''
	mem_total = ''
	root_use = ''
	timereal = ''
	boot_use = ''
	mds_use = ''
	for hostinfo in gethostid():
		print hostinfo[6]
		item1 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re1}) 
		if item1 == []:
			item1 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re11})
		if item1 == []:
			item1 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re12})
		if item1 == []:
			item1 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re13})
		if item1 == []:
			item1 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re14})
		if item1 == []:
			item1 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re15})
		if item1 == []:
			item1 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re16})
		if item1:
			itemid1 = item1[0]['itemid']
			try:
				item1_history = zapi.history.get(itemids=[itemid1],limit=400,sortfield='clock',sortorder='DESC')
			except:
				pass
			else:
				if item1_history:
					tcpinfo = {int(x['value']):x['clock'] for x in item1_history}
					tcp_count = max([ x for x in tcpinfo.keys()])
					timestamp = tcpinfo[tcp_count]
					timevalue = time.localtime(int(timestamp))
					timereal = time.strftime("%H:%M:%S",timevalue)
		item2 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re2})
		if item2:
			itemid2 = item2[0]['itemid']
			try:
				item2_history = zapi.history.get(itemids=[itemid2],limit=400,history=0,sortfield='clock',sortorder='DESC')
			except:
				pass
			else:
				if item2_history:
					cpu_idle = min([int(float(x['value'])) for x in item2_history])
					cpu = str(100 - cpu_idle) + '%'

		item3 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re3})
		if item3:
			itemid3 = item3[0]['itemid']
			try:
				item3_history = zapi.history.get(itemids=[itemid3],limit=400,sortfield='clock',sortorder='DESC')
			except:
				pass
			else:
				if item3_history:
					mem_ava = min([int(x['value']) for x in item3_history])

		item4 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re4})
		if item4:
			itemid4 = item4[0]['itemid']
			try:
				mem_total = int(zapi.history.get(itemids=[itemid4],limit=10)[0]['value'])
			except:
				pass

		item5 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re5})
		if item5:
			itemid5 = item5[0]['itemid']
			try:
				item5_history = zapi.history.get(itemids=[itemid5],limit=400,history=0,sortfield='clock',sortorder='DESC')
			except:
				pass
			else:
				if item5_history:
					root_idle = min([int(float(x['value'])) for x in item5_history])
					root_use = 100 - root_idle

		item6 = zapi.item.get(filter={'hostid':hostinfo[0],'key_':re6})
		if item6:
			itemid6 = item6[0]['itemid']
			try:
				item6_history = zapi.history.get(itemids=[itemid6],limit=400,history=0,sortfield='clock',sortorder='DESC')
			except:
				pass
			else:
				if item6_history:
					boot_idle = min([int(float(x['value'])) for x in item6_history])
					boot_use = 100 - boot_idle

		item7 =  zapi.item.get(filter={'hostid':hostinfo[0],'key_':re7})
		if item7:
			itemid7 = item7[0]['itemid']
			try:
				item7_history = zapi.history.get(itemids=[itemid7],limit=400,history=0,sortfield='clock',sortorder='DESC')
			except:
				pass
			else:
				if item7_history:
					mds_idle = min([int(float(x['value'])) for x in item7_history])
					mds_use = 100 - mds_idle

		disk_info = {root_use:'/:',boot_use:'/boot:',mds_use:'/mds:'}
		max1 = max([ x for x in disk_info.keys()])
		max2 = disk_info[max1]
		max_disk = max2 + str(max1) + '%'
		mem_use = str(100 - int(float(mem_ava) / mem_total * 100)) + '%'
		hostinfo += [tcp_count,cpu,mem_use,timereal,max_disk]
		for x in range(len(hostinfo) - 1):
			worksheet.write(y,x,hostinfo[x+1])
		y += 1
	workbook.save('/root/zabbix_api/zabbix_public.xls')
	print '======OK======'	

if __name__ == '__main__':
	getitem()
