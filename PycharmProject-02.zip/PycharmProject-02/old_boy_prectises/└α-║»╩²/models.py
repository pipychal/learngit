from peewee import (Model, SqliteDatabase, CharField, IntegerField,
                    SmallIntegerField, ForeignKeyField, Check,
                    OperationalError, DoesNotExist)

DATABASE = SqliteDatabase('sse.db',threadlocals=True,
                          pragmas=(
                              ('synchronous', 'off'),
                              ('journal_mode', 'WAL'),
                              ('cache_size', 10000),
                              ('mmap_size', 1024 * 1024 * 32)))

DATABASE2 = SqliteDatabase('itdb.db',threadlocals=True,
                          pragmas=(
                              ('synchronous', 'off'),
                              ('journal_mode', 'WAL'),
                              ('cache_size', 10000),
                              ('mmap_size', 1024 * 1024 * 32)))

class BaseModel(Model):
    class Meta:
        database = DATABASE
        order_by = ('-id',)

    @classmethod
    def getOne(cls, *query, **kwargs):
       # 为了方便使用，新增此接口，查询不到返回None，而不抛出异常
       try:
          return cls.get(*query, **kwargs)
       except DoesNotExist:
           return None

class User(BaseModel):
    """用户记录"""
    fields_new = (
        'name',
        'pwd',
        'crtpath'
    )

    fields_all = (
        'name',
        'pwd',
        'tbuserid',
        'crtpath'
    )

    id = IntegerField(null=True)
    name = CharField(null=True)
    pwd = CharField(null=True)
    crtpath = CharField()
    tbuserid = CharField()

    def to_json(self):
        return {"name": self.name}

    def is_authenticated(self):
        return True

    def is_active(self):
        return True

    def is_anonymous(self):
        return False

    def get_id(self):
        return str(self.id)

class Crash(BaseModel):
    """宕机记录"""
    fields_new = (
        'time1',
        'time2',
        'ip',
        'error',
        'cause'
    )

    fields_detail = (
        'time1',
        'time2',
        'error',
        'cause'
    )

    fields_all = (
        'id',
        'time1',
        'time2',
        'ip',
        'error',
        'cause',
        'operator',
        'tbtaskid',
        'tbtaskstate'
    )

    time1 = IntegerField()
    time2 = IntegerField()
    ip = CharField(null=True)
    error = CharField()
    cause = CharField()
    tbtaskid = CharField()
    tbtaskstate = IntegerField()
    operator = IntegerField(null=True)

class Repair(BaseModel):
    """补数记录"""
    fields_new = (
        'date',
        'ip',
        'cause'
    )

    fields_detail = (
        'date',
        'cause',
        'operator'
    )

    fields_all = (
        'id',
        'date',
        'ip',
        'cause',
        'operator',
        'tbtaskid',
        'tbtaskstate'
    )

    date = IntegerField(null=True)
    ip = CharField(null=True)
    cause = CharField()
    operator = IntegerField(null=True)
    tbtaskid = CharField()
    tbtaskstate = IntegerField()

class Maintain(BaseModel):
    """维修记录"""
    fields_new = (
        'date',
        'ip',
        'device',
        'operate',
        'state'
    )

    fields_detail = (
        'date',
        'device',
        'operate',
        'state'
    )

    fields_all = (
        'id',
        'date',
        'ip',
        'device',
        'operate',
        'state'
    )

    date = IntegerField(null=True)
    ip = CharField(null=True)
    device = CharField()
    operate = CharField()
    state = IntegerField()

class Public(BaseModel):
    """行情总表"""
    fields_all = (
        'id',
        '地点',
        '机柜号',
        '主用IP',
        '其它IP',
        '服务器名称',
        '券商',
        '软件商',
        '状态',
        '应用类型',
        '对外类型',
        'LVSIP',
        '行情站名称',
        '机器类型',
        '操作系统',
        '虚拟OS类型',
        '虚拟机配置',
        '服务类型'
    )

    地点 = CharField(null=True)
    机柜号 = CharField(null=True)
    主用IP = CharField(null=True)
    其它IP = CharField()
    服务器名称 = CharField(null=True)
    券商 = CharField()
    软件商 = CharField()
    状态 = CharField()
    应用类型 = CharField()
    对外类型 = CharField()
    LVSIP = CharField()
    行情站名称 = CharField()
    机器类型 = CharField()
    操作系统 = CharField()
    虚拟OS类型 = CharField()
    虚拟机配置 = CharField()
    服务类型 = CharField()
    机器类型标记 = CharField()
    应用类型标记 = CharField()
    服务类型标记 = CharField()
    服务端口 = CharField()
    地点标记 = CharField()
    状态标记 = CharField()
    券商标记 = CharField()
    信息商标记 = CharField()
    业务标记 = CharField()

class Private(BaseModel):
    """私有云总表"""
    fields_all = (
        'id',
        '地点',
        '机柜号',
        '主用IP',
        '其它IP',
        '服务器名称',
        '券商',
        '软件商',
        'VLAN号',
        '状态',
        '应用类型',
        'LVSIP',
        '机器类型',
        '操作系统',
        '虚拟OS类型',
        '虚拟机配置'
    )

    地点 = CharField(null=True)
    机柜号 = CharField(null=True)
    主用IP = CharField(null=True)
    其它IP = CharField()
    服务器名称 = CharField(null=True)
    券商 = CharField()
    软件商 = CharField()
    VLAN号 = CharField()
    状态 = CharField()
    应用类型 = CharField()
    LVSIP = CharField()
    机器类型 = CharField()
    操作系统 = CharField()
    虚拟OS类型 = CharField()
    虚拟机配置 = CharField()

class Metal(BaseModel):
    """资产统计表"""
    fields_all = (
        'id',
        '地点',
        '机柜号',
        '主用IP',
        '服务器标签',
        '品牌',
        '型号',
        '序列号',
        '生产日期'
    )

    地点 = CharField(null=True)
    机柜号 = CharField(null=True)
    主用IP = CharField(null=True)
    服务器标签 = CharField()
    品牌 = CharField()
    型号 = CharField()
    序列号 = CharField()
    生产日期 = CharField()

class Offline(BaseModel):
    """下线记录表"""
    fields_all = (
        'id',
        '地点',
        '机柜号',
        '主用IP',
        '对外服务IP',
        '券商',
        '信息商',
        '应用类型',
        '计划交付日期',
        '实际交付日期',
        '计划上线日期',
        '实际上线日期',
        '备注'
    )

    地点 = CharField(null=True)
    机柜号 = CharField(null=True)
    主用IP = CharField(null=True)
    对外服务IP = CharField()
    券商 = CharField()
    信息商 = CharField()
    应用类型 = CharField()
    计划交付日期 = CharField()
    实际交付日期 = CharField()
    计划上线日期 = CharField()
    实际上线日期 = CharField()
    备注 = CharField()

class ExtIP(BaseModel):
    """对外服务IP库"""
    fields_all = (
        'id',
        '运营商',
        '站点',
        '机柜号',
        '对外服务IP',
        '备注'
    )

    运营商 = CharField(null=True)
    站点 = CharField(null=True)
    机柜号 = CharField(null=True)
    对外服务IP = CharField(null=True)
    备注 = CharField()

class Raidinfo(BaseModel):
    """阵列卡信息"""
    fields_all = (
        'id',
        'ip',
        'model'
        'firmware',
        'cachestate',
        'batterystate',
        'cachesize',
        'cachepolicy',
        'avgio',
        'time'
    )

    ip = CharField(null=True)
    model = CharField()
    firmware = CharField()
    cachestate = CharField()
    batterystate = CharField()
    cachesize = IntegerField()
    cachepolicy = CharField()
    avgio = IntegerField()
    time = IntegerField()

class Diskinfo(BaseModel):
    """磁盘信息"""
    fields_all = (
        'id',
        'ip',
        'error',
        'time'
    )

    ip = CharField()
    error = CharField()
    time = IntegerField()

class Metalinfo(BaseModel):
    """硬件信息"""
    fields_all = (
        'id',
        'ip',
        'hostname'
        'release',
        'kernel',
        'mac',
        'vendor',
        'model',
        'sn',
        'mem',
        'mem_num',
        'mem_vendor',
        'mem_model',
        'cpu',
        'cpu_cores',
        'cpu_model',
        'disk',
        'disk_type',
        'disk_model',
        'time'
    )

    ip = CharField(null=True)
    hostname = CharField()
    release = CharField()
    kernel = CharField()
    mac = CharField()
    vendor = CharField()
    model = CharField()
    sn = CharField()
    mem = IntegerField()
    mem_num = IntegerField()
    mem_vendor = CharField()
    mem_model = CharField()
    cpu = IntegerField()
    cpu_cores = IntegerField()
    cpu_vendor = CharField()
    cpu_model = CharField()
    disk = IntegerField()
    disk_type = CharField()
    disk_vendor = CharField()
    disk_model = CharField()
    time = IntegerField()

class LVS(BaseModel):
    """LVS信息"""
    fields_all = (
        'id',
        'LVS主用IP',
        'LVS备用IP',
        'LVS虚拟IP',
        'LVS映射公网IP',
        'LVS映射端口',
        '虚拟服务器IP'
    )

    LVS主用IP = CharField()
    LVS备用IP = CharField()
    LVS虚拟IP = CharField()
    LVS映射公网IP = IntegerField()
    LVS映射端口 = CharField()
    虚拟服务器IP = CharField()

class LVSInfo(BaseModel):
    """LVS配置"""
    fields_all = (
        'id',
        'ip',
        'priority',
        'vsip'
        'vsport',
        'rsip',
        'rsport',
        'persist_time',
        'time'
    )

    ip = CharField(null=True)
    priority = IntegerField()
    vsip = CharField()
    vsport = IntegerField()
    rsip = CharField()
    rsport = IntegerField()
    persist_time = IntegerField()
    time = IntegerField()

class LVSChange(BaseModel):
    """LVS信息"""
    fields_all = (
        'id',
        'ip',
        'priority',
        'vsip'
        'vsport',
        'rsip',
        'rsport',
        'persist_time',
        'time'
    )

    ip = CharField(null=True)
    priority = IntegerField()
    vsip = CharField()
    vsport = IntegerField()
    rsip = CharField()
    rsport = IntegerField()
    persist_time = IntegerField()
    time = IntegerField()

class LVS_ChangeLog(BaseModel):
    """LVS历史记录"""
    ip = CharField(null=True)
    vsip = CharField()
    vsport = IntegerField()
    log = CharField()
    time = IntegerField(null=True)

class MaxConn(BaseModel):
    """并发数"""
    fields_all = (
        'id',
        'date',
        'city',
        'cabinet',
        'ip',
        'linknum',
        'limitnum',
        'type'
    )

    date = IntegerField(null=True)
    city = CharField()
    cabinet = CharField()
    ip = CharField()
    linknum = IntegerField()
    limitnum = IntegerField()
    type = IntegerField(null=True)

class Capacity(BaseModel):
    """容量"""
    fields_all = (
        'id',
        'date',
        'type',
        'city',
        'cabinet',
        'flow',
        'limitnum',
        'online1',
        'online2',
        'ready',
        'offline'
    )

    date = IntegerField(null=True)
    type = IntegerField(null=True)
    city = CharField(null=True)
    cabinet = CharField()
    flow = IntegerField()
    limitflow = IntegerField()
    online1 = IntegerField()
    online2 = IntegerField()
    ready = IntegerField()
    offline = IntegerField()

class ITDB(Model):
    class Meta:
        database = DATABASE2
        order_by = ('-id',)

class items(ITDB):
    fields_all = (
        'id',
        'itemtypeid',
        'manufacturerid',
        'model',
        'sn',
        'sn2',
        'warrantymonths',
        'purchasedate',
        'dnsname',
        'locationid',
        'userid',
        'ipv4',
        'label',
        'status'
    )

    itemtypeid = IntegerField()
    manufacturerid = IntegerField()
    model = CharField()
    sn = CharField()
    sn2 = CharField()
    warrantymonths = IntegerField()
    purchasedate = IntegerField()
    dnsname = CharField()
    locationid = IntegerField()
    userid = IntegerField()
    ipv4 = CharField()
    label = CharField()
    status = IntegerField()

class invoices(ITDB):
    fields_all = (
        'id',
        'number',
        'date',
        'vendorid',
        'buyerid',
        'description'
    )

    number = IntegerField()
    date = IntegerField()
    vendorid = IntegerField()
    buyerid = IntegerField()
    description = CharField()

class item2inv(ITDB):
    fields_all = (
        'itemid',
        'invid'
    )

    itemid = IntegerField()
    invid = IntegerField()

class users(ITDB):
    fields_all = (
        'id',
        'username'
    )

    username = CharField()

class itemtypes(ITDB):
    fields_all = (
        'id',
        'typedesc'
    )

    typedesc = CharField()

class agents(ITDB):
    fields_all = (
        'id',
        'title'
    )

    title = CharField()

class locations(ITDB):
    fields_all = (
        'id',
        'name'
    )

    name = CharField()

class statustypes(ITDB):
    fields_all = (
        'id',
        'statusdesc'
    )

    statusdesc = CharField()

'''
def initialize():
    try:
        DATABASE.connect()
        print("Initializing database...")
    except OperationalError:
        print("Database already initialized!")

    print("Database was successfully initialized!")

    try:
        DATABASE.close()
    except Exception as e:
        print(e)

def direct_sql_query(query):
    DATABASE.execute_sql(query)
'''