from flask import flash
from peewee import fn, JOIN, RawQuery
from collections import OrderedDict
import sys,os,shutil,time,datetime
import logging
import models
import config
from teambitionAPI import tb
# from autosessionCRT import CRTsession
# from zabbixAPI import zabbix
from lvs import analyze

# logging.basicConfig(level=logging.DEBUG)
logging.Formatter('%(asctime)s %(levelname)s %(message)s', datefmt='%a, %d %b %Y %H:%M:%S')

'''
def list_details(date,active_page, title="",ip=None):
    records_public = models.Public.select().where(models.Public.主用IP == ip)
    records_lvs = models.Public.select().where(models.Public.LVSIP == ip)
    records_crash = models.Crash.select(models.Crash.time1,models.Crash.恢复时间,models.Crash.故障现象,models.Crash.原因分析).where(models.Crash.主用IP == ip)
    return render_template('detail.html',
                           records_public=records_public,
                           records_crash=records_crash,
                           records_lvs = records_lvs,
                           active_page=active_page,
                           title=title,
                           fields_public=models.Public.fields_all,
                           fields_crash =models.Crash.fields_detail,
                                    date=date)

def find_records(date,form_class, active_page, title=""):
    if request.method == "POST":
        query_list = []

        for key in request.form:
            if request.form[key] and key != 'csrf_token':
                query_list.append("{}={}".format(key, request.form[key]))

        query = "&&".join(query_list)

        return redirect('/{}?{}'.format(active_page, query))

    return render_template('search_form.html',
                           form=form_class(),
                           active_page=active_page,
                           title=title,
                                    date=date)
'''

def mkzabbix():
    model = models.Public
    metalinfo = models.Metal

    records = (model.select(model.地点.alias('city'), model.机柜号.alias('cabinet'), model.服务器名称.alias('name'), model.主用IP.alias('ip'), model.券商.alias('qs'), model.软件商.alias('app'), model.应用类型.alias('type'), model.操作系统.alias('system'), model.应用类型标记.alias('typeflag'), model.信息商标记.alias('appflag'))
               .where(~(model.服务类型 == '资源租用') & ~(model.券商 << ['移动业务', '大智慧', '互联网技术部', '信息公司', '钱龙资讯', '']) & (model.机器类型 == '虚拟机') & (model.状态 << ['上线', '券商试运行']) & ~(model.应用类型 << ['Audit', '']))
               .dicts())
    for record in records:
        data = {}
        data['host_name'] = record['name']
        data['visible_name'] = record['city'][1:] + '-' + record['cabinet'] + '-' + record['app'] + '-' + record['qs'] + '-' + record['ip']
        data['host_ip'] = record['ip']
        if 'CentOS' in record['system']:
            if record['qs'] == '负载均衡':
                data['template'] = [{'Template-LVS': '模板-负载均衡'},{'Template-Linux-All': '模板-Linux-通用'}]
            else:
                data['template'] = [{'Template-' + record['typeflag'].rstrip('Flag') + '-Linux-' + record['appflag']:'模板-' + record['type'] + '-Linux-' + record['app']}, {'Template-Linux-All':'模板-Linux-通用'}]
        else:
            data['template'] = [{'Template-' + record['typeflag'].rstrip('Flag') + '-Windows-' + record['appflag']:'模板-' + record['type'] + '-Windows-' + record['app']}, {'Template-Windows-All':'模板-Windows-通用'}]
        if record['qs'] == record['app']:
            data['group'] = [record['city'][1:] + record['cabinet'], record['qs']]
        else:
            data['group'] = [record['city'][1:] + record['cabinet'], record['qs'], record['app']]
        zabbix.create_host(data)

    records = (model.select(model.地点.alias('city'), model.机柜号.alias('cabinet'), model.服务器名称.alias('name'), model.主用IP.alias('ip'), model.虚拟OS类型.alias('os'), metalinfo.品牌.alias('vendor'))
               .join(metalinfo, JOIN.LEFT_OUTER, on=(metalinfo.主用IP == model.主用IP))
               .where((model.机器类型 == '物理机') & ~(model.地点 == 'Q长沙'))
               .dicts())
    for record in records:
        data = {}
        data['host_name'] = record['name']
        vendor = record['vendor'] if record['vendor'] else '未知'
        os = record['os'] if record['os'] else '未知'
        data['visible_name'] = record['city'][1:] + '-' + record['cabinet'] + '-' + vendor + '-' + os + '-' + record['ip']
        data['host_ip'] = record['ip']
        if 'KVM' in record['os']:
            data['template'] = [{'Template-KVM': '模板-KVM'}]
        else:
            data['template'] = [{'Template-ESXI': '模板-ESXI'}]
        data['group'] = [record['city'][1:] + record['cabinet'], '物理机']
        zabbix.create_host(data)

    records = (model.select(model.地点.alias('city'), model.机柜号.alias('cabinet'), model.服务器名称.alias('name'), model.主用IP.alias('ip'), model.券商.alias('qs'), model.软件商.alias('app'), model.操作系统.alias('system'))
               .where(~(model.服务类型 == '资源租用') & ~(model.券商 << ['移动业务', '大智慧', '互联网技术部', '信息公司', '钱龙资讯', '']) & (model.机器类型 == '虚拟机') & (model.地点 == 'Z全真') & ~(model.应用类型 << ['Audit', '']))
               .dicts())
    for record in records:
        data = {}
        data['host_name'] = record['name']
        if record['qs']:
            data['visible_name'] = record['city'][1:] + '-' + record['cabinet'] + '-' + record['app'] + '-' + record['qs'] + '-' + record['ip']
        else:
            data['visible_name'] = record['city'][1:] + '-' + record['cabinet'] + '-' + record['app'] + '-未知-' + record['ip']
        data['host_ip'] = record['ip']
        if 'CentOS' in record['system']:
            data['template'] = [{'Template-Linux-All': '模板-Linux-通用'}]
        else:
            data['template'] = [{'Template-Windows-All': '模板-Windows-通用'}]
        data['group'] = [record['city'][1:] + record['cabinet']]
        zabbix.create_host(data)

'''
def mk_CRT(user, crtpath):
    sessions = ['tdx','ths','dzhjdb','dzhxyd','ql','hs','lvs','zyfp','ths_h5']
    for session in sessions:
        crt = CRTsession.session(session)
        crt.generator_session(user)

    BasePath = sys.path[0]
    DownloadsPath = os.path.join(BasePath, 'downloads')
    if os.path.exists(os.path.join(DownloadsPath,'%s.exe'% user)):
        os.remove(os.path.join(DownloadsPath,'%s.exe'% user))

    crtpath = crtpath + '\Sessions'
    #config.pzip(user)
    config.rar(user, crtpath)
    #shutil.move((os.path.join(BasePath,"%s.exe" % user)),DownloadsPath)
    shutil.rmtree(os.path.join(BasePath, 'SSE'))
    os.chdir(BasePath)

    return redirect('/forms/downloads/%s.exe' % user)
'''

class Charts(object):

    def __init__(self):
        self.public = models.Public
        self.private = models.Private
        self.extip = models.ExtIP
        self.offline = models.Offline
        self.crash = models.Crash
        self.repair = models.Repair
        self.maintain = models.Maintain
        self.metal = models.Metal
        self.itdb_items = models.items
        self.maxconn = models.MaxConn
        self.capacity = models.Capacity
        self.threemonth = int(time.mktime(datetime.datetime.now().timetuple())) - 86400 * 90
        self.data = []

    def mkservice(self, qs, app, city):
        all = 0
        location = []
        applist = []
        appcitybar = {}
        apppie = {}
        typepie = {}

        # 选项 券商 值为所有，图例为券商
        if qs == '(.*)':
            records = (self.public.select(self.public.券商.alias('qs'), fn.COUNT(self.public.主用IP).alias('count'))
                .where((self.public.地点.regexp(city)) & (self.public.软件商.regexp(app)) & (self.public.状态 << ['上线', '券商试运行']) & (self.public.应用类型.contains('发布')) & (self.public.应用类型 != '') & (self.public.机器类型 == '虚拟机'))
                .group_by(self.public.券商)
                .dicts())
            # 临时解决 券商 值为空
            for record in records:
                if record['qs'] == '':
                    pass
                else:
                    apppie[record['qs']] = record['count']
                    applist.append(record['qs'])
            applist.sort()
        else:
            # 选项 券商 值选定
            # 选项 信息商 值为所有，饼图为信息商
            if app == '(.*)':
                records = (self.public.select(self.public.软件商.alias('app'), fn.COUNT(self.public.主用IP).alias('count'))
                    .where((self.public.券商.regexp(qs)) & (self.public.地点.regexp(city)) & (self.public.状态 << ['上线', '券商试运行']) & (self.public.应用类型.contains('发布')) & (self.public.应用类型 != '') & (self.public.机器类型 == '虚拟机'))
                    .group_by(self.public.软件商)
                    .dicts())
                for record in records:
                    apppie[record['app']] = record['count']
                    applist.append(record['app'])
                applist.sort()
            # 选项 券商/信息商 值选定
            # 选项 地点 值为所有，饼图为城市
            elif city == '(.*)':
                records = (self.public.select(self.public.地点.alias('city'), fn.COUNT(self.public.主用IP).alias('count'))
                    .where((self.public.券商.regexp(qs)) & (self.public.软件商.regexp(app)) & (self.public.状态 << ['上线', '券商试运行']) & (self.public.应用类型.contains('发布')) & (self.public.应用类型 != '') & (self.public.机器类型 == '虚拟机'))
                    .group_by(self.public.地点)
                    .dicts())
                for record in records:
                    apppie[record['city'][1:]] = record['count']
                applist.append(app)
            # 选项 券商/信息商/地点 值选定
            # 选项 饼图为机柜
            else:
                records = (self.public.select(self.public.地点.alias('city'), self.public.机柜号.alias('cabinet'), fn.COUNT(self.public.主用IP).alias('count'))
                    .where((self.public.券商.regexp(qs)) & (self.public.软件商.regexp(app)) & (self.public.地点.regexp(city)) & (self.public.状态 << ['上线', '券商试运行']) & (self.public.应用类型.contains('发布')) & (self.public.应用类型 != '') & (self.public.机器类型 == '虚拟机'))
                    .group_by(self.public.地点, self.public.机柜号)
                    .dicts())
                for record in records:
                    apppie[record['city'][1:]+record['cabinet']] = record['count']
                applist.append(app)
                applist.sort()

        # 应用类型饼图
        records = (self.public.select(self.public.服务类型.alias('type'), fn.COUNT(self.public.主用IP).alias('count'))
            .where((self.public.券商.regexp(qs)) & (self.public.软件商.regexp(app)) & (self.public.地点.regexp(city)) & (self.public.状态 << ['上线', '券商试运行']) & (self.public.应用类型.contains('发布')) & (self.public.应用类型 != '') & (self.public.机器类型 == '虚拟机'))
            .group_by(self.public.服务类型)
            .dicts())
        for record in records:
            typepie[record['type']] = record['count']
            all = all + record['count']

        # X轴类目为地点
        records = (self.public.select(self.public.地点.alias('city'), self.public.机柜号.alias('cabinet'))
            .where((self.public.券商.regexp(qs)) & (self.public.软件商.regexp(app)) & (self.public.地点.regexp(city)) & (self.public.状态 << ['上线', '券商试运行']) & (self.public.应用类型.contains('发布')) & (self.public.应用类型 != '') & (self.public.机器类型 == '虚拟机'))
            .group_by(self.public.地点, self.public.机柜号)
            .dicts())
        for record in records:
            location.append(record['city'][1:] + '\n' + record['cabinet'])
        location.sort()

        # Y轴值
        for a in applist:
            count = []
            for i in location:
                record = (self.public.select(self.public.主用IP)
                    .where(((self.public.券商.regexp(a)) | (self.public.软件商.regexp(a))) & (self.public.地点.contains(i[0:2])) & (self.public.机柜号 == i[-2:])  & (self.public.状态 << ['上线', '券商试运行']) & (self.public.应用类型.contains('发布')) & (self.public.应用类型 != '') & (self.public.机器类型 == '虚拟机'))
                    .count())
                count.append(record)
            appcitybar[a] = count

        self.data = [all, location, applist, appcitybar, apppie, typepie]
        return self.data
    def mkdetail_maxconn(self, type, qs, app, city, cabinet, date1, date2):
        today = {'all': None, 'linknum': None, 'limit': None}
        yesterday = {'all': None, 'linknum': None}

        if type == '云平台':
            type = 1
            joindb = self.public
        elif type == '私有云':
            type = 2
            joindb = self.private
        elif type == '移动':
            type = 3
            joindb = self.public
        elif type == 'MAAS':
            type = 4
            joindb = self.public

        if date1 == None or date2 == None:
            tmp = []
            records = self.maxconn.select(self.maxconn.date).group_by(self.maxconn.date).order_by(self.maxconn.date.desc()).limit(2)
            for record in records:
                tmp.append(record.date)
            date1 = tmp[0] if date1 == None else date1
            date2 = tmp[1] if date2 == None else date2

        for date in [date1, date2]:
            all = 0
            linknum = OrderedDict()
            records = (self.maxconn
                    .select(self.maxconn.ip, self.maxconn.linknum, self.maxconn.limitnum, joindb.地点.alias('city'), joindb.机柜号.alias('cabinet'))
                    .join(joindb, JOIN.LEFT_OUTER, on=(joindb.主用IP == self.maxconn.ip))
                    .where((self.maxconn.date == date) & (self.maxconn.type == type) & (joindb.地点.regexp(city)) & (joindb.机柜号.regexp(cabinet)) & (joindb.券商.regexp(qs)) & (joindb.软件商.regexp(app)))
                    .dicts()
                    .order_by(joindb.地点.desc(), joindb.机柜号.desc()))
            if date == date1:
                limit = OrderedDict()
                for record in records:
                    ip = record['ip'] + record['city'][1:] + record['cabinet']
                    linknum[ip] = record['linknum']
                    limit[ip] = record['limitnum']
                    all = all + record['linknum']
                today['all'] = all
                today['linknum'] = linknum
                today['limit'] = limit
            else:
                for record in records:
                    ip = record['ip'] + record['city'][1:] + record['cabinet']
                    linknum[ip] = record['linknum']
                    all = all + record['linknum']
                yesterday['all'] = all
                yesterday['linknum'] = linknum

        citypie = OrderedDict()
        if city == '(.*)':
            text = '各站点并发数分布'
            records = (self.maxconn
                    .select(fn.SUM(self.maxconn.linknum),joindb.地点.alias('city'))
                    .join(joindb, JOIN.LEFT_OUTER, on=(joindb.主用IP == self.maxconn.ip))
                    .where((self.maxconn.date == date1) & (self.maxconn.type == type) & (joindb.券商.regexp(qs)) & (joindb.软件商.regexp(app)))
                    .group_by(joindb.地点)
                    .order_by(joindb.地点)
                    .dicts())
        else:
            text = '各机柜并发数分布'
            records = (self.maxconn
                    .select(fn.SUM(self.maxconn.linknum),joindb.机柜号.alias('city'))
                    .join(joindb, JOIN.LEFT_OUTER, on=(joindb.主用IP == self.maxconn.ip))
                    .where((self.maxconn.date == date1) & (self.maxconn.type == type) & (joindb.券商.regexp(qs)) & (joindb.软件商.regexp(app)) & (joindb.地点.regexp(city)))
                    .group_by(joindb.机柜号)
                    .order_by(joindb.机柜号)
                    .dicts())
        for record in records:
            citypie[record['city']] = record['linknum']

        apppie = OrderedDict()
        records = (self.maxconn
                .select(fn.SUM(self.maxconn.linknum),joindb.软件商.alias('app'))
                .join(joindb, JOIN.LEFT_OUTER, on=(joindb.主用IP == self.maxconn.ip))
                .where((self.maxconn.date == date1) & (self.maxconn.type == type) & (joindb.券商.regexp(qs)))
                .group_by(joindb.软件商)
                .order_by(joindb.软件商)
                .dicts())
        for record in records:
            apppie[record['app']] = record['linknum']

        self.data = [today, yesterday, citypie, apppie, text]
        return self.data
    def mkdetail_capacity(self, type, city, date1, date2):
        flag = 0
        today = {'all': None, 'used': None, 'limit': None, 'online': None, 'ready': None, 'offline': None}
        yesterday = {'all': None, 'used': None, 'online': None, 'ready': None, 'offline': None}

        if type == 'PC行情':
            type = 1
        elif type == '港股商业行情':
            type = 2
        elif type == '手机行情L1':
            type = 3
        elif type == '手机行情L2':
            type = 3
            flag = 1
        elif type == '私有云':
            type = 4

        if date1 == None or date2 == None:
            tmp = []
            records = self.capacity.select(self.capacity.date).group_by(self.capacity.date).order_by(
                self.capacity.date.desc()).limit(2)
            for record in records:
                tmp.append(record.date)
            date1 = tmp[0] if date1 == None else date1
            date2 = tmp[1] if date2 == None else date2

        for date in [date1, date2]:
            all = 0
            used = OrderedDict()
            online = OrderedDict()
            ready = OrderedDict()
            offline = OrderedDict()
            records = (self.capacity
                       .select(self.capacity.city, self.capacity.cabinet, self.capacity.flow, self.capacity.limitflow,
                               self.capacity.online1, self.capacity.online2, self.capacity.ready, self.capacity.offline)
                       .where((self.capacity.type == type) & (self.capacity.date == date) & (self.capacity.city.regexp(city)))
                       .order_by(self.capacity.city.desc())
                       .dicts())

            if date == date1:
                limit = OrderedDict()
                for record in records:
                    data = record['city'] + '\n' + record['cabinet'] if record['cabinet'] else record['city']
                    used[data] = record['flow']
                    limit[data] = record['limitflow']
                    online[data] = record['online2'] if flag else record['online1']
                    ready[data] = record['ready']
                    offline[data] = record['offline']
                    if type != 0:
                        if flag:
                            all = all + record['online2'] + record['ready'] + record['offline']
                        else:
                            all = all + record['online1'] + record['ready'] + record['offline']
                    else:
                        all = all + record['flow']
                today['all'] = all
                today['used'] = used
                today['limit'] = limit
                today['online'] = online
                today['ready'] = ready
                today['offline'] = offline
            else:
                for record in records:
                    data = record['city'] + '\n' + record['cabinet'] if record['cabinet'] else record['city']
                    used[data] = record['flow']
                    online[data] = record['online2'] if flag else record['online1']
                    ready[data] = record['ready']
                    offline[data] = record['offline']
                    if type != 0:
                        if flag:
                            all = all + record['online2'] + record['ready'] + record['offline']
                        else:
                            all = all + record['online1'] + record['ready'] + record['offline']
                    else:
                        all = all + record['flow']
                yesterday['all'] = all
                yesterday['used'] = used
                yesterday['online'] = online
                yesterday['ready'] = ready
                yesterday['offline'] = offline
        self.data = [today, yesterday]
        return self.data
    def mktrend_maxconn(self, type, qs, app, city, cabinet, ip):
        if type == '云平台':
            type = 1
            joindb = self.public
        elif type == '私有云':
            type = 2
            joindb = self.private
        elif type == '移动':
            type = 3
            joindb = self.public
        elif type == 'MAAS':
            type = 4
            joindb = self.public

        history = OrderedDict()
        records = (self.maxconn
                .select(self.maxconn.date, fn.SUM(self.maxconn.linknum))
                .join(joindb, JOIN.LEFT_OUTER, on=(joindb.主用IP == self.maxconn.ip))
                .where((self.maxconn.type == type) & (joindb.券商.regexp(qs)) & (joindb.软件商.regexp(app)) & (joindb.地点.regexp(city)) & (joindb.机柜号.regexp(cabinet)) & (joindb.主用IP.regexp(ip)))
                .group_by(self.maxconn.date)
                .dicts()
                .order_by(self.maxconn.date))
        for record in records:
            date = time.strftime('%Y-%m-%d', time.localtime(record['date']))
            history[date] = record['linknum']

        self.data = [history]
        return self.data
    def mktrend_capacity(self, type, city, cabinet):
        history = {'date':None, 'flow': None, 'limitflow': None, 'online': None, 'ready': None, 'offline': None}
        datelist = []
        flow = OrderedDict()
        limitflow = OrderedDict()
        online = OrderedDict()
        ready = OrderedDict()
        offline = OrderedDict()

        if type == '网络':
            records = (self.capacity
                    .select(self.capacity.date, fn.SUM(self.capacity.flow), fn.SUM(self.capacity.limitflow))
                    .where((self.capacity.type == 0) & (self.capacity.city.regexp(city)) & (self.capacity.cabinet.regexp(cabinet)))
                    .group_by(self.capacity.date)
                    .dicts()
                    .order_by(self.capacity.date))
            for record in records:
                date = time.strftime('%Y-%m-%d', time.localtime(record['date']))
                datelist.append(date)
                flow[date] = record['flow']
                limitflow[date] = record['limitflow']
        elif type == '服务器':
            records = (self.capacity
                    .select(self.capacity.date, fn.SUM(self.capacity.online1), fn.SUM(self.capacity.online2), fn.SUM(self.capacity.ready), fn.SUM(self.capacity.offline))
                    .where((self.capacity.type > 0) & (self.capacity.city.regexp(city)))
                    .group_by(self.capacity.date)
                    .dicts()
                    .order_by(self.capacity.date))
            for record in records:
                date = time.strftime('%Y-%m-%d', time.localtime(record['date']))
                datelist.append(date)
                online[date] = record['online1'] + record['online2']
                ready[date] = record['ready']
                offline[date] = record['offline']

        history['date'] = datelist
        history['flow'] = flow
        history['limitflow'] = limitflow
        history['online'] = online
        history['online'] = online
        history['ready'] = ready
        history['offline'] = offline

        self.data = [history]
        return self.data
    def mkcrash(self, qs, app, city, cabinet, ip):
        data = OrderedDict()
        top10 = OrderedDict()


        records = RawQuery(self.crash,'SELECT strftime(\'%Y-%m\',datetime(time1,\'unixepoch\',\'localtime\')) AS date,count(time1) AS count FROM crash GROUP BY date').dicts()
        for record in records:
            data[record['date']] = record['count']

        records = (self.crash
                .select(self.crash.ip, fn.Count(self.crash.ip).alias('count'), self.public.券商.alias('qs'), self.public.软件商.alias('app'))
                .where(self.crash.time1 > self.threemonth)
                .join(self.public, JOIN.LEFT_OUTER, on=(self.public.主用IP == self.crash.ip))
                .group_by(self.crash.ip)
                .order_by(fn.Count(self.crash.ip).desc())
                .dicts()
                .limit(10))
        for record in records:
            tmp = []
            tmp.append(record['qs'])
            tmp.append(record['app'])
            tmp.append(record['count'])
            top10[record['ip']] = tmp

        self.data = [data, top10]
        return self.data
    def mkrepair(self, qs, app, city, cabinet, ip):
        data = OrderedDict()
        top10 = OrderedDict()

        records = RawQuery(self.repair,
                       'SELECT strftime(\'%Y-%m\',datetime(date,\'unixepoch\',\'localtime\')) AS date1,count(date) AS count FROM repair GROUP BY date1').dicts()
        for record in records:
            data[record['date1']] = record['count']

        records = (self.repair
                .select(self.repair.ip, fn.Count(self.repair.ip).alias('count'), self.public.券商.alias('qs'), self.public.软件商.alias('app'))
                .where(self.repair.date > self.threemonth)
                .join(self.public, JOIN.LEFT_OUTER, on=(self.public.主用IP == self.repair.ip))
                .group_by(self.repair.ip)
                .order_by(fn.Count(self.repair.ip).desc())
                .dicts()
                .limit(10))
        for record in records:
            tmp = []
            tmp.append(record['qs'])
            tmp.append(record['app'])
            tmp.append(record['count'])
            top10[record['ip']] = tmp

        self.data = [data, top10]
        return self.data
    def mkmaintain(self):
        data = OrderedDict()
        top10 = OrderedDict()

        records = RawQuery(self.maintain,
                       'SELECT strftime(\'%Y-%m\',datetime(date,\'unixepoch\',\'localtime\')) AS date1,count(date) AS count FROM maintain GROUP BY date1').dicts()
        for record in records:
            data[record['date1']] = record['count']

        records = (self.maintain
                .select(self.maintain.ip, fn.Count(self.maintain.ip).alias('count'), self.metal.品牌.alias('vendor'), self.metal.型号.alias('model'))
                .where(self.maintain.date > self.threemonth)
                .join(self.metal, JOIN.LEFT_OUTER, on=(self.metal.主用IP == self.maintain.ip))
                .group_by(self.maintain.ip)
                .order_by(fn.Count(self.maintain.ip).desc())
                .dicts()
                .limit(10))
        for record in records:
            tmp = []
            tmp.append(record['vendor'])
            tmp.append(record['model'])
            tmp.append(record['count'])
            top10[record['ip']] = tmp

        self.data = [data, top10]
        return self.data
    def mkitdb(self, dnsname):
        itemtypes, agents, status, locations = Tables().mkitdb_options()

        metal_bar = OrderedDict()
        network_bar = OrderedDict()
        type_pie = OrderedDict()
        manufacturer_pie1 = OrderedDict()
        manufacturer_pie2 = OrderedDict()
        warranty_pie = {'过保':0, '在保':0, '无保':0}
        all = {'metal':0, 'network':0}
        tmp = 0

        records = (self.itdb_items
                .select(self.itdb_items.locationid, fn.COUNT(self.itdb_items.model).alias('count'))
                .where((self.itdb_items.itemtypeid << ['14','16']) & (self.itdb_items.dnsname.contains(dnsname)))
                .group_by(self.itdb_items.locationid)
                .order_by(self.itdb_items.locationid)
                .dicts())
        for record in records:
            if record['locationid'] is not None:
                metal_bar[locations[record['locationid']]] = record['count']
            else:
                pass
                # metal_bar['未知'] = record['count']
            tmp = tmp + record['count']
        all['metal'] = tmp
        tmp = 0

        '''self.itdb_items.locationid << ['49','50'] 暂时解决去除X轴不对等'''
        records = (self.itdb_items
                .select(self.itdb_items.locationid, fn.COUNT(self.itdb_items.model).alias('count'))
                .where((self.itdb_items.itemtypeid << ['8','10','11','13']) & ~(self.itdb_items.locationid << ['49','50']) & (self.itdb_items.dnsname.contains(dnsname)))
                .group_by(self.itdb_items.locationid)
                .order_by(self.itdb_items.locationid)
                .dicts())
        for record in records:
            if record['locationid'] is not None:
                network_bar[locations[record['locationid']]] = record['count']
            else:
                pass
                # network_bar['未知'] = record['count']
            tmp = tmp + record['count']
        all['network'] = tmp

        records = (self.itdb_items
                .select(self.itdb_items.itemtypeid, fn.COUNT(self.itdb_items.model).alias('count'))
                .where(self.itdb_items.dnsname.contains(dnsname))
                .group_by(self.itdb_items.itemtypeid)
                .order_by(self.itdb_items.itemtypeid)
                .dicts())
        for record in records:
            if record['itemtypeid'] is not None:
                type_pie[itemtypes[record['itemtypeid']]] = record['count']
            else:
                type_pie['未知'] = record['count']

        records = (self.itdb_items
                .select(self.itdb_items.manufacturerid, fn.COUNT(self.itdb_items.model).alias('count'))
                .where((self.itdb_items.itemtypeid << ['14','16']) & (self.itdb_items.dnsname.contains(dnsname)))
                .group_by(self.itdb_items.manufacturerid)
                .order_by(self.itdb_items.manufacturerid)
                .dicts())
        for record in records:
            if record['manufacturerid'] is not None:
                manufacturer_pie1[agents[record['manufacturerid']]] = record['count']
            else:
                manufacturer_pie1['未知'] = record['count']

        records = (self.itdb_items
                .select(self.itdb_items.manufacturerid, fn.COUNT(self.itdb_items.model).alias('count'))
                .where((self.itdb_items.itemtypeid << ['8','10','11','13']) & (self.itdb_items.dnsname.contains(dnsname)))
                .group_by(self.itdb_items.manufacturerid)
                .order_by(self.itdb_items.manufacturerid)
                .dicts())
        for record in records:
            if record['manufacturerid'] is not None:
                manufacturer_pie2[agents[record['manufacturerid']]] = record['count']
            else:
                manufacturer_pie2['未知'] = record['count']

        records = (self.itdb_items
                .select(self.itdb_items.purchasedate, self.itdb_items.warrantymonths)
                .where(self.itdb_items.dnsname.contains(dnsname))
                .dicts())
        for record in records:
            if record['purchasedate'] is not None:
                deltamonths = int((int(time.mktime(datetime.date.today().timetuple())) - record['purchasedate']) / (24 * 60 * 60))
                warrantydays = record['warrantymonths']*30
                if record['warrantymonths'] is not None:
                    if (deltamonths > warrantydays):
                        warranty_pie['过保'] = warranty_pie['过保'] + 1
                    else:
                        warranty_pie['在保'] = warranty_pie['在保'] + 1
                else:
                    warranty_pie['无保'] = warranty_pie['无保'] + 1
            else:
                warranty_pie['无保'] = warranty_pie['无保'] + 1

        self.data = [all, metal_bar, network_bar, type_pie, manufacturer_pie1, manufacturer_pie2, warranty_pie]
        return self.data

class Tables(object):

    def __init__(self):
        self.public = models.Public
        self.private = models.Private
        self.extip = models.ExtIP
        self.offline = models.Offline
        self.crash = models.Crash
        self.repair = models.Repair
        self.metal = models.Metal
        self.maintain = models.Maintain
        self.itdb_items = models.items
        self.itdb_agents = models.agents
        self.itdb_itemtypes = models.itemtypes
        self.itdb_status = models.statustypes
        self.itdb_locations = models.locations
        # self.itdb_item2inv = models.item2inv
        # self.itdb_invoices = models.invoices
        self.raidinfo = models.Raidinfo
        self.metalinfo = models.Metalinfo
        self.diskinfo = models.Diskinfo
        self.lvsinfo = models.LVSInfo
        self.data = []
        self.index = {'extip':self.extip, 'public':self.public, 'offline':self.offline, 'crash':self.crash, 'itdb':self.itdb_items, 'repair':self.repair, 'maintain':self.maintain}

    def create(self, page, data, **kwargs):
        model = self.index[page]
        record = model()

        for (k, v) in data.items():
            if k in ['id', 'itemtypeid', 'manufacturerid', 'status', 'locationid', 'model']:
                continue
            elif 'date' in k:
                if type(v) is str:
                    v = int(time.mktime(time.strptime(v, "%Y-%m-%d")))
                setattr(record, k, v)
            elif 'time' in k:
                if type(v) is str:
                    v = int(time.mktime(time.strptime(v, "%Y-%m-%d %H:%M")))
                setattr(record, k, v)
            else:
                setattr(record, k, v)

        if page in ['repair', 'crash']:
            if self.public.select().where(self.public.主用IP == data['ip']).count() == None:
                recordex = (self.private
                            .select()
                            .where(self.private.主用IP == record.ip)
                            .dicts())
            else:
                recordex = (self.public
                            .select()
                            .where(self.public.主用IP == record.ip)
                            .dicts())
            taskid = tb.teambitionAPI().create(recordex, record, page, kwargs['tbuserid'])
            setattr(record, 'tbtaskid', taskid)
            setattr(record, 'tbtaskstate', 0)
            setattr(record, 'operator', kwargs['userid'])

        record.save()
        flash("添加成功!", "success")
        config.DBBackup()
    def update(self, page, id, data, **kwargs):

        model = self.index[page]
        record = model.get(model.id == id)
        for (k, v) in data.items():
            if k in ['id', 'itemtypeid', 'manufacturerid', 'status', 'locationid', 'model']:
                continue
            elif 'date' in k:
                if type(v) is str:
                    v = int(time.mktime(time.strptime(v, "%Y-%m-%d")))
                setattr(record, k, v)
            elif 'time' in k:
                if type(v) is str:
                    v = int(time.mktime(time.strptime(v, "%Y-%m-%d %H:%M")))
                setattr(record, k, v)
            else:
                setattr(record, k, v)

        if page in ['repair', 'crash']:
            if self.public.select().where(self.public.主用IP == record.ip).count() == None:
                recordex = (self.private
                            .select()
                            .where(self.private.主用IP == record.ip)
                            .dicts())
            else:
                recordex = (self.public
                            .select()
                            .where(self.public.主用IP == record.ip)
                            .dicts())
            try:
                tb.teambitionAPI().update(recordex, record, record.tbtaskid, page, kwargs['tbuserid'])
            except Exception as e:
                print(e)
            finally:
                pass

        '''ajax如何实现flash?'''
        try:
            setattr(record, 'operator', kwargs['userid'])
            record.save()
            config.DBBackup()
            flash("id:{}编辑成功!".format(id), "success")
        except Exception as e:
            print(e)
            flash("id:{}编辑失败!".format(id), "warning")
    def delete(self, page, id):

        model = self.index[page]
        record = model.get(model.id == id)

        if page in ['repair', 'crash']:
            taskid = model.select(model.tbtaskid).where(model.id == id).get()
            try:
                tb.teambitionAPI().delete(taskid.__dict__['_data']['tbtaskid'])
            except Exception as e:
                print(e)
            finally:
                pass

        try:
            record.delete_instance()
            config.DBBackup()
            flash("id:{}删除成功!".format(id), "success")
        except Exception as e:
            print(e)
            flash("id:{}删除失败!".format(id), "warning")
    def check(self, page, ip, qs, app):
        check_public = (self.public.select()
                        .where(((self.public.其它IP == ip) | (self.public.LVSIP == ip)) & (self.public.软件商.regexp(app)) & ~(self.public.券商.regexp(qs)))
                        .exists())
        check_offline = (self.offline.select()
                         .where((self.offline.对外服务IP == ip) & (self.offline.信息商.regexp(app)) & ~(self.offline.券商.regexp(qs)))
                         .exists())
        result = False if check_public or check_offline else True
        return result
    def mkpublic(self, state='(.*)'):
        records = (self.public.select()
                   .where(self.public.状态.regexp(state))
                   .dicts())
        for record in records:
            self.data.append(record)
        return self.data
    def mkoptions(self, type, qs, app, city):
        qslist, applist, citylist, cabinetlist = [], [], [], []

        if type == "云平台":
            model = self.public
            records = (model
                       .select(model.券商)
                       .where((model.服务类型 == '应用托管') & (model.状态 << ['上线', '券商试运行']) & ~(
            model.券商 << ['移动业务', '大智慧', '互联网技术部', '负载均衡', '信息公司', '钱龙资讯', '']))
                       .order_by(model.券商)
                       .distinct())
            for record in records:
                qslist.append(record.__dict__['_data']['券商'])
            records = (model
                       .select(model.软件商)
                       .where((model.券商.regexp(qs)) & (model.服务类型 == '应用托管') & (model.状态 << ['上线', '券商试运行']) & ~(
            model.券商 << ['移动业务', '大智慧', '互联网技术部', '负载均衡', '信息公司', '钱龙资讯', '']))
                       .order_by(model.软件商)
                       .distinct())
            for record in records:
                applist.append(record.__dict__['_data']['软件商'])
            records = (model
                       .select(model.地点)
                       .where((model.软件商.regexp(app)) & (model.券商.regexp(qs)) & (model.服务类型 == '应用托管') & (
            model.状态 << ['上线', '券商试运行']) & ~(model.券商 << ['移动业务', '大智慧', '互联网技术部', '负载均衡', '信息公司', '钱龙资讯', '']))
                       .order_by(model.地点)
                       .distinct())
            for record in records:
                citylist.append(record.__dict__['_data']['地点'])
            records = (model
                       .select(model.机柜号)
                       .where(
                (model.地点.regexp(city)) & (model.软件商.regexp(app)) & (model.券商.regexp(qs)) & (model.服务类型 == '应用托管') & (
                model.状态 << ['上线', '券商试运行']) & ~(model.券商 << ['移动业务', '大智慧', '互联网技术部', '负载均衡', '信息公司', '钱龙资讯', '']))
                       .order_by(model.机柜号)
                       .distinct())
            for record in records:
                cabinetlist.append(record.__dict__['_data']['机柜号'])

        elif type == "所有":
            model = self.public
            records = (model
                       .select(model.券商)
                       .where((model.状态 << ['上线', '券商试运行']) & ~(model.券商 << ['大智慧', '负载均衡', '钱龙资讯', '']) & (
            model.应用类型.contains('发布')) & (model.服务类型 != ''))
                       .order_by(model.券商)
                       .distinct())
            for record in records:
                qslist.append(record.__dict__['_data']['券商'])
            records = (model
                       .select(model.软件商)
                       .where(
                (model.券商.regexp(qs)) & (model.状态 << ['上线', '券商试运行']) & ~(model.券商 << ['大智慧', '负载均衡', '钱龙资讯', '']) & (
                model.应用类型.contains('发布')) & (model.服务类型 != ''))
                       .order_by(model.软件商)
                       .distinct())
            for record in records:
                if record.__dict__['_data']['软件商'] == '':
                    pass
                else:
                    applist.append(record.__dict__['_data']['软件商'])
            records = (model
                       .select(model.地点)
                       .where((model.软件商.regexp(app)) & (model.券商.regexp(qs)) & (model.状态 << ['上线', '券商试运行']) & ~(
            model.券商 << ['大智慧', '负载均衡', '钱龙资讯', '']) & (model.应用类型.contains('发布')) & (model.服务类型 != ''))
                       .order_by(model.地点)
                       .distinct())
            for record in records:
                citylist.append(record.__dict__['_data']['地点'])
            records = (model
                       .select(model.机柜号)
                       .where((model.地点.regexp(city)) & (model.软件商.regexp(app)) & (model.券商.regexp(qs)) & (
            model.状态 << ['上线', '券商试运行']) & ~(model.券商 << ['大智慧', '负载均衡', '钱龙资讯', '']) & (model.应用类型.contains('发布')) & (
                              model.服务类型 != ''))
                       .order_by(model.机柜号)
                       .distinct())
            for record in records:
                cabinetlist.append(record.__dict__['_data']['机柜号'])

        elif type == '私有云':
            model = self.private
            records = (model
                       .select(model.券商)
                       .where((model.状态 << ['上线', '券商试运行']) & (model.券商 != ''))
                       .order_by(model.券商)
                       .distinct())
            for record in records:
                qslist.append(record.__dict__['_data']['券商'])
            records = (model
                       .select(model.软件商)
                       .where((model.券商.regexp(qs)) & (model.状态 << ['上线', '券商试运行']) & (model.软件商 != ''))
                       .order_by(model.软件商)
                       .distinct())
            for record in records:
                applist.append(record.__dict__['_data']['软件商'])
            records = (model
                       .select(model.地点)
                       .where((model.软件商.regexp(app)) & (model.券商.regexp(qs)) & (model.状态 << ['上线', '券商试运行']))
                       .order_by(model.地点)
                       .distinct())
            for record in records:
                citylist.append(record.__dict__['_data']['地点'])
            records = (model
                       .select(model.机柜号)
                       .where((model.地点.regexp(city)) & (model.软件商.regexp(app)) & (model.券商.regexp(qs)) & (
            model.状态 << ['上线', '券商试运行']))
                       .order_by(model.机柜号)
                       .distinct())
            for record in records:
                cabinetlist.append(record.__dict__['_data']['机柜号'])

        elif type == '移动':
            model = self.public
            qslist.append('移动业务')
            records = (model
                       .select(model.软件商)
                       .where((model.券商 == '移动业务') & (model.服务类型 == '应用托管') & (model.状态 << ['上线', '券商试运行']))
                       .order_by(model.软件商)
                       .distinct())
            for record in records:
                applist.append(record.__dict__['_data']['软件商'])
            records = (model
                       .select(model.地点)
                       .where(
                (model.软件商.regexp(app)) & (model.券商 == '移动业务') & (model.服务类型 == '应用托管') & (model.状态 << ['上线', '券商试运行']))
                       .order_by(model.地点)
                       .distinct())
            for record in records:
                citylist.append(record.__dict__['_data']['地点'])
            records = (model
                       .select(model.机柜号)
                       .where(
                (model.地点.regexp(city)) & (model.软件商.regexp(app)) & (model.券商 == '移动业务') & (model.服务类型 == '应用托管') & (
                model.状态 << ['上线', '券商试运行']))
                       .order_by(model.机柜号)
                       .distinct())
            for record in records:
                cabinetlist.append(record.__dict__['_data']['机柜号'])

        elif type == 'MAAS':
            model = self.public
            qslist.append('互联网技术部')
            applist.append('行情服务')
            records = (model
                       .select(model.地点)
                       .where(
                (model.软件商 == '行情服务') & (model.券商 == '互联网技术部') & (model.服务类型 == '应用托管') & (model.状态 << ['上线', '券商试运行']))
                       .order_by(model.地点)
                       .distinct())
            for record in records:
                citylist.append(record.__dict__['_data']['地点'])
            records = (model
                       .select(model.机柜号)
                       .where(
                (model.地点.regexp(city)) & (model.软件商 == '行情服务') & (model.券商 == '互联网技术部') & (model.服务类型 == '应用托管') & (
                model.状态 << ['上线', '券商试运行']))
                       .order_by(model.机柜号)
                       .distinct())
            for record in records:
                cabinetlist.append(record.__dict__['_data']['机柜号'])

        self.data = [qslist, applist, citylist, cabinetlist]
        return self.data
    def mkextip(self):
        records = self.extip.select().dicts()

        for record in records:
            online = ''
            records_online = (self.public
                              .select(self.public.券商, self.public.软件商)
                              .where(self.public.LVSIP == record['对外服务IP'])
                              .distinct()
                              .dicts())
            for record1 in records_online:
                online = online + record1['券商'] + ':' + record1['软件商'] + '<br>'
            record['使用中'] = online if online else ''

            offline = ''
            records_offline = (self.offline
                               .select(self.offline.券商, self.offline.信息商)
                               .where((self.offline.对外服务IP == record['对外服务IP']) & (self.offline.备注 == '下线'))
                               .distinct()
                               .dicts())
            for record2 in records_offline:
                offline = offline + record2['券商'] + ':' + record2['信息商'] + '<br>'
            record['已下线'] = offline if offline else ''

            self.data.append(record)

        return self.data
    def mkcrash(self):
        records = self.crash.select().dicts()

        for record in records:
            if record['tbtaskstate'] == 0:
                if tb.teambitionAPI().isDone(record['tbtaskid']) is True:
                    tmp = self.crash.get(self.crash.id == record['id'])
                    setattr(tmp, 'tbtaskstate', 1)
                    tmp.save()

            records_qsapp = (self.public
                              .select(self.public.服务器名称, self.public.机器类型, self.public.券商, self.public.软件商)
                              .where(self.public.主用IP == record['ip'])
                              .dicts())

            for record_qsapp in records_qsapp:
                record['qs'] = record_qsapp['券商']
                record['app'] = record_qsapp['软件商']
                if record_qsapp['机器类型'] == '物理机':
                    record['hostip'] = record['ip']
                else:
                    hostname = ''
                    for i in record_qsapp['服务器名称'].strip().split('-')[0:3]:
                        if 'XJ' in i:
                            hostname = hostname + 'XJ-ES-'
                        else:
                            hostname = hostname + i + '-'
                    records_host = (self.public
                                    .select(self.public.主用IP)
                                    .where((self.public.服务器名称.contains(hostname.rstrip('-'))) & (self.public.机器类型 == '物理机'))
                                    .dicts())
                    for record_host in records_host:
                        record['hostip'] = record_host['主用IP']

            self.data.append(record)

        return self.data
    def mkrepair(self):
        records = self.repair.select().dicts()

        for record in records:
            if record['tbtaskstate'] == 0:
                if tb.teambitionAPI().isDone(record['tbtaskid']) is True:
                    tmp = self.repair.get(self.repair.id == record['id'])
                    setattr(tmp, 'tbtaskstate', 1)
                    tmp.save()

            records_qsapp = (self.public
                              .select(self.public.券商, self.public.软件商)
                              .where(self.public.主用IP == record['ip'])
                              .dicts())
            for record2 in records_qsapp:
                record['qs'] = record2['券商']
                record['app'] = record2['软件商']

            self.data.append(record)
        return self.data
    def mkmaintain(self):
        records = self.maintain.select().dicts()

        for record in records:
            records_vendormodel = (self.metal
                              .select(self.metal.品牌, self.metal.型号, self.metal.序列号, self.metal.地点, self.metal.机柜号)
                              .where(self.metal.主用IP == record['ip'])
                              .dicts())
            for record2 in records_vendormodel:
                record['vendor'] = record2['品牌']
                record['model'] = record2['型号']
                record['sn'] = record2['序列号']
                record['city'] = record2['地点'][1:]
                record['cabinet'] = record2['机柜号']

            self.data.append(record)
        return self.data
    def mkitdb(self):
        itemtypes, agents, status, locations = self.mkitdb_options()

        records = self.itdb_items.select().dicts()
        for record in records:
            if record['purchasedate'] is not None:
                deltamonths = int((int(time.mktime(datetime.date.today().timetuple())) - record['purchasedate']) / (24 * 60 * 60))
                warrantydays = record['warrantymonths']*30
                if record['warrantymonths'] is not None:
                    record['expired'] = 1 if (deltamonths > warrantydays) else 0
                else:
                    record['expired'] = 2
            else:
                record['expired'] = 2
            for (k, v) in record.items():
                if k == 'itemtypeid':
                    record[k] = itemtypes[v]
                elif k == 'manufacturerid':
                    record[k] = agents[v]
                #elif k == 'purchasedate':
                    #record[k] = time.strftime('%Y-%m-%d', time.localtime(v))
                elif k == 'status':
                    record[k] = status[v]
                elif k == 'locationid':
                    if v is None:
                        pass
                    else:
                        record[k] = locations[v]
                else:
                    continue
            self.data.append(record)
        return self.data
    def mkitdb_options(self):
        itemtypes = {}
        records = self.itdb_itemtypes.select().dicts()
        for record in records:
            itemtypes[record['id']] = record['typedesc']

        agents = {}
        records = self.itdb_agents.select().dicts()
        for record in records:
            agents[record['id']] = record['title']

        status = {}
        records = self.itdb_status.select().dicts()
        for record in records:
            status[record['id']] = record['statusdesc']

        locations = {}
        records = self.itdb_locations.select().dicts()
        for record in records:
            locations[record['id']] = record['name']

        self.data = [itemtypes, agents, status, locations]
        return self.data
    def mkraidinfo(self):
        records = (self.raidinfo.select(self.raidinfo, self.public.地点, self.public.机柜号, self.metalinfo.sn, self.metalinfo.vendor)
                       .join(self.public, JOIN.LEFT_OUTER, on=(self.public.主用IP == self.raidinfo.ip))
                       .join(self.metalinfo, JOIN.LEFT_OUTER, on=(self.metalinfo.ip == self.raidinfo.ip))
                       .dicts())
        for record in records:
            self.data.append(record)
        return self.data
    def mkdiskinfo(self):
        records = (self.diskinfo.select(self.diskinfo, self.public.地点, self.public.机柜号, self.metalinfo.sn, self.metalinfo.vendor)
                       .join(self.public, JOIN.LEFT_OUTER, on=(self.public.主用IP == self.diskinfo.ip))
                       .join(self.metalinfo, JOIN.LEFT_OUTER, on=(self.metalinfo.ip == self.diskinfo.ip))
                       .dicts())
        for record in records:
            if record['error'] in ['', 'Unknown']:
                record['state'] = 1
            else:
                record['state'] = 0
            self.data.append(record)
        return self.data
    def mkmetalinfo(self):
        records = (self.metalinfo.select(self.metalinfo, self.public.地点, self.public.机柜号)
                       .join(self.public, JOIN.LEFT_OUTER, on=(self.public.主用IP == self.metalinfo.ip))
                       .dicts())
        for record in records:
            self.data.append(record)
        return self.data

class LVS(object):

    def __init__(self):
        self.public = models.Public
        self.lvsinfo = models.LVSInfo
        self.lvs = models.LVS
        self.changelog = models.LVS_ChangeLog
        self.data = []

    def create(self, **kwargs):
        datas = analyze.run()
        date = int(time.time())
        for data in datas:
            for vs in data:
                ip = vs['ip']
                vsip = vs['vsip']
                vsport = vs['vsport']
                priority = vs['priority']
                persist_time = vs['persist_time'] if 'persist_time' in vs else 0
                for i in range(len(vs['rsip'])):
                    model = self.lvsinfo
                    record = model()
                    rsip = vs['rsip'][i]
                    rsport = vs['rsport'][i]
                    setattr(record, 'ip', ip)
                    setattr(record, 'priority', priority)
                    setattr(record, 'time', date)
                    setattr(record, 'vsip', vsip)
                    setattr(record, 'vsport', vsport)
                    setattr(record, 'persist_time', persist_time)
                    setattr(record, 'rsip', rsip)
                    setattr(record, 'rsport', rsport)
                    record.save()
    def update(self):
        datas = analyze.run()
        date = int(time.time())
        for data in datas:
            vs_new = []
            for vs in data:
                ip = vs['ip']
                vsip = vs['vsip']
                vsport = vs['vsport']
                vs_new.append(vsip+':'+str(vsport))
                vs.pop('ip')
                if 'persist_time' not in vs:
                    vs['persist_time'] = 0
                diff = self.compare(vs)
                if diff:
                    model = self.changelog
                    record = model()
                    setattr(record, 'ip', ip)
                    setattr(record, 'vsip', vsip)
                    setattr(record, 'vsport', vsport)
                    setattr(record, 'log', diff)
                    setattr(record, 'time', date)
                    record.save()
            results = self.compare2(ip, vs_new)
            for result in results:
                model = self.changelog
                record = model()
                setattr(record, 'ip', ip)
                setattr(record, 'vsip', result['vsip'])
                setattr(record, 'vsport', result['vsport'])
                setattr(record, 'log', result['diff'])
                setattr(record, 'time', date)
                record.save()
    def compare(self, log):
        diff = []
        # 判断新log是否新增vip
        flag = self.lvsinfo.getOne(self.lvsinfo.vsip == log['vsip'], self.lvsinfo.vsport == log['vsport'])
        if flag:
            rs_old, rs_new = [],[]
            records = (self.lvsinfo
                    .select(self.lvsinfo.persist_time, self.lvsinfo.rsip, self.lvsinfo.rsport)
                    .where((self.lvsinfo.vsip == log['vsip']) & (self.lvsinfo.vsport == log['vsport']))
                    .dicts())
            for record in records:
                persist_time = record['persist_time']
                rs_old.append(record['rsip'] + ':' + str(record['rsport']))
            # 判断新log是否修改persist_time
            if int(log['persist_time']) != persist_time:
                diff.append('保持连接从 %s 修改为 %s 秒' % (persist_time, log['persist_time']))
            # 判断新log是否修改rs
            for i in range(0, len(log['rsip'])):
                rs_new.append(log['rsip'][i] + ':' + str(log['rsport'][i]))
            rs_diff = list(set(rs_new).difference(set(rs_old)))
            for i in range(0, len(rs_diff)):
                diff.append('新增RealServer:%s' % rs_diff[i])
            rs_diff = list(set(rs_old).difference(set(rs_new)))
            for i in range(0, len(rs_diff)):
                diff.append('删除RealServer:%s' % rs_diff[i])
        else:
            diff.append('新增VirtualServer:%s:%s 保持连接:%s秒' % (log['vsip'],log['vsport'],log['persist_time']))
            for i in range(0, len(log['rsip'])):
                diff.append('新增RealServer:%s:%s' % (log['rsip'][i], log['rsport'][i]))
        return diff
    def compare2(self, ip, vs_new):
        result = {}
        # 判断新log是否删除vip
        vs_old = []
        records = (self.lvsinfo
                   .select(self.lvsinfo.vsip, self.lvsinfo.vsport)
                   .where(self.lvsinfo.ip == ip)
                   .dicts())
        for record in records:
            vs_old.append(record['vsip'] + ':' + str(record['vsport']))
        vs_diff = list(set(vs_old).difference(vs_new))
        for i in range(0, len(vs_diff)):
            diff = []
            diff.append('删除VirtualServer:%s' % vs_diff[i])
            vsip = vs_diff[i].split(':')[0]
            vsport = vs_diff[i].split(':')[1]
            records2 = (self.lvsinfo
                        .select(self.lvsinfo.rsip, self.lvsinfo.rsport)
                        .where((self.lvsinfo.vsip == vsip) & (self.lvsinfo.vsport == vsport))
                        .dicts())
            for record2 in records2:
                diff.append('删除RealServer:%s:%s' % (record2['rsip'], record2['rsport']))
            result['diff'] = diff
            result['vsip'] = vsip
            result['vsport'] = vsport
            yield result
    def alarm(self, **kwargs):
        records = (self.lvsinfo
                   .select(fn.COUNT(self.lvsinfo.rsip).alias('count'), self.lvsinfo.rsip, self.public.地点.alias('city'), self.public.机柜号.alias('cabinet'), self.public.软件商.alias('app'), self.public.券商.alias('qs'))
                   .join(self.public, JOIN.LEFT_OUTER, on=(self.public.主用IP == self.lvsinfo.rsip))
                   .group_by(self.lvsinfo.rsip)
                   .dicts())
        for record in records:
            # 检查RSIP个数是否为偶数
            if record['count'] % 2:
                record.pop('count')
                record['error'] = '主备遗漏'
                self.data.append(record)
            # 检查RSIP是否上线
            if record['app'] == '' and record['qs'] == '':
                record.pop('count')
                record['error'] = '已下线'
                self.data.append(record)
        records = (self.lvsinfo
                   .select(self.lvsinfo.rsip, self.lvsinfo.vsip, self.lvs.LVS虚拟IP.alias('vsip2'))
                   .join(self.lvs, JOIN.LEFT_OUTER, on=(self.lvs.虚拟服务器IP == self.lvsinfo.rsip))
                   .group_by(self.lvsinfo.rsip)
                   .dicts())
        for record in records:
            # 检查VIP是否正确
            if record['vsip'] != record['vsip2'] and record['vsip2'] != None:
                record['error'] = 'VIP错误'
                self.data.append(record)
        return self.data
    def treeview(self, qs='.*', app='.*', city='.*', cabinet='.*', priority=0):
        records = (self.lvsinfo
                   .select(self.lvsinfo.ip, self.public.地点.alias('city'), self.public.机柜号.alias('cabinet'))
                   .join(self.public, JOIN.LEFT_OUTER, on=(self.public.主用IP == self.lvsinfo.rsip))
                   .where((self.public.地点.regexp(city)) & (self.public.机柜号.regexp(cabinet)) & (self.public.券商.regexp(qs)) & (self.public.软件商.regexp(app)) & (self.lvsinfo.priority == priority))
                   .dicts()
                   .order_by(self.public.地点, self.public.机柜号)
                   .distinct())
        for record in records:
            grandparent = {}
            count = 0
            grandparent['text'] = record['ip']+' '+record['city']+record['cabinet']
            grandparent_nodes = []
            records2 = (self.lvsinfo
                        .select(self.lvsinfo.vsip, self.lvsinfo.vsport, self.lvsinfo.persist_time)
                        .join(self.public, JOIN.LEFT_OUTER, on=(self.public.主用IP == self.lvsinfo.rsip))
                        .where((self.lvsinfo.ip == record['ip']) & (self.public.地点.regexp(city)) & (self.public.机柜号.regexp(cabinet)) & (self.public.券商.regexp(qs)) & (self.public.软件商.regexp(app)))
                        .dicts()
                        .order_by(self.public.地点, self.public.机柜号)
                        .distinct())
            for record2 in records2:
                parent = {}
                count2 = 0
                parent['text'] = record2['vsip'] + ':%d' % record2['vsport'] + ' 保持连接:%d秒' % record2['persist_time']
                child_nodes = []
                records3 = (self.lvsinfo.select(self.lvsinfo.rsip, self.lvsinfo.rsport, self.public.券商.alias('qs'), self.public.软件商.alias('app'))
                            .join(self.public, JOIN.LEFT_OUTER, on=(self.public.主用IP == self.lvsinfo.rsip))
                            .where((self.lvsinfo.vsip == record2['vsip']) & (self.lvsinfo.vsport == record2['vsport']) & (self.public.地点.regexp(city)) & (self.public.机柜号.regexp(cabinet)) & (self.public.券商.regexp(qs)) & (self.public.软件商.regexp(app)))
                            .dicts()
                            .order_by(self.public.地点, self.public.机柜号)
                            .distinct())
                for record3 in records3:
                    child = {}
                    count2 = count2 + 1
                    child['text'] = record3['rsip'] + ':%d' % record3['rsport'] + ' ' + record3['qs'] + ' ' + record3['app']
                    child_nodes.append(child)
                parent['nodes'] = child_nodes
                parent['tags'] = [count2]
                count = count + count2
                grandparent_nodes.append(parent)
            grandparent['nodes'] = grandparent_nodes
            grandparent['tags'] = [count]
            self.data.append(grandparent)
        return self.data