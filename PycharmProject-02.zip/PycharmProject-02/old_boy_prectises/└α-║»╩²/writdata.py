#!/usr/bin/env python
#coding:utf-8
#author:hlw

import requests,re,os
import xml.etree.ElementTree as ET

def login():
	s = requests.session()
	user = 'huangliwu'
	passwd = 'huangliwu'
	url = 'http://114.80.155.57:6925/magicflu/rlogin'
	data = {'j_username':user,'j_password':passwd}
	try:
		req=s.post(url=url,data=data)
	except:
		print 'Login error!'
	else:
		return s

hostinfos = [{'jiguihao':'F1','zhuyongip':'10.131.79.30','fuwuqimingcheng':'SH-TG-F1-ZF1','quanshang':''},{'jiguihao':'F1','zhuyongip':'10.131.79.30','fuwuqimingcheng':'TG-F1-ZF1-VM1'}]

def checkout(hostinfo):
	url = 'http://114.80.155.57:6925/magicflu/service/s/857eedd4-29bb-4547-b1fb-31efdf7deaef/forms/ea781514-1a9c-4105-b37a-f0c2e5953f33/records/feed?start=0&limit=10'
	hostinfo1 = {y:x for x,y in hostinfo.items()}
	req = requests.get(url)
	res = req.text.encode('utf-8')
	os.remove('record.xml')
	with open('record.xml','w') as f:
		f.write(res)
	tree = ET.parse('record.xml')
	root = tree.getroot()
	compareinfo = {}
	for x in root:
		for y in x:
			if y.tag == 'id':
				recordid = y.text
			for i in y:
				compare = []
				recordinfo = [ n.text for n in i]
				if hostinfo['fuwuqimingcheng'] in recordinfo:
					for m in hostinfo1.keys():
						if m in recordinfo:
							pass
						else:
							field = hostinfo1[m]
							compare.append(field)
				compareinfo[recordid] = compare
	return compareinfo

def writedata(hostinfo):
	url = 'http://114.80.155.57:6925/magicflu/service/s/857eedd4-29bb-4547-b1fb-31efdf7deaef/forms/ea781514-1a9c-4105-b37a-f0c2e5953f33/records/'
	for x,n in checkout(hostinfo).items():
		if checkout(hostinfo)[x]:
			url = url + x
			req = requests.get(url)
			res = req.text.encode('utf-8')
			with open('record.xml','w') as f:
				f.write(res)
			tree = ET.parse('record.xml')
			root = tree.getroot()
			for x in root:
				for y in x:
					for z in y:
						if z.tag in n:
							z.text = hostinfo[z.tag]
						z.set('updated','yes')
				if x.tag == 'totalCount':
					root.remove(x)
			tree.write('record.xml')
			with open('record.xml','r') as f:
				data = f.read()
				#re1 = re.compile(r'./?feed.')
				#rs1 = re1.sub('',data)
				rs1 = data.replace(r'./?feed.','')
			req1 = login().put(url,rs1)
			print req1.text

def logout():
	user = 'huangliwu'
	passwd = 'huangliwu'
	url = 'http://114.80.155.57:6925/magicflu/rlogout'
	data = {'j_username':user,'j_password':passwd}
	try:
		req=requests.post(url=url,data=data)
	except:
		print 'Logout error!'

def main():
	for hostinfo in hostinfos:
		checkout(hostinfo)
		writedata(hostinfo)
		logout()


if __name__ == '__main__':
	main()
