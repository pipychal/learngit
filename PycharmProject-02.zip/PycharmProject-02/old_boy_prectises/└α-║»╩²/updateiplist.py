from peewee import (Model, SqliteDatabase, CharField, IntegerField,
                    SmallIntegerField, ForeignKeyField, Check,
                    OperationalError, DoesNotExist)
import os,time,re

# DATABASE = SqliteDatabase('/home/mds/ssedb/sse.db',threadlocals=True,
DATABASE = SqliteDatabase('D:\pytmp\sse.db',threadlocals=True,
                          pragmas=(
                              ('synchronous', 'off'),
                              ('journal_mode', 'WAL'),
                              ('cache_size', 10000),
                              ('mmap_size', 1024 * 1024 * 32)))
							  
class BaseModel(Model):
    class Meta:
        database = DATABASE
        order_by = ('-id',)

    @classmethod
    def getOne(cls, *query, **kwargs):
       # 为了方便使用，新增此接口，查询不到返回None，而不抛出异常
       try:
          return cls.get(*query, **kwargs)
       except DoesNotExist:
           return None
		   
class Metal(BaseModel):
    """资产统计表"""
    fields_all = (
        'id',
        '地点',
        '机柜号',
        '主用IP',
        '服务器标签',
        '品牌',
        '型号',
        '序列号',
        '生产日期'
    )

    地点 = CharField(null=True)
    机柜号 = CharField(null=True)
    主用IP = CharField(null=True)
    服务器标签 = CharField()
    品牌 = CharField()
    型号 = CharField()
    序列号 = CharField()
    生产日期 = CharField()
	
	
class Public(BaseModel):
    """行情总表"""
    fields_all = (
        'id',
        '地点',
        '机柜号',
        '主用IP',
        '其它IP',
        '服务器名称',
        '券商',
        '软件商',
        '状态',
        '应用类型',
        '对外类型',
        'LVSIP',
        '行情站名称',
        '机器类型',
        '操作系统',
        '虚拟OS类型',
        '虚拟机配置',
        '服务类型'
    )

    地点 = CharField(null=True)
    机柜号 = CharField(null=True)
    主用IP = CharField(null=True)
    其它IP = CharField()
    服务器名称 = CharField(null=True)
    券商 = CharField()
    软件商 = CharField()
    状态 = CharField()
    应用类型 = CharField()
    对外类型 = CharField()
    LVSIP = CharField()
    行情站名称 = CharField()
    机器类型 = CharField()
    操作系统 = CharField()
    虚拟OS类型 = CharField()
    虚拟机配置 = CharField()
    服务类型 = CharField()
    机器类型标记 = CharField()
    应用类型标记 = CharField()
    服务类型标记 = CharField()
    服务端口 = CharField()
    地点标记 = CharField()
    状态标记 = CharField()
    券商标记 = CharField()
    信息商标记 = CharField()
    业务标记 = CharField()


def mkiplist():
    model = Public
    metalinfo = Metal
    Ctime = time.strftime("%Y-%m-%d")

    records = (model.select(model.地点.alias('city'), model.机柜号.alias('cabinet'), model.服务器名称.alias('name'), model.主用IP.alias('ip'), model.券商.alias('qs'), model.软件商.alias('app'), model.应用类型.alias('type'), model.操作系统.alias('system'), model.应用类型标记.alias('typeflag'), model.地点标记.alias('cityflag'), model.信息商标记.alias('appflag'))
               .where(~(model.地点 == 'Z全真') & ~(model.服务类型 == '资源租用') & ~(model.券商 << ['移动业务']) & ~(model.软件商 << ['大智慧沪港通','行情服务','汇点','钱龙资讯','同花顺手机L2','同花顺资讯','同花顺副行情']) & (model.机器类型 == '虚拟机') & (model.状态 << ['上线', '券商试运行']) & (model.应用类型 == '发布'))
               .dicts())
    records2 =  (model.select(model.地点.alias('city'), model.主用IP.alias('ip'), model.地点标记.alias('cityflag'), model.机柜号.alias('cabinet'), model.服务器名称.alias('name'))
               .where(~(model.地点 == 'Z全真') & (model.机器类型 == '虚拟机') & (model.状态 << ['上线', '券商试运行','测试']) & (model.软件商 << ['Audit']))
               .dicts())
    
	#生成auditip/proxyip(10.131.79.62	9988	A1:SH1)
    for record2 in records2:
        print(record2['ip'],record2['cityflag'],record2['cabinet'])
        # # print(record2['cabinet'][-1])
        # shenjicity = record2['cabinet'] + ':' + record2['cityflag'][:2] + record2['cabinet'][-1]
        # # print(shenjicity)
        # if record2['city'][1:] =='金桥':
        #     ip = '10.132.26.149'
        # elif record2['city'][1:] =='上海' and record2['cabinet'] == 'C11':
        #     ip = '10.131.79.62'
        # elif record2['city'][1:] =='上海' and record2['cabinet'] == 'C12':
        #     ip = '10.132.14.62'
        # elif record2['city'][1:] =='云桥' and record2['cabinet'] == 'C1,C2':
        #     ip = '10.132.46.22'
        # elif record2['city'][1:] =='全真' and record2['cabinet'] == 'F0':
        #     ip = '10.131.1.97'
        # else:
        #     ip = record2['ip']
        # with open('D:\pytmp\iplist\shenjiaudit' + Ctime +'.txt', 'a') as f:
        #     f.write(ip + '	9988	' + shenjicity + '	' + record2['cityflag'][:2] + record2['cabinet'] + "\n")
        #     f.close()
	
    #生成iplist.txt(只要发布&不需要全真&不需要大智慧沪港通/行情服务/汇点/钱龙资讯/同花顺手机L2/同花顺资讯/同花顺副行情)
    # for record in records:
    #     # with open('D:\pytmp\iplisttest.txt', 'a') as f:
    #     #     f.write(record['ip'] + ' ' + record['qs'] + ' ' + record['app'] + "\n")
    #     #     f.close()
    #     ip = record['ip']
    #     for record2 in records2:
    #     	if record2['city'][1:] =='金桥':
    #     		auditip = '10.132.26.149'
    #     	elif record2['city'][1:] =='上海' and record2['cabinet'] == 'C11':
    #     		auditip = '10.131.79.62'
    #     	elif record2['city'][1:] =='上海' and record2['cabinet'] == 'C12':
    #     		auditip = '10.132.14.62'
    #     	elif record2['city'][1:] =='云桥' and record2['cabinet'] == 'C1,C2':
    #     		auditip = '10.132.46.22'
    #     	elif record2['city'][1:] =='全真' and record2['cabinet'] == 'F0':
    #     		auditip = '10.131.1.97'
    #     	else:
    #     		auditip = record2['ip']
    #     with open('D:\pytmp\iplist\iplist.txt', 'a') as f:
    #         f.write(record['cityflag'][:2] + record['cabinet'] + "\t" + ip + "\n")
    #         f.close()

    # f = open('D:\pytmp\shenjiaudit' + Ctime +'.txt','r')
    # for line in open('D:\pytmp\shenjiaudit' + Ctime +'.txt'):
    #     citycabinet = re.split('[\n\t]',f.readline())[3]
    #     # print(citycabinet)
    #     f2 = open('D:\pytmp\iplist.txt','r')
    #     for line2 in open('D:\pytmp\iplist.txt'):
    #         if re.split('[\n\t]',f2.readline())[0] == citycabinet:
    #             with open('D:\pytmp\iplist\iplist_' + citycabinet + '.txt', 'a') as f3:
    #                 f3.write(re.split('[\n\t]',f2.readline())[1] + "\n")
    #             f3.close()

	# #分发，可以放在生成文件后
	# ansible -i $globalpath/inventory/hosts4sys citycabinet -m copy -a "src=iplist_citycabinet.txt dest=/mds/iplist.txt mode=0600"
mkiplist()
