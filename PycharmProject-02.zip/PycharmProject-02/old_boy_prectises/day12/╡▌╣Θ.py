#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:
# 递归注意问题又三个：
#   1：明确的结束条件
#   2：问题规模每递归一次都应该比上一次的问题规模有所减少
#   3：效率相对低下
def calc(n):
    print(n)
    return calc(n/2)