#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
###该脚本有个缺陷；等于56，这个没问题； 输入的数字小于56，则只有三次输出，这个也没问题，符合设计；
###但是 输入的数字 大于56 ，则一直重复提示输出，输入 3 次以上并没有中断循环而退出，而是一直重复提示输出。需要改进。
age_of_oldboy = 56

count = 0
while count <3:                            #（1） 输入的次数 小于 3 次
     guess_age = int(input("guess age:")) # 定义 输入的变量且为整数类型 ；变量的名称为 guess_age
     if guess_age == age_of_oldboy :       # 如果  输入的变量( guess_age )  等于 设定号的变量 ( age_of_oldboy 为 56 )
         print("yes, you got it. ")          # 则 打印出 yes,you got it.
         break                                  # 正确则 破坏循环 退出循环
     elif guess_age > age_of_oldboy:      # 再如果 输入的变量( guess_age )  大于 设定号的变量 ( age_of_oldboy 为 56 )
         print("think smaller...")           # 则 打印出think smaller...
     else:                                # 再如果呢，以上两个条件都不满足；
         print("think bigger...")            # 那么就打印 think bigger...
     count = count +1                     # 累计加上 1  ；直至到 3 次
else:
    print("you have tried too many times...")