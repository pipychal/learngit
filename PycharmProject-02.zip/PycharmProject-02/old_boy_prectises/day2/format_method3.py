#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date: 2017/02/13

# 该脚本是为了格式化输出；需要两大步骤：1 定义变量 ； 2 引用占位符，格式化输出
# 赋值给变量；其值默认是 字符串类型 ，即 str

# 1：定义变量
name = input("please input your name:")
age = int(input("how old are you:"))      # int()  ：表示整数类型  ；age 变量在这儿表示：这个age变量用整数类型
                                                 # 把 这个结果 raw_input("how old are you:")  传输给 这个方法 int() ;强行定义 age 变量的类型；py是强类型语言 ；int 是 integer 的缩写
print(type(age))                                # 打印 age 这个变量的类型；看个人习惯；可打印也可以不打印  【 如果想再转义成 str 类型；可以在打印时候转义 :如： print(type(age) ,type( str(age) )) 】

sex = input("please input your sex:")
dep = input("which department:")

# 2：引用变量格式化输出；其中需要到占位符 %s  ; % (name,age,sex,dep) 最后这个引用变量不可少（变量和引用变量一一对应）  ：% (变量1,变量2,变量3,变量4)
#把以上几个变量放到 message 这个变量中；并格式化输出
# %s 即 %string  的简写 ；字符串类型
# %d 即 %digital 的简写 ；整数类型
message = ''' Infomatione of the company staff:
        Name: %s
        Age : %d
        Sex : %s
        Dep : %s
        '''% (name,age,sex,dep)
print(message)