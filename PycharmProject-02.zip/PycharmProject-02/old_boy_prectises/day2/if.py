#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
import getpass          # 导入 getpass 密文传输 这个模块;在 pycharm 里不好使。在windows 下才可。

_username = 'alex'              # 1 存用户名和密码 ；给 2 用
_password = 'abc123'
username = input("username:")
password = getpass.getpass("password:")

if _username == username and _password == password:        # 2  判断 用户名和密码 输入是否对；那么先存用户名和密码； 判断最后必须 “冒号” 结束
    print("Welcome user {name} login......".format(name=username))
else:         # 也要 写上“冒号” 结束
    print("Invalid username or password")
print("nihao")