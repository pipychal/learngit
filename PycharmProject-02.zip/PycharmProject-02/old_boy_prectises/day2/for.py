#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
'''
for i in range(10):           #  range(10)  表示循环十次 ；每循环一次就给 i 赋予一个变量值 ；从 0 到 9
    print("loop",i)
'''
# 简单的 for 循环
'''
age_of_oldboy = 56
for i in range(3):
     guess_age = int(input("guess age:"))
     if guess_age == age_of_oldboy :
         print("yes, you got it. ")
         break
     elif guess_age > age_of_oldboy:
         print("think smaller...")
     else:
         print("think bigger...")
else:
    print("you have tried too many times..")
'''

#for i in range(10):
#    print("loop",i)

#for i in range(1,10,2):    # 在 10 之内，从 1 开始打印，隔 2 位数 打印一次
#    print("loop",i)

for i in range(1,10,3):    # 在 10 之内，从 1 开始打印，隔 3 位数 打印一次
    print("loop",i)