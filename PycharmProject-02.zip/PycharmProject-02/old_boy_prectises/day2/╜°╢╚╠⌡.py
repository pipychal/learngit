#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
import sys,time
for i in range(50):                 # 循环打印 标准输出的 50个 # 号
     sys.stdout.write("#")          # 等缓存区域满了之后统一打印出来，但是我们为了快速看到这个效果，就循环一次就刷新一次缓存
     sys.stdout.flush()             # 刷新缓存
     time.sleep(0.2)                # 间隔 0.2 秒刷新一次缓存，直到把要打印的 # ；打印完毕。