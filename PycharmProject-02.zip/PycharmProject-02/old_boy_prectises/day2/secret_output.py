#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
import getpass                    # getpass 在pycharm不好使
username = input("username:")
password = input("password:")

print(username,password)