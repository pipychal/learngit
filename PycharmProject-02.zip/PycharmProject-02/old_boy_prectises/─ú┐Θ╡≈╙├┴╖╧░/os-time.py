#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:

### **** 主旨：把 path所指向的“文件”或者“目录”的“最后（存取时间）和（修改时间）”；这里是指 D:\a 目录下的 client.txt 文件 最后修改所生成的时间戳
###          转换成 “格式化的字符串”格式 ，如：2017-09:19 16:52:02
###          time 模块各个时间转换的流程； 1 ）这个时间戳是 字符串  --> 转成  2 ）这个时间是 struct_time(tuple) --> 再转换成 3 )  格式化的字符串

### 时间转换顺序和格式详细看如下链接   http://egon09.blog.51cto.com/9161406/1840425

import time,datetime,os,sys
at=os.path.getatime(r'D:\a\client.txt')
# print(at)
mt=os.path.getmtime(r'D:\a\client.txt')         # 这个时间戳是 字符串
#print(mt)

mtzhgt=time.gmtime(mt)                               # 这个时间是 struct_time(tuple)
atzhgt=time.gmtime(at)
#zhmkt=time.mktime(mt)     #  staticme 转换为字符串
mtzhstrft=time.strftime("%Y-%m:%d %H:%M:%S",mtzhgt) # 这个时间是 格式化的字符串
atzhstrft=time.strftime("%Y-%m:%d %H:%M:%S",atzhgt) # 这个时间是 格式化的字符串
#print(zhmt)
#print('this is %d day:'%zhlt.tm_year)
# ### 换成 既有年 又有月 又有日
#print(zhmkt)
print(atzhstrft)
print(mtzhstrft)