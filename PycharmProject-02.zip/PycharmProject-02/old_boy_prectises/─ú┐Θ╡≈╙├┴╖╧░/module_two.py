#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
name = 'lisi'
def say_hi_lisi():
    print("come on lisi")
say_hi_lisi()


def s1():
    pass
def d1():
    pass