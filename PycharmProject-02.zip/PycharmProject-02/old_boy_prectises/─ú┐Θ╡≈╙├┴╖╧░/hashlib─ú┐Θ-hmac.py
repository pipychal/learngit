#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
import hashlib,hmac

### 给一个文件 生产一个 md5  ####
# h = hmac.new(b'天王盖地虎', b'宝塔镇河妖')  ；内容一定要用 二进制 b
# ------------------------
# m = hashlib.md5()
# m.update(b"hello world")
# print(m.hexdigest())
# ------------------------
# m.update(b"It's me")
# print(m.hexdigest)
# ------------------------
#

h = hmac.new(b'天王盖地虎', b'宝塔镇河妖')
print(h.digest())
print(h.hexdigest())