#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
## （一）一个模块里单种方法， 多个模块，用“逗号隔开”
## （二）一个模块里多种方法,多种变量， 多个模块，用“逗号隔开”

# import module_one,module_two                   ### （一）一个模块里单种方法 多个模块，用“逗号隔开”
# from module_one import *                      ### 从 module_one 的所有方法和变量都倒入进来；不太好用,肯定有问题的
from module_one import name,logger
# from module_one import logger as logger_one   ### 从 模块（module_one）导入该模块的 logger 函数，并给其另起一个别名 logger_one

# one = module_one.name        # 导入(调用)变量：另一个py 脚本module_one 的 name 变量
# print(one)
# one2 = module_one.say_hi_zhangsan()   # 导入(调用)方法：另一个py 脚本module_one 的 say_hi() 方法 ; 模块名.方法
# print(one,one2)

# def logger():
#     print("in the main")
# logger()
# logger_one()
#print(name)
logger()
