#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
import time,datetime


## ================================= time =================================
x=time.gmtime()
y=time.localtime()
x1=time.time()
# print(help(x))        # 打印 time.gmtime() 的方法
#x.tm_year
# print(x)
# print(y)
# print(x1)
###  得到的结果是：time.struct_time(tm_year=2017, tm_mon=9, tm_mday=19, tm_hour=6, tm_min=36, tm_sec=25, tm_wday=1, tm_yday=262, tm_isdst=0)
# print(x.tm_year)        # 取 time.gmtime() 中的 “年”
# print(x.tm_mon)          # 取 time.gmtime() 中的 “月”
#.....
# z=x.tm_year
# print(z)
# print("This is 1973 day:%d" %x.tm_min)
##################################
# xx=time.mktime(x)
# print(xx)
# print(time.strftime("%Y-%m:%d %H:%M:%S",x))     #  得到结果为 ： 2017-09:19 07:18:00
# print(time.strptime('2017-09:19 07:18:00',"%Y-%m:%d %H:%M:%S"))
#help(time)
#print(time.clock())
print(time.asctime())       # time.asctime()  展示本地时间；得到的结果为 Tue Sep 19 16:04:57 2017
print(time.ctime())

## ================================= datetime =================================