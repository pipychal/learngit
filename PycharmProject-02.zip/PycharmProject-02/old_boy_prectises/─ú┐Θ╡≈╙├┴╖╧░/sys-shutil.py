#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
import sys,shutil,os

# print(sys.maxint)
# print(sys.exit())
# print(sys.argv)
# print(sys.maxint)
# print(sys.maxint)
# print(sys.maxint)
# print(sys.maxint)
# print(sys.maxint)

# f1 = open("笔记1","w",encoding="utf-8")
# f2 = open("笔记2","w",encoding="utf-8")
shutil.make_archive("ceshi2","tar",root_dir="D:\communication tool\code bag\Pycharm\untitled1\homework",base_dir="D:\tdx\tdxvim_UT")