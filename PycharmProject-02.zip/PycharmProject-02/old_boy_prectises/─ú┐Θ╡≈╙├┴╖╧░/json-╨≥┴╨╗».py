#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
import json


####   序列化   #####
info = {
    'name':'alex',
    'age':'20'
}
f = open("test.txt","rb")
f.read( json.dumps(info) )       # 序 列 化：把数据存储到文件里
f.close()


### #  序列化   #####
# info = {
#     'name':'alex',
#     'age':'20'
# }
# f = open("test.txt","r")
# datacz = json.loads(f.read())       # 反序列化：把数据重载回来
# print(datacz['age'])