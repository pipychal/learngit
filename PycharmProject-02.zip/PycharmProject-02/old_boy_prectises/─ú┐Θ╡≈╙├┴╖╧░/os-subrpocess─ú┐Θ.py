#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
import subprocess,os

### subprocess 主要是调用 linux 的 shell ;   对 os.system  和  os.spawn* 模块的替换。

# res = os.system('dir')         # 1）os.system() 返回执行的结果 o 或者 1
# print(res)

# ress = os.popen('dir').read()  # 2）os.popen().read()返回执行命令具体的结果的状态；没有返回返回值
# print(ress)

resss = subprocess.
