#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:

####  shutil  来压缩整个目录   ####
import shutil,zipfile,tarfile
shutil.make_archive("company_py","tar",root_dir="D:\communication tool\code bag\Pycharm\untitled1")

####  zipfile  来压缩整个具体的几个文件   ####
# z = zipfile.ZipFile("linshizip","w")
# z.write("time_datetime.py")
# print("-================-")
# z.write("__init__.py")
# z.close()