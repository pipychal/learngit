#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
### 用于序列化与反序列化的两个模块
import json,pickle,shelve,datetime

d = shelve.open('shelve_test')  # 打开一个文件

info = {"alex","rain","test"}
name = ["alex", "rain", "test"]
#
# d["name"] = name  # 持久化列表
# d["info"] = info  # 持久化 dict （字典）
# d['date'] = datetime.datetime.now()
#
# d.close()

print(d.get("name"))
print(d.get("info"))
print(d.get("date"))