#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
import ConfigParser

# 暂且不看，用到再看 ansible , saltstack  所用的格式是 yaml
# ConfigParser 使用的地方是 nginx  , mysql
# 方便自己他人用和解析
### ConfigParser 在 py2 里是大写  ；   在 py3 里是小写configparser

import ConfigParser

config = ConfigParser.ConfigParser()