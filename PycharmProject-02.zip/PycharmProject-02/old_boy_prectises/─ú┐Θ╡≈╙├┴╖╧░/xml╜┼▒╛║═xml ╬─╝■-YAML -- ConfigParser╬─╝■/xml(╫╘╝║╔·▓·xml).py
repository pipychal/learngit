#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
### pycharm 有个缺点，生成xml 之后就没有分开分行，全部写到一行；这样不好。
###  生成的 xml ；存放到　test.xml　文件里

import xml.etree.ElementTree as ET

new_xml = ET.Element("namelist")
name1 = ET.SubElement(new_xml, "zhangsan", attrib={"enrolled": "yes"})
age = ET.SubElement(name1, "age", attrib={"checked": "no"})
sex = ET.SubElement(name1, "sex")
age.text = '33'
sex.text = 'male'
name2 = ET.SubElement(new_xml, "lisi", attrib={"enrolled": "no"})
age2 = ET.SubElement(name2, "age2")
sex2 = ET.SubElement(name1, "sex2")
age2.text = '19'
sex2.text = 'female'
et = ET.ElementTree(new_xml)                                    # 生成文档对象
et.write("test.xml", encoding="utf-8", xml_declaration=True)  # 声明我是 xml 格式的  xml_declaration=True

ET.dump(new_xml)                            # 打印生成的格式  ；