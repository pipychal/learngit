#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
#  xml  ; 老系统一直用这个 xml 接口；
#  python 处理 xml　　　；　　变量.text　　：表示写入该值
import xml.etree.ElementTree as ET

tree = ET.parse("xmltest.xml")
root = tree.getroot()
# print(root)                         # 打印的是所对应目标的内存地址，这不是我们想要的
#print(root.tag)

# 1）. 历遍 xml  文档  ; 对 xmltest.xml  这个 xml 文本处理。
# for child in root:
#     print(child.tag,child.attrib)
#     for i in child:
#         print(i.tag,i.text)
#
# # 2）. 只历遍 year 节点； .set
# for node in root.iter('year'):
#     print(node.tag,node.text)
#
# # 3）. 对 某部分内容 进行修改   .iter  方法，以及延伸方法不太清楚用，可以看源码
# for node in root.iter('year'):
#     new_year = int(node.text) + 1
#     node.text = str(new_year)
#     node.set("updated_by","yes")
# tree.write("xmltest-2.xml")


# 4）.------------------把 country 字样，删除 rank 大于50 的部分，然后把删除后，文件剩下的内容写到 output.xml 文件-------------------
# for country in root.findall('country'):           # 第一层是  country
#     rank = int(country.find('rank').text)         # 第二层是  rank
#     if rank > 50:
#         root.remove(country)
# tree.write('output.xml')


#------------------ 对这个 sztemplate.xml 文件进行处理 ;还没写完----------------
# for child in root2:
#     print(child.tag,child.attrib)
#     for i in child:
#         print(i.tag,i.text)
#
# for node in root2.iter('template'):
#     print(node.tag,node.text)
