#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
#### 默认是 二进制模式 读写 rb , wb

import pickle

### #  序列化   #####
info = {
    'name':'alex',
    'age':'20'
}
f = open("test2.txt","wb")
data = pickle.dumps()     # 反序列化：把数据重载回来
# print(data['age'])