#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:
import random,os

# print(random.random)
#print(help(random))
print(os.getcwd())
# print(os.chdir("D:\install_program_bag"))
# print(os.curdir)
# print(os.pardir)
# print(os.makedirs(r"D:\a\f\e"))         # 创建目录
#print(os.removedirs(r"D:\a"))         # 创建目录
print(os.)