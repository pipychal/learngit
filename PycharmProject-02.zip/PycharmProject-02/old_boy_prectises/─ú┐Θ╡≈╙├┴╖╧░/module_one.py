#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
import sys,os
DIR_D = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(DIR_D)

import package_test

# name = 'zhangsan'
# # def say_hi_zhangsan():
# #     print("come on zhangsan")
# # say_hi_zhangsan()
# #
# # def s():
# #     pass
# # def d():
# #     pass
# def logger():
#     print("in the module_one")
# logger()