#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
# date :2017-02-22   20:36
# 集合是一个"无序的"，不重复的数据组合，它的主要作用如下：
#              1 ：去重，把一个列表变成集合，就自动去重了
#              2 ：关系测试，测试两组数据之前的交集、差集、并集等关系

#-------------------------------------------------------------------------------------------------
#              1 ：去重，把一个列表变成集合，就自动去重了
#list_1 = [1,4,5,7,3,6,7,9]       # list_1  是列表
#list_1 = set(list_1)             # 把 list_1 变成 集合（在列表前 加 set() ）；然后就可以达到去重的目的。
#print(list_1)                    # 打印这个列表；“重复的值 7 ” 就被去掉了
#print(type(list_1),list_1)       # 打印“这个列表的类型” 以及 “列表本身”；“重复的值 7 ” 就被去掉了

# ================================================================================================
#              2 ：关系测试，测试两组数据之前的交集、差集、并集等关系
list1 = [1,4,5,7,3,6,7,9]           # 这 list1 和 list2 都是“列表”  列表用“中括号”括起来。
list2 = [11,4,23,7,3,6,7,19]        #
list3 = [1,4,5]
list4 = [6,7,8]
list1 = set([1,4,5,7,3,6,7,9])      # 用 set() ; 把 list1 这个“列表” 变成了 “集合”
list2 = set([11,4,23,7,3,6,7,19])   # 用 set() ; 把 list2 这个“列表” 变成了 “集合”
list3 = set(list3)
list4 = set([6,7,8])
list5 = set([1,2,3])
#print(list_1,list_2)

# 1 交集 ；两者集合的 共同部分 ======== intersection() ======== & ===========
# 方法  1 ：
# intersection()
#list1.intersection(list2)           # 求 list1 和 list2  这两个集合的交集；表示方式：  集合1.intersection(集合2)
#print(list2.intersection(list1))    # 打印 两个集合list1 和 list2 的交集。
# 方法 2 ：    &
#list = list1 & list2
#print(list)

# 2 并集 ；两者集合的 不同部分  ======== union() ======== | =========== 去重但也展示，重复只展示一次======
# 方法  1 ：
#list1.union(list2)                  # 求 list1 和 list2  这两个集合的交集；表示方式：  集合1.union(集合2)
#print(list1.union(list2))           # 打印 两个集合list1 和 list2 的并集。
# 方法  2 ：
#list = list1 | list2
#print(list)
# 3 差集 ；两个集合；======== difference() ========  -  ===========   某个集合 list1 相对于另一个集合 list2 来说；list1 有哪些不同
# 方法  1 ：
#list1.difference(list2)
#print(list1.difference(list2))      # 在 list1 集合中；相对于list2 有哪些不同
#print(list2.difference(list1))      # 在 list2 集合中；相对于list1 有哪些不同
# 方法  2 ：
#list = list1 - list2                # 求差集（项在 list1 中，但不 list2 中）
#print(list)
#list = list2 - list1                # 求差集（项在 list2 中，但不在 list1 中）
#print(list)
# 4 对称差集 ==（去掉交集）== (也叫反向差集)======== symmetric_difference() ========  ^  =========== （项在list1 或 list2 中，但不会同时出现在二者中）互相都没有的都展示出来
# 方法  1 ：
#print(list1.symmetric_difference(list2))
# 方法  2 ：
#list = list1 ^ list2
#print(list)
# 5 子集   ( list3 属于 list1 )
# 方法 1
#print(list3.issubset(list1))       # 集合 list3 是 集合 list1 的子集 【 对 则返回 True ; 错 则返回 False 】
#print(list1.issubset(list2))
# 方法 2
#list3 <= list1
# 6 父集  list1 包含 list3
# 方法 1 ：
#print(list1.issuperset(list2))     # 集合 list1 是 集合 list2 的父集 【 对 则返回 True ; 错 则返回 False 】
# 方法 2 ：
#  list1 >= list3
# 7 ================= isdisjoint() ===========无交集；则返回 True ====有交集则返回 False ======
print(list3.isdisjoint(list4))      # list3 和 list4 无交集；则返回     True
print(list3.isdisjoint(list5))      # list3 和 list5 有一个交集；有交集则返回 False

###  8  ### 基本操作

# 添加 使用 add() ;
list1.add('333')             # 添加一项
list1.update([10, 37, 42])    # 在 list1 集合中中添加多项

# 删除,使用remove()   ；可以删除一项：
#list1.remove('H')
#print(list1.remove('ddd'))      # remove() 删除 列表里没有的值；则会报错
print(list1.discard('ddd'))     # discard() 删除 列表里没有的值；也不会报错
# 查看 集合的长度
len(list1)                    # set 的长度

#  判断 某个值 是否 在某某集合里；也就是说某个值是否是该集合的成员。

#  x in list1        # 测试 x 是否是 s 的成员
#  x not in list1   # 测试 x 是否不是 s 的成员

# 浅复制
list1.copy()     # 返回 set “s”的一个浅复制