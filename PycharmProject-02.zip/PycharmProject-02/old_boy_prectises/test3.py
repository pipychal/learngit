#!/usr/bin/env python
#_*_ coding:utf-8 _*_


# 从文件中读取数据到map中
def get_data_to_map():
    hotel_dict = {}
    with open('hotel.txt', 'r') as f:
        for line in f.readlines():
            res = line.split('\t')
            current_value = 1
            if res[0] in hotel_dict:
                current_value = hotel_dict[res[0]] + 1
            hotel_dict[res[0]] = current_value
    return hotel_dict


# 对map中的数据进行排序
def map_soft(hotel_dict):
    soft_hotel_dict = sorted(hotel_dict.iteritems(), lambda x, y: cmp(x[1], y[1]))
    return soft_hotel_dict


# 输出排序的数据
def show_soft_result(result_list):
    for item in result_list:
        print item[0], item[1]


if __name__ == '__main__':
    hotel_dict = get_data_to_map()
    result_list = map_soft(hotel_dict)
    show_soft_result(result_list)