#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:
#  写很多网站；一个网站代表一个函数。有三个页面，每个页面都需要登录才可以写东西和发帖
# 列出三个函数； auth 函数作为装饰器；
import time

user,passwd = 'alex','abc123'

def auth(func):
    def wrapper(*args,**kwargs):
        username = input("Username:").strip()
        password = input("Password:").strip()

        if user == username and passwd == password:
            print("\033[32:1mUser passwd authentication\033[0m")
            func(*args,**kwargs)
        else:
            exit("\033[31:1mInvalid username or password\033[0m")
    return wrapper

def index():
    pass

@auth
def home():
    pass

@auth
def bbs():
    pass

index()
home()
bbs()
