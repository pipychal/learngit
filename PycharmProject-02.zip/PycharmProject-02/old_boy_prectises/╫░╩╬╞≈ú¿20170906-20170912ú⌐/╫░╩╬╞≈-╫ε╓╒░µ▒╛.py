#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:
import time
user,passwd = 'alex','abc123'

### （一）装饰函数
def auth(auth_type):
    print("auth func:",auth_type)       # 打印 auth_type 的变量返回值；确定具体是那个参数传递
    def outer_wrapper(func):
        def wrapper(*args, **kwargs):
            print("warpper func args:"*args, **kwargs)     # 打印 wrapper 的变量返回值；确定具体是那个参数传递
            if auth_type == "local":
                username = input("Username:").strip()
                password = input("Password:").strip()
                if user == username and passwd == password:
                    print("\033[32;1mUser passwd authentication\033[0m")
                    res = func(*args, **kwargs)  # 把以下调用的函数(可以是 index ,home bbs 其中任意一个)赋值个 ret 变量
                    print("---after authenticaion--- ")
                    return res
                else:
                    exit("\033[31;1mInvalid username or password\033[0m")
            elif auth_type == "ldap":
                print("这是ldap")
        return wrapper          ### 这个在 warpper 函数之后；必须 return wrapper
    return outer_wrapper        ### 这个在 outer_warpper 函数之后；必须 return outer_wrapper

### （二）被装饰函数 index   home   bbs   ;  和装饰三个函数 ：index   home   bbs
@auth()
def index():
    print("welcome to index page")
    pass

@auth(auth_type="local")        ###  在装饰的时候给“位置参数” auth_type="local
def home():
    print("welcome to home page")
    return "from home"
    pass

@auth(auth_type="ldap")         ###  在装饰的时候给“位置参数” auth_type="ldap
def bbs():
    pass

### （三） 调用，执行三个函数  index   home   bbs ；也就调用和执行装饰函数的代码逻辑
index()                         ### 调用 index 相当于调用 wrapper
home()                          ### 调用 home  相当于调用 wrapper
bbs()                           ### 调用 bbs 相当于调用