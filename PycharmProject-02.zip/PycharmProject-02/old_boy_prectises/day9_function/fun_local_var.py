#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date: 2017-02-23

###( 一 )  全局变量  ####    当外面和里边也有个同名的全局变量的时候，还可以勉强使用。
#school = "oldboy edu"

### （二） 局部变量  #### 在外部不可调用。 name 是局部变量。 同名变量也无所谓，局部变量只可以在内部调用。
#def change_name(name):
#    school = "mage"                     # 这里的 school 变量是 “局部变量”
#    print("before change",name,school)  # 函数之外的 school 是全局变量；内部的函数可以直接调用。
#    name = "qq"                         # 局部变量 是 name ； 这个函数 change_name 就是这个变量的作用域
#    print("after change",name)
#change_name(name='dd')

#name = "qinwang"
#change_name(name)
#print(name,school)

## ****** ### 把局部变量 强行 改成 全局变量。  最好别用。。。建议最好别用。。。不应该在函数里定义全局变量。  *******
##   不然等到程序量大的时候，调用这个函数也很多的时候；就会导致全局变量 经常改变 ；逻辑就会相当混乱；难以维护。
##   举个例子：把“局部变量”变成 “全局变量”
#def change_name(name):
#    global school               #  把“局部变量” 改成 “全局变量” 必须声明一下 ； global
#    school = "mage"
#    print("before change",name,school)  # school 是全局变量；内部的函数可以直接调用。
#    name = "qq"                     # 局部变量 是 name ； 这个函数 change_name 就是这个变量的作用域
#    print("after change",name)
#change_name(name='dd')

#name = "qinwang"
#change_name(name)
#print(name,school)


### 整数，字符串 这两种情况下；局部变量不可以修改全局变量的。
### 集合，列表，字典 ，包括 类 ；这些情况下，局部变量 是可以 修改全部变量的值的。

school = "lodboy edu"
names = ["Alex","Jack","Rain"]
def change_name():
    print(names)
    names[0] = "金角大王"
    print("inside func",names)
change_name()
print(names)