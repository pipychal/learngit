#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date: 2017-03-03

###（一）： 函数的 return          return 之后的命令是不会被输出了。！！！！！！！！！！！！！！！
#  总结要点：
# 1.0   返回值 =0 ；返回 None
# 1.0   返回值 =1 ；返回 Object
# 1.0   返回值 >1 ；返回 tuple (元组)
# 为啥要有返回值；就是  要返回这个 “函数” 整个执行的结果 状态 ；以便于 后面程序的调用；当这个函数执行的结果为 True 或者 False 的时候；可以给后面的程序直接依据上一个函数的结果作为条件。。
###################################  1  return  ####################################
########  1.0  #########
#def test():
#    return 0
########  1.1  #########
#def test1():                    # define a function  as test1
#    print('in the test1')
#    return 0                   # 这是一个返回值；其返回值也可以自定义。返回值之后；的任何命令都不会输出了
#test1()                         # execute the function test1

########  1.2  #########
#def test1():                    # define a function  as test1
#    print('in the test1')
#    return 0
#    print('in the end')      # 返回值；返回值可以自定义。返回值之后任何命令都不会输出 例如 print('in the end') 不会输出
#test1()

###################################  2  return  something ####################################
########  2.0  #########   没有 return  默认返回 None
#def test1():
#    print('in the test1')
#test1()

########  2.1  #########    return 0
#def test2():
#    print('in the test2')
#    return 0                    # return 0
#test2()

########  2.2  #########    return 数字，字符串，列表，字典 ，元组；你可以返回很多值，但解释器默认把这一堆数字，字符串，列表，字典，元组 放到“一个元组”里返回
#def test3():
#    print('in the test3')
#    return 1,'hello',['zhangsan','lisi'],{'name':'zhangsan'},(2,3)
#test3()

#x=test1()
#y=test2()
#z=test3()
#print(x)
#print(y)
#print(z)

###（二）： 函数的 “形参” 和 “实参”
# 总结 ：
#    函数类型：
#       1：“形参” 只要你自己的程序不调用这个函数，那么形参就 不会占内存空间
#          “实参” 实际占内存空间
#	    2：“位置  参数”     一一对应关系 ；不可多，也不可少（形参和实参）
#	    3：“关键字参数”    不一一对应…灵活性  x=1  y=12  等等的形式
#       4：  同时有 “关键字参数”和“位置参数”的时候；  《 位置参数 必须在 关键字参数 之前。切记 》
#	    4：“默认函数参数” ；如软件安装，有默认安装，就是这么用的。（其实“默认参数” 也等同于 “关键字参数”）

########  1  ######### “形参” 和 “实参”
#def test(x,y):          # x 和 y 是形参；不占内存空间
#    print(x)
#    print(y)
#test(1,3)               # 1  2    是实参；实际占内存空间

#def test(x,y):
#    print(x)
#    print(y)
#x=1
#y=2
#test(y=y,x=x)
#test(x,y)
#test(y,x)
#test(4,y=2)

########  2  ######### “位置  参数”
#def test(x,y):
#    print(x)
#    print(y)
#x=1
#y=2
#test(y=y,x=x)
#test(x,y)
#test(y,x)
#test(4,2)

########  3  ######### “关键字 参数” 例子  #test(y=y,x=x)
#def test(x,y):
#    print(x)
#    print(y)
#x=1
#y=2
#test(y=y,x=x)
#test(x=4,y=2)

########  4  ######### 即有 “关键字 参数” 也有 “位置 参数” 调用；这个时候，解释器默认按照 “位置参数”来读取
#def test(x,y,z):
#    print(x)
#    print(y)
#    print(z)
#test(y=y,x=x)
#test(4,y=2,z=2)             # 这个表达是 正确 的      理由 ：《 位置参数 必须在 关键字参数 之前。切记 》
#test(4,y=2,3)               # 这个表达是 错误 的      理由 ：《 位置参数 必须在 关键字参数 之前。切记 》

########  5  ######### “默认函数参数”####
def test(x,y=3):
    print(x)
    print(y)
test(1)



'''
def test1():
    print('in the test1')
    return 0,1,'hello'
test1()

########  2.1  #########    return 0
def test2():
    print('in the test2')
    return test1()                    # return 0
test2()

def stu_register(name, age, country, course):
    print("----注册学生信息------")
    print("姓名:", name)
    print("age:", age)
    print("国籍:", country)
    print("课程:", course)


#stu_register("王山炮", 22, "CN", "python_devops")
#stu_register("张叫春", 21, "CN", "linux")
#stu_register("刘老根", 25, "CN", "linux")

#def stu_register(name,age,*args):
#    print(name,age,args)
#stu_register("qw",18)
#stu_register("Jack",32,"CN","Python")

#def stu_register(name,age,*args,**kwargs):
#    print(name,age,args.kwargs)
#stu_register("PP",22)
#stu_register("Jack",32,"CN","Python",sex="Male",province="ShanDong")

# change name   argument
name = "PP"
def change_name(name):
    print("before change:",name)
    name = "QQ"
    print("after name:",name)
change_name(name)
print(name)
'''

