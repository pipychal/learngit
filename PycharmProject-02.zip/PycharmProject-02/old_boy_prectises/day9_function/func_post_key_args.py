#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP

#   函数类型：
#   	1：“位置  参数”     一一对应关系
#	    2：“关键字参数”   不一一对应…灵活性 x=2  y=3  等等。
#	    3：“默认函数参数”在 “形参”里设置

#######################  （ 一 ） ####### 实参传一个 字符串或者 列表  def test(x,*args)

#def test(x,y,z=2):     # 形参设置的 默认参数， z=2
#    print(x)
#    print(y)
#    print(z)
#test(1,2)           # 调用这个 test 函数；实参只是 1 2 ；z 这个形参无需设置实参也可以
#test(2,3,4)         # x y z 三个形参 分别设置为 2  3  4 ；就连 默认设置的形参参数 z=2 都被 4替代

### 多个形参对应多个实参的用法 ;即参数组
# 方法 一 ：方法比较low
#def test(x,y,z,a,b):
#    print(x)
#    print(y)
#    print(z)
#    print(a)
#    print(b)
#test(1,2,3,4,5)

# 方法 二 ：常用方法。该用法包含 *  和  args  两个部分 ; *args 这种方法只能接收列表或者元组；但不能接收 “字典”
#   *kwargs ：把 Ｎ　个“位置参数”，转换成　“元组”的方式。只接收“位置参数”；如若没有赋值给它；那么它就是空的元组
#           * 表示可以传很多值；或者说任意值
#           args 是参数的表示方法   ；  * 和 args 缺一不可。
#def test(*args):
#    print(args)
#test(1,2,3,4,5,6)       # 直接写　；传很多值
#test(*[1,2,3,4,5,6])    # 　＊　和　一个列表的传值

# 方法 三 ：你在定义一个函数的时候并不知道自己要传多少个参数，业务扩大；需要传的参数也多了；为了不修改源代码，所以用这个方式可以这么表达
#def test(x,*args):
#    print(x)          # 打印第一个形参的位置参数
#    print(args)       # 打印第二个至 N 个
#test(1,2,3,4,5,6,7,8) # 实参 1 赋值给 x  ；实参 2 3 4 5 6 7 8 赋值给args

#######################  （ 二 ） ####### 实参传
# 一个 字典 def test(x,**kwargs)
#   **kwargs ：把 Ｎ　个“关键字参数”，转换成　“字典”的方式。只接收“关键字参数”
#def test(**kwargs):
#    print(kwargs)
#test(name='alex',age=8,sex='Male')     # name='alex'  是关键字参数
#test(**{'name':'alex','age':8,'sex':'M'})

#   x,**kwargs ：把 Ｎ　个“关键字参数”，转换成　“字典”的方式。
#   和未知参数结合；
#def test(name,age=18,**kwargs):     # 定义的默认参数 ; 位置参数 必须在 关键字参数 之前。
#def test(name,**kwargs):
#    print(x)
#    print(kwargs)
#test('alex',age=8,sex='Male')     # 位置参数和关键字参数同时存在的时候；位置参数一定要在关键字参数之前。
#test(age=8,sex='Male'.'alex')     # 这个是错误的示范：位置参数必须在关键字参数之前才对。

#def test(name,age=18,**kwargs):   # 默认参数赋值 age=18
#    print(name)
#    print(age)
#    print(kwargs)
#    test('pp',)
#test('pp',sex='m',hobby='tesla',age=3)  # 这样是可行的。
#test('pp',23,hobby='tesla',age=3)     # 这样是不行的。实参 23 和 3 都传给了 形参 age ；违反了形参和实参一一对应的关系。

############33###   *args   和   **args 一起使用
#def test(name,age=18,*args,**kwargs):   # 默认参数赋值 age=18
#    print(name)
#    print(age)
#    print(args)
#    print(kwargs)
#test('pp',age=34,sex='m',hobby='tesla')

#def test1(name,age=18,*args,**kwargs):   # 默认参数赋值 age=18
#    print(name)
#    print(age)
#    print(args)
#    print(kwargs)
#    logger(test1)

#def logger(source):
#    print("from %s" % source)

#test1('pp', age=34, sex='m', hobby='tesla')



