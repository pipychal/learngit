#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP

# 变量可以指向函数，函数的参数能接收变量，那么一个函数就可以接收另一个函数作为参数，这种函数就称之为高阶函数。
#def add(x, y, f):
#    return f(x) + f(y)

#res = add(3, -6, abs)
#print(res)
###  1   这是普通的函数；还没把函数当做参数来传递给另一个函数；下面的第 2 个例子就是 高阶函数。
#def add(a,b):
#    print(a,b)
#    return 0
#add(1,5)

### 2   高阶函数 ；  Alex 也没用到； 所以日后自己可能用到。不是很重要。用到了再查。
def add(a,b,f):
    return f(a)+(b)
res = add(3,-6,abs)
print(res)