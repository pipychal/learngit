#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
# 字符编码的详解：
# 在 Unicode 里 英文和中文都只是占了 2 个字符（字节）也就是 16 位
# 在 ASCII 码 不能存中文；只能存英文或者特殊字符；为了存中文 所以出现了 Unicode
# 原来 一个英文在 ASCII 码只是 占了 1 个字节
# utf-8 是 Unicode 的扩展集；
#  utf-8 是可变长；可伸缩的形式字符编码；所有的英文字符都还是以 ASCII 码形式来存
#                                        所有的中文字符 统一是  三个字节。
# GBK ？
#python3默认字符编码unicode
#    备注：字符编码必须搞清楚…不然，写里面的代码还得折腾
#	ASCII码只能存英文，一个字母占一个字节；不可以存中文
#	GBK     存7000  多中文字
#	gb1830  存10000 多中午字
#	GB2312  存20000 多中文
#	为了整个各国的各种文字，出现了unicode  一个中文2个字节，1个英文1字节，那么一个我2M的英文文档就占了4M空间，这样就会浪费了2M的空间；
#	为了解决这个空间浪费的问题，又弄出了个unicode的扩展集utf-8；
#	在这里1个英文字母占一个字节，一个中文字占两个三个字节，互不干扰，1M英文文档还是1M .就解决了空间浪费的问题了
#import sys                                    # 引入 sys 模块。
#print(sys.getdefaultencoding())               # 引入这个sys 模块 打印自己工具环境的字符编码。

#s = "你好"                                     # 这个默认是 utf-8
#print(s)
#s_to_gbk = s.encode("utf-8").decode("gbk")    # 想转成GBK ；那么先声明自己的是啥字符集；再转成想要的字符编码。
                                                # 把 utf-8 转换成 GBK
#print(s_to_gbk)

# python2  and  python3   python3 默认的编码是 unicode ； 文件头声明的程序的编码是文件编码，和程序本身的编码不一致


import sys                                    # 引入 sys 模块。
print(sys.getdefaultencoding())               # 引入这个sys 模块 打印自己工具环境的字符编码。
s = "你好"                                     # 这个默认是 utf-8
print(s)
print(s.encode("utf-8"))                  # 这里是我们把 utf-8 转换成了 gbk
print(s.encode("gbk"))                    #
print(s.encode("gb2312"))                 #
print(s.encode("utf-8").decode("gbk"))   # 这里是我们把 utf-8 转换成了 gbk

