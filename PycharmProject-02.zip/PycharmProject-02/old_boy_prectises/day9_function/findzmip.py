#!/usr/bin/env python
# -*- coding: utf-8 -*  -
import re,sys,os
from xlrd import *
from ftplib import FTP
iplist = []
if not os.path.exists("iplist.txt"):
       print("iplist.txt not found")
       exit(1)
with open('iplist.txt','r') as ipl:
       for ipline in ipl:
              ipline = ipline.strip('\n')
              iplist.append(ipline)
def showColValue(row,iplistline,flag):
       infoFileName = str(iplistline) + ".txt"
       infoFile = open(infoFileName,"a")
       if flag == 'Z':
              s_list = [1,2,3,4,6,7,8,9,12,17]
              for i in s_list:
                     print(sh_list[row][i],end=' ')
                     infoFile.write(sh_list[row][i] + ' ')
              print('')
              infoFile.write('\n')
       elif flag == 'V':
              s_list = [0,2,4,6,7,8]
              for i in s_list:
                     urow = row
                     while True:
                            if sh_lvs_list[urow][i] != '':
                                   print(sh_lvs_list[urow][i],end=' ')
                                   infoFile.write(sh_lvs_list[urow][i] + ' ')
                                   break
                            else:
                                   urow = urow - 1
              print('')
              infoFile.write('\n')
       else:
              print ("showColValue Error")
              exit(1)
       infoFile.close()
def searchZFrow(row,iplistline):
       for v_row in range(nrows):
              try:
                     if sh_list[v_row].index(sh_list[row][1]):
                            if sh_list[v_row].index(sh_list[row][2]):
                                   if len(sh_list[row][7]) > 3:
                                         xinxishang = sh_list[row][7][0] + sh_list[row][7][1] + sh_list[row][7][2]
                                   else:
                                          xinxishang = sh_list[row][7]
                                   try:
                                          if sh_list[v_row].index(xinxishang):
                                                 if sh_list[v_row].index('转发'):
                                                        showColValue(v_row,iplistline,'Z')
                                   except ValueError:
                                          pass
                                   try:
                                          if sh_list[v_row].index(str(xinxishang) + "V5"):
                                                 if sh_list[v_row].index('转发'):
                                                        showColValue(v_row,iplistline,'Z')
                                   except ValueError:
                                          pass
                                   try:
                                          if sh_list[v_row].index(str(xinxishang) + "经典版"):
                                                 if sh_list[v_row].index('转发'):
                                                        showColValue(v_row,iplistline,'Z')
                                   except ValueError:
                                          pass
                                   if sh_list[v_row].index(str(xinxishang) + "新一代"):
                                          if sh_list[v_row].index('转发'):
                                                 showColValue(v_row,iplistline,'Z')
              except ValueError:
                     pass
sh = open_workbook(r'D:\SVNroot\Project\MDS运维\16 配置管理流程\IP地址表\00行情站点资源分配总表.xls').sheet_by_index(0)
sh_lvs = open_workbook(r'D:\SVNroot\Project\MDS运维\16 配置管理流程\IP地址表\00行情站点资源分配总表.xls').sheet_by_index(1)
ncols,nrows = sh.ncols,sh.nrows
lvs_ncols,lvs_nrows = sh_lvs.ncols,sh_lvs.nrows
sh_list = [[0 for clist in range(ncols)] for rlist in range(nrows)]
sh_lvs_list = [[0 for lvs_clist in range(lvs_ncols)] for lvs_rlist in range(lvs_nrows)]
for irowlist in range(nrows):
       for icollist in range(ncols):
              sh_list[irowlist][icollist] = sh.cell_value(irowlist,icollist)
for lvs_irowlist in range(lvs_nrows):
       for lvs_icollist in range(lvs_ncols):
              sh_lvs_list[lvs_irowlist][lvs_icollist] = sh_lvs.cell_value(lvs_irowlist,lvs_icollist)
for iplistline in iplist:
       for v_row in range(nrows):
              try:
                     if sh_list[v_row].index(iplistline):
                            showColValue(v_row,iplistline,'Z')
                            searchZFrow(v_row,iplistline)
                            break
              except ValueError:
                     pass
       for lvs_v_row in range(lvs_nrows):
              try:
                     if sh_lvs_list[lvs_v_row].index(iplistline):
                            showColValue(lvs_v_row,iplistline,'V')
                            break
              except ValueError:
                     pass
ftp = FTP()
if ftp.connect("114.80.155.43",7710):
       ftp.login("sysop","SsePwd&123")
       ftp.cwd("sysop/lzp")
       for iplistlinefile in iplist:
              infoFileName = str(iplistlinefile) + ".txt"
              if os.path.exists(infoFileName):
                     ftp.storbinary('STOR ' + infoFileName,open(infoFileName,"rb"))
       ftp.close()
else:
       print("ftp connnect faild")
       exit(1)
