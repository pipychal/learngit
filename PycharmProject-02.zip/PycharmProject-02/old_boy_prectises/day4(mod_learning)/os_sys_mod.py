#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
# 2017-02-15
# 调用第三方模块（可以是自己写的；也可以是别人写的）
# 计算机是不能够识别高级语言的，所以当我们运行一个高级语言程序的时候，就需要一个“翻译机”来从事把高级语言转变成计算机能读懂的机器语言的过程。
# 这个过程分成两类，第一种是编译，第二种是解释。编译型语言在程序执行之前，先会通过编译器对程序执行一个编译的过程，把程序转变成机器语言。
# 运行时就不需要翻译，而直接执行就可以了。最典型的例子就是C语言。
import os,sys           #  执行之后就会产生一个 login.pyc 这个文件；这个是做了编译的动作；解释给机器来读。

# os 这个调用系统的操作系统的命令 os.system  ; 而其括号内的双引号内是：执行的命令 dir 是windows 下的命令
# os.system("dir") ；os.system() 这个表示执行命令；只打印到屏幕，但不保存结果

cmd_res = os.system("dir")   # 把 os.system("dir") 存入变量 cmdz-res 里
cmd_res = os.popen("dir")
#print("--->",cmd_res)       # 打印这个 变量 cmd_res    ；得出的状态是 0 表示这个命令是正确的
#os.mkdir(new)    # 创建 new 目录

# name = "alex"
# print("i am %s " % name)

# sys 系统调用模块；这里我们讲的是：打印系统的环境变量
# python sys.py 1 2 3
print(sys.path)  # 打印系统的环境变量
#print(sys.argv[2])   #取出这个列表中的某个字段;列表里的字段默认从 0 开始 ...1.2.3...这里表示的取出第三个字段。