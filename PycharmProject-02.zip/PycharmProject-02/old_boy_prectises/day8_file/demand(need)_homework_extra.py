#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
# 程序 1  ：实现简单的 shell  sed 替换功能
# 程序 2  ：修改 haproxy 配置文件。  用第一个程序作业即可实现。  作业内容在day2 里

