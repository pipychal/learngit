#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date: 2017-02-23
#    对文件操作流程：
#	    1：打开文件，得到文件句柄并赋值给一个变量  （内存对象）
#	    2：通过句柄对文件进行操作
#	    3：关闭文件

## 打开文件自动放歌 ##  需求；自己 去玩

# 打开文件的模式有：
# =============(一)============= r  w  a  + =================================
#   r，只读模式（默认）。
#   w，只写模式。【不可读；不存在则创建；存在则删除内容；】
#   a，追加模式。【可读；   不存在则创建；存在则只追加内容；】
#   "+" 表示可以同时读写某个文件
# =============(二)============= r+  w+  a+ U =================================
#   r+，可读写文件。【可读；可写；可追加】    # 常用方法；读 然后 追加写入
#   w+，写读                                  # 不常用方法：写（就创建了一个新的文件）；再读，好像没啥意思；所以不常用
#   a+，同a
#   "U"表示在读取时，可以将 \r \n \r\n自动转换成 \n （与 r 或 r+ 模式同使用）
# =============(三)============= rU  r+U  "b"  rb  wb  ab =================================
# Python2.X 二进制和字符串可以相互调用 ；但是呢 Python3.X 以上 二进制就是二进制  ； 字符串就是字符串
#   rU
#   r+U
#   "b"表示处理二进制文件（如：FTP发送上传ISO镜像文件，linux可忽略，windows处理二进制文件时需标注）
#   rb        二进制读  用处：1：网络传输的时候  ；
#   wb        二进制写  用处：1：
#   ab
# =============(四)============= with 语句 =================================
# with语句   ；为了避免打开文件后忘记关闭，可以通过管理上下文，即：
# with open('log', 'r') as f:  如此方式，当with代码块执行完毕时，内部会自动关闭并释放文件资源。
# 在Python 2.7  ；后，with又支持同时对多个文件的上下文进行管理，即：
# with open('log1') as obj1, open('log2') as obj2:
#    pass
#   --------========================-------------======================----------------------=====
# =============(一)============= r  w  a  + =================================
# # #  1  # # # 来个不符合文件开关的操作例子。
#data = open("yesterday",encoding="utf-8").read()        # 告诉程序；你要用 utf-8 打开这个文件
#data = open("yesterday").read()                        # # 现在我的系统某人 utf-8 ；所以不需要指定编码格式 encoding="utf-8"
#print(data)
#print ("Python 是一个非常棒的语言，不是吗？")       # # 随便的打印一段文字

# # #  2  # # # 标准文件开关的流程  “读” “写”；写的时候要注意，以防 空白 覆盖 原有的内容。
#f = open("yesterday",'r',encoding="utf-8")       #  “只读” 的方式。写只能是 “只写” 的方式
#f = open("yesterday1",'w',encoding="utf-8")      # 'r' 必须放在文件之后。 'w' 写是创建新的文件；注意：别在原有的文件上写；要不然其内容会被空内容覆盖。
                                        #  实际上，打开这个文件的同时，把“这个文件的内存里的文件对象的‘地址’” (也叫“句柄”)赋值给 “变量f”
#f = open("yesterday2",'a',encoding="utf-8")      # 只是 “追加” 'a' 等同于 append
#data = f.readline()                   # 再赋值 "读文件" 给 "变量data" ； 一行一行的读，读完毕后，光标就放在最后一行的末尾。
#data = f.read()                       # 读取剩下的所有内容,文件大时不要用
#print(data)                           # 打印文件
#f.write("我爱北京天安门，东方之星\n")             # 把 写里的内容 "我爱北京天安门" "东方之星"  写到 yesterday1 新文件里  \n  就是换行输出。
#f.write("你好，这个世界，我来了.你们都还好么")   # 把这个 "你好，这个世界，我来了.你们都还好么" 追加都 yesterday1 里
#f.close()                             # 关闭文件  ；别忘记文件的关闭。也无需报存。

# =============(二)============= r+  w+  a+ U =================================
# =============(三)============= rU  r+U  "b"  rb  wb  ab =================================

# =============(四)============= with 语句 =================================

#   # 读 多 行 的几种表达方法
# 方法 1
#f = open("yesterday3",'r',encoding="utf-8")
#print(f.readline())                             # 读 3 行 ；
#print(f.readline())
#print(f.readline())
# 方法 2
#for i in range(3):
#    print(f.readline())

# 全文格式化输出：
# 方法 1   给 变量 用  strop()  方法；把空格和换行都去掉。。。。。。
#f = open("yesterday3",'r',encoding="utf-8")
#for line in f.readlines():      # 判断 line 这个变量在 f.readlines() 里
#   print(line)                  # 打印 变量 line   (系统默认有换行符 \n) ；如果想把换行符给去掉 给这个 line 变量用 strop() 方式
#   print(line.strip())
# 方法 2   等同   方法 1
#f = open("yesterday3",'r',encoding="utf-8")
#data = f.read()
#print(data)

# 全文格式化输出：到第十行 ；读到内存里；这样量大 会很慢。
#  方法 1 ：f.readlines()    只适合读取 首文件 。不适合读取大文件。      --- low 方法。
#  也可以 用 f.readline()  一行一行读；但是也是不适合读取大文件。
# = open("yesterday3",'r',encoding="utf-8")
#or index,line in cnumerate(f.readlines()):
#   if index == 9:
#       print('-----分割线-------')
#       continue
#   print(line.strip())

#  方法 2 ：(  计数器； ) 循环一行就删除一行 ；内存里就留下 一行；这样就不会撑爆内存  --- high 方法。
#  计数器；
# = open("yesterday3",'r',encoding="utf-8")
#for ling in f:
#   print(line)

count = 0
f = open("yesterday3",'r',encoding="utf-8")
for line in f:
    if count == 9:
        print('---------------------分割线-----------------------')
        count +=1               # 必不可少 ； 在其 continue 前  + 1
        continue
    print(line)
    count +=1                   # 必不可少 ； 结束之后也 + 1
f.close()                       # 关闭文件 这一步必不可少。。。 切记别忘记了。。。

# 二进制模式，就不能被读写。打印会出错。
#with open("yesterday2",'rb',encoding="utf-8") as f:
# f = open("yesterday2",'rb',encoding="utf-8")
#print(f.readlines())



# 用二进制写入。原文件就会被清空且重新写入。
#f = open("yesterday2",'wb')
#f.write("hello binary\n".encode())
#f.close()


#for i in range(1,33):
#    print(i)
