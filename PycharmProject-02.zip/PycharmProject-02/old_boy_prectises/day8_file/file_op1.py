#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
# date :2017-02-23  23:27
# 一行代码不应该超过 80 个字符。
# python 读完整个文本之后，光标就到文本末尾了；但我想把光标再次提到前面怎么处理呢？如下：

########### 1 ####### open() readline()  readlines()  tell()  seek()  close() ############## 1 ######

#f = open("yesterday3",'r',encoding="utf-8")    # 用 utf-8 编码 打开文件
#print(f.tell())                                   # 打开指针的位置在哪儿。
#print(f.readline())      # f.readline()表示读取文件的行数 “一行” 或者 “多行”f.readlines()
#print(f.readlines())    # f.readlines() 表示把整个文本都读取出来。
#print(f.read(5))        # f.read()    表示读取文件的字符个数 ；f.read(5)表示读取 f 文件的前五个字符
#print(f.tell())          # f.tell() 表示 判断上面有几个 N 行 有几个字符。.f.tell() 的括号内不能有任何参数！！！
#f.seek(0)               # f.seek(N) ：f.seek() 表示，光标回到某位置  ；f.seek(0) 表示光标回答开头的位置。
                         #             N        表示光标回到任意一个字符(任意数字)的某个位置;任意个字符之前就不展示出来了。
#print(f.readline())     # f.seek(0)；光标回到文本开头的位置；然后再次再读取这个文本的第一行。
#f.close()

#### 2 #######  encoding() buffer() detach() ............. ############## 2 #
### f.buffer()   buffer 也是内存中的一个临时文件。这个临时文件也不会很大。可以按照自己的需求设置大小。
### errors()   做异常处理的 ；alex 不会。暂且不需要关注
### detach()   做中断用；少用。不讲
### readinto() 也不讲了；少用。不讲
### newlines   也不讲了；少用。不讲
### fileno()   返回“文件句柄”在 “内存中的编号”;操作系统文件句柄的编号；我们很少用；暂且不管
### encoding   打印这个文件的字符编码
### isatty()   看 这是是否是一个终端设备；和打印机交互需要用到。
###  name      打印文件名字 ；就像 shell 里的 $0
###  flush()   默认是：代码量达到一定程度就会自动刷新，但也可以自己手动强制刷新
### seekable() 如果你是字符串，或者普通的二进制；可以把光标移动回去；能移回去就返回 True ；否则返回 False
### readable() 判断文件是否可读;可读就返回 True ；否则返回 False
### writable() 判断文件是否可写；可写就返回 True ；否则返回 False
### closed     判断文件是否关闭；可写就返回 True ；否则返回 False
### truncate(N) 截断；指定截断 从头开始截断；（移动并不好使。）开始截断 ；N 个字符后的所有内容都会被清空。
#   具体写法   #
#print(f.encoding)
#print(f.fileno())
#print(f.isatty())
#print(f.name)
#print(f.writable())

#print(f.flush())       强制刷新的场景：比如存钱。以及程序运行时间的进度条。
#   以写的模式；默认写到硬盘；但是其实不一定写到硬盘上；突然断电，又可能没写到硬盘；而是先写到内存里；
#               因为每写一段代码都传到硬盘；本身硬盘的读写速度慢于写到内存的速度；故 所有写的操作都先写道内存的缓存里
#               这个缓存的内存有大小；等写的东西达到一定这个内存设定值的一定大小后；统一写到硬盘里；从而提高了，读写的速度。涉及到了 cache  和 buffer 了。
#import sys,time
#for i in range(50):
#    sys.stdout.write("#")
#    sys.stdout.flush()
#    time.sleep(0.1)

#f = open("yesterday",'w',encoding="utf-8")
#f.truncate()                # 对文件 yesterday 写操作；并用 truncate() 方法；此时就会清空这个文件的内容；注意!注意！注意

#f = open("yesterday3",'a',encoding="utf-8")
#f.truncate(10)          # 截断；并清空除了前十个字符的 之后的所有内容

#f = open("yesterday4",'a',encoding="utf-8")
#f.seek(10)
#f.truncate(20)          # 从头开始截断；移动 seek(N)和 truncate（N）一起使用；seek(N)并不好使,；只认截断truncate(N) 。

#### 3 #######  修改文件.（相当于  shell 中 sed 得替换功能 ）.作业 1  ############## 3 #

# 修改文件：（修改得内容写死了；也可以把修改得内容弄成一个变量；可以修改文中的任意内容。）
#        备注：除了源文件之外；还产生了一个新的文件。
#        思路如下：1 以读的方式打开源文件（yesterday2）
#                     2 以写的方式，创建一个空且新的文件（yesterday2.bak）
#                     3 for 循环历遍这个源文件并把历遍的内容赋的值给 line 变量 ；并判断‘ 需要修改的文件内容’ --->> "爱情总是最具毁灭性"
#                               是否在这个历遍的内容里；
#                     4 修改 需要修改的内容 ；对这个 历遍的内容赋的值给 line 变量 用 replace() 的方法；方法的括号内是“修改的内容”“被修改后的内容”
#                     5 把源文件内容一并复制一份给新的文件 f_new ；并修改 被修改后的修改内容。
#                     6 现在我们已经打开了两个文件；所以最后还得关闭上这两个文件。

###  如下是写死了的方法  ###  1  #
# 方法 1.0
#f = open("yesterday2",'r',encoding="utf-8")
#f_new = open("yesterday2.bak",'w',encoding="utf-8")
#for line in f:
#    if "爱情总是最具毁灭性" in line:
#        line = line.replace("爱情总是最具毁灭性","爱情总是最具戏剧性")
#        f_new.write(line)
#    else:
#        f_new.write(line)
#f.close()
#f_new.close()

# 方法 1.1
#f = open("yesterday2",'r',encoding="utf-8")
#f_new = open("yesterday2.bak",'w',encoding="utf-8")
#for line in f:
#    if "昨日当我年少轻狂" in line:
#        line = line.replace("昨日当我年少轻狂","昨日当me young qing")
#    f_new.write(line)
#f.close()
#f_new.close()

###  如下是没写死；而是换成一个或者多个变量的方法  ###  2  #
'''
import sys
f = open("yesterday2",'r',encoding="utf-8")
f_new = open("yesterday2.bak",'w',encoding="utf-8")
find_str = sys.argv[1]
replace_str = sys.argv[2]
for line in f:
    if find_str in line:
        line = line.replace(find_str,replace_str)
    f_new.write(line)
f.close()
f_new.close()
'''
#### 4 #######  with 语句避免打开文件忘记关闭；自动关闭管理。 python 自动的垃圾回收机制. ############## 3 #
# 打开关闭单个文件情况下  ；那么我要打开多个文件呢？怎么处理？
#    处理方法： 英文的 逗号和斜杠  来表示  ；逗号：是为了分开  两个打开的文件
#               , \                          斜杠：是为了要打开的第二个文件可以跳到下一个行。
import sys
# f = open("yesterday2",'r',encoding="utf-8")
with open("yesterday2",'r',encoding="utf-8") as f,\
      open("yesterday3", 'r', encoding="utf-8") as f2:
    for line in f:
        print(line)