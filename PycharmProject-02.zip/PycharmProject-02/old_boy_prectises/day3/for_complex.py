#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP

#  for 样例;
'''
# 从 0 开始 到 10 ......
 for i in range(10):           #  range(10)  表示循环十次 ；每循环一次就给 i 赋予一个变量值 ；从 0 到 9
    print("loop",i)

# 打印 偶数。隔着 2 个数
for i in range(0,10,2):
    print("loop ",i)

# 打印 奇数。隔着 3 个数
for i in range(0,10,3):
    print("loop ",i)
# 判断
count = 0
age_of_oldboy = 56
for i in range(3):
     guess_age = int(input("guess age:"))
     if guess_age == age_of_oldboy :
         print("yes, you got it. ")
         break
     elif guess_age > age_of_oldboy:
         print("think smaller...")
     else:
         print("think bigger...")
     count +=1
     if count == 3:
         countine_confirm = input("do you wont to keep continue?")
         if countine_confirm != 'n':
             count =0
else:
    print("you have tried too many times..")
'''
# 循环
for i in range(5):       # 每 大循环 1 次 就小循环 3 次 ；一共 3 个大循环
    print('------>',i)
    for j in range(2):
        print('===>',j)
        if i >1:          # 判断：如果 小循环 大于2次 就跳出 这个小循环
            break