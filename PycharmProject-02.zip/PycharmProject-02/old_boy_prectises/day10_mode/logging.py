#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
'''
init()	# 系统初始化（读取所有的商品信息，保存到一个全局变量中）
login() 	# 登录
register()	# 新用户注册
show_products()	# 展示所有的商品序号、商品名称、价格
user_choice()	# 让用户输入选择的商品序号或者q，如果是q就调用show_current_shopping_log()并exit()
show_current_shopping_log()	# 显示本次购物日志
balance_enough()	# 检查余额是否足够
add_cart()	# 放入购物车并高亮显示、扣费，并调用日志信息shopping_log()和show_user_balance()显示用户余额
shopping_log()	# 添加到本次消费日志和用户信息的日志中
save_user()	# 将用户信息存回到文件中去
show_user_balance()	# 显示当前用户的余额，注意要高亮显示
show_shopping_log()	# 显示用户所有历史购物日志
'''

import  os,sys,time

BASE_DIR = os.path.dirname(__file__)
DB_DIR = os.path.join(BASE_DIR, 'db')
print(BASE_DIR)
print(DB_DIR)

def init():	# 系统初始化（读取所有的商品信息，保存到一个全局变量中）
    pass
def login(): 	# 登录
    username = input("请输入自己的用户名:")
    password = input("请输入自己的密码:")
    if user_exist(username):
        # 用户存在，则比较用户名和密码
        pass   # 检查用户是否存在
        if username == 'coosh' and password == '123':
            load_user_info('coosh')
            return True
        else:
            return False
    else:
        register(username)
        return True


def user_exist(name):   # 检查用户是否存在
    user_info_file = os.path.join(DB_DIR, name)
    print(user_info_file)
    if os.path.exists(user_info_file):
        return True
    else:
        return False


result = user_exist('coosh')

# 让用户输入用户名和密码；然后开始循环（无线循环）
def register(name):  # 新用户注册
    print("您是新用户：", name)
    while True:
        password = input("请输入新密码：")
        if len(password.strip()) >0:
            # 用户输入的密码不为空或全空格
            new_user(name,password)
            return True
            pass
        else:
            print('密码不能为空，')


def new_user(name, password): # 把新用户的信息保存到文件
    # 如下是字典的形式
    user = {
        'password': password,
        'balance': 15000,
        'shopping_log': [],
    }
    new_user_file = os.path.join(DB_DIR, name)
    with open(new_user_file, 'w') as f:
        f.write(user)

new_user('alex', '123')


def load_user_info(username):   # 加载用户信息
    user_file = os.path.join(DB_DIR, username)
    with open(user_file,'r') as f:
        data = f.read()
    user = eval(data)
    print(user)
    return user

load_user_info('alex')


def show_products():	# 展示所有的商品序号、商品名称、价格
    pass
def user_choice():	# 让用户输入选择的商品序号或者q，如果是q就调用show_current_shopping_log()并exit()
    pass
def show_current_shopping_log():	# 显示本次购物日志
    pass
def balance_enough():	# 检查余额是否足够
    pass
def add_cart():	# 放入购物车并高亮显示、扣费，并调用日志信息shopping_log()和show_user_balance()显示用户余额
    pass
def shopping_log():	# 添加到本次消费日志和用户信息的日志中
    pass
def save_user():	# 将用户信息存回到文件中去
    pass
def show_user_balance():	# 显示当前用户的余额，注意要高亮显示
    pass
def show_shopping_log():	# 显示用户所有历史购物日志