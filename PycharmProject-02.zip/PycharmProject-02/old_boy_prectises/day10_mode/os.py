#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
import sys,os

BASE_DIR = os.path.dirname(__file__)
DB_DIR = os.path.join(BASE_DIR, 'db')
print(BASE_DIR)
print(DB_DIR)
