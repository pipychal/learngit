#!/usr/bin/env python
# -*- coding: utf-8 -*-
my_age = 28
count = 0
while count < 2:
    user_input = int(input("input your guess num:"))

    if user_input == my_age:
        print("Congratulations, you got it !")
        break
    elif user_input < my_age:
        print("Oops,think bigger!")
    else:
        print("think smaller!")
    count += 1 #每次loop 计数器+1
else:
    print("猜这么多次都不对,你个笨蛋.")