#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:

def fib(max):           # max 设置为 10
    n, a, b = 0, 0, 1
    while n < max:     #  n < 10  的条件
        # print(b)
        yield b         # yield  使其变成生成器。
        a, b = b, a + b
        n = n + 1
    return 'done'

# f=fib(10)
# print("-------one by one-------")
# print(f.__next__())
# print(f.__next__())
# print(f.__next__())
# print(f.__next__())
# print(f.__next__())
# print(f.__next__())
# print(f.__next__())
# print(f.__next__())
# print(f.__next__())
# print(f.__next__())
# print(f.__next__())

g = fib(6)
while True:
   try:
       x = next(g)
       print('g:', x)
   except StopIteration as e:
       print('Generator return value:', e.value)
       break
# for i in f:
#     print(i)