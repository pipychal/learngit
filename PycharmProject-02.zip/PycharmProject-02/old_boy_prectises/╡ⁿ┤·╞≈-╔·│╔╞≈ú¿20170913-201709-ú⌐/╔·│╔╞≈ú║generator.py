#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:

######  (一) ： 普通写法  ##############
# 1) :
# a = []
# for i in range(10):
#     a.append(i*2)           ## a.append(i*3)  a.append(i-3)
# print(a)

###  得到结果 [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]

# 2) 普通写法 2 :
# a = [1,2,3,4,5]
# for index,i in enumerate(a):
#     a[index] +=1
# print(a)

# 3）普通写法 3：
#     a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
#     a = map(lambda x:x+1, a)
#     print(a)



######  ( 二) ： 深入版本-生成式  ##############  是第一种方式的 优化写法，升级写法。
# 1 ). 慢的写法 ，假如循环数大就特别慢
# b = [ i*2 for i in range(10000000000)]         ## i 是变量 ；也可以把 i 替换成“函数”，函数还可以传参 ; 这个我们叫“列表生成式”
# print(b)

# 2 ）.快的写法
    ## 获取列表的算法，并把之赋值给一个变量 b
b = ( i*2 for i in range(100) )
print(b)
    ## 调用这个算法，并打印出算法的值
for i in b:
    print(i)
