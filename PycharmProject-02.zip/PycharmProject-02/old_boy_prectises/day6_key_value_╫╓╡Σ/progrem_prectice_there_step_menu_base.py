#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP

while not True:
    for i in menu:
        print(i)

    chioce = input("选择进入1>>:")

    if chioce in menu:
        while not True:                 # 在这层还是一直在这层输入；然后我们就给个死循环
            for i2 in menu[chioce]:
                print("\t",i2)
            chioce2 = input("选择进入2>>:")

            if chioce2 in menu[chioce]:
                while not True:        # 在这层还是一直在这层输入；然后我们就给个死循环
                    for i3 in menu[chioce][chioce2]:
                        print("\t\t", i3)
                    chioce3 = input("选择进入3>>:")

                    if chioce3 in menu[chioce][chioce2]:
                        for i4 in menu[chioce][chioce2][chioce3]:
                            print("\t\t",i4)
                        chioce4 = input("最后一层，按 b 返回>>:")
                        if chioce4 == "b":
                            break
            if chioce2 == "b":
                        break
    if chioce == "exit":
        break