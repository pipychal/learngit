#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinw
# Date:
# 模拟登陆
# 1.用户输入账号密码进行登陆
# 2.用户信息存在文件内
# 3.用户密码输错三次后锁定用户


### 还需要改进和增加，完善的地方有：###
    # 1：添加一个 用户注册函数，用户注册的时候写入一个用户相关信息的文件里，这个时候是以列表的形式存在
    # 2：注册完毕之后，就可以登陆，登陆的时候去注册的文件里读取用户名和密码
    # 3：user_info 需要改进，去调用注册的函数，拿取用户名和密码
    # 4：密码必须是秘文传输
    # 5：这些账户和密码应该写到mysql 数据库的某某用户名和密码表里！！！这个和实用！！！

import sys
count = 0
user_info = { "zhangsan":"123","lisi":"456","wangwu":"678" }        # 这里是一个字典，
username = input("Please input your username>>>:")
if username in user_info:
    print(username)       #                                               # 验证 username是否和输入的一致
    with open("lock_list", "r") as f:
        for i in f:
            print(i)                                                      # 验证 username 是否和 lock_list 文件里的一致
            if username == i:                                             ###### 把 username  写成 user_info 了；卡住了；现在好了。
                print('您的账号已经被锁定')
                sys.exit('您的账户以及被锁定，请联系管理员')
            else:
                while count < 3:
                    password = input('Please input your password:')
                    if password == user_info[username]:
                        print('登录成功，欢迎%s!' % username)
                        sys.exit()
                    else:
                        count += 1
                        if count == 3:
                            print('用户被锁定...')
                            sys.exit()
                        else:
                            print('密码错误！请重新输入。还有%s次机会' % (3 - count))
else:
    print('用户名不存在!')