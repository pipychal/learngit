#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:
# 模拟登陆
# 1.用户输入账号密码进行登陆
# 2.用户信息存在文件内
# 3.用户密码输错三次后锁定用户

# 用户输入的用户名和密码放到一个文本里；然后解析成字典类型（也就是对文本内容进行字典的转换），最后我们循环这个字典去验证即可，
# 当然这个时候必须创建一个空字典，方便存入数据，也便于循环。 循环去验证用户名和密码是否对应，即达到了检测的目的

### 把既定的内容写到文件里，然后处理文件的内容转化成字典。待会儿做个优化：让用户输入（注册的的用户名和密码）存到新创建的文件里，然后再处理，转化。

import sys
count = 0
############################################# 一 ：将文件user_info 的内容转化成字典 user_dict ；如下 1 ，2 ，3 段############################################333
#### 1 ：读取文件内容
# 读取文件写法 1 ：
# with open('user_info','r') as f:
#     user_info = f.read()
user_info = "zhangsan:123,lisi:456,wangwu:678"        # 这个情况是写现成的内容，没有文件的读取。用了文件读取时候可以不用这种方法
user_list = user_info.split(',')            # 把 user_info 里的内容以 “逗号”分割 ，并赋值给 user_list 变量。

# user_info = "zhangsan:123,lisi:456,wangwu:678"
user_dict = {}
for i in user_list:
    i_list = i.split(':')
    user_dict[i_list[0]] = i_list[-1]       # 把以上的结果存到 user_dict 这个字典里
print(user_dict)                            # 这个打印 user_dict 字典是为了查看存入字典后得到的结果，得到的结果就是字典的形式。

username = input("Please input your username>>>:")
if username in user_dict:                                   # 判断和用户交互的用户输入的用户名是否在 user_info 这个表里。
#     # lock_list ：被锁定的文件的信息
#     with open('lock_list', 'r') as f1:
#         lock_list = f1.read()
    lock_list = {'zhangsan':'123'}                                #&&&&&&& 需要在优化。写成去文件里读取
    if user_dict in lock_list:                                # 再判断 user_info 文件里的用户名 是否在 lock_list （锁定的用户名放在这个表里）这个表里，
        print('您的账号已经被锁定')                      # 如果在，打印出 # Your count was locked
        sys.exit('您的账户以及被锁定，请联系管理员')        # 退出 借助了 sys 模块。开头就导入模块 sys
    else:                                               # 如果不在，
        while count < 3:
            password = input('Please input your password:')    #则重新输入你的密码。
            if password == user_info[password]:
                print('登录成功，欢迎%s!' % username)
                sys.exit()
            else:
                count +=1
                if count == 3:
                    print('用户被锁定...')
                    sys.exit()
                else:
                    print('密码错误！请重新输入。还有%s次机会' % (3-count))
else:
    print('用户名不存在!')

# # # user_info = "zhangsan:123,lisi:456,wangwu:678"        # 这个情况是写现成的内容，没有文件的读取。用了文件读取时候可以不用这种方法
# user_list = user_info.split(',')            # 把 user_info 里的内容以 “逗号”分割 ，并赋值给 user_list 变量。
# print(user_list)                            # 分割完毕得到的结果是 ['zhangsan:123', 'lisi:456']，其并不是一个字典
#
# #### 3 ：创建一个空字典，并对以上分割的结果- user_list ；再次分割，且进行循环，把循环的结果传入空字典 user_dict 里，如 34 行；得到的结果是字典，如
# #           {'wangwu': '678', 'zhangsan': '123', 'lisi': '456'}
# user_dict = {}
# for i in user_list:
#     i_list = i.split(':')
#     user_dict[i_list[0]] = i_list[-1]       # 把以上的结果存到 user_dict 这个字典里
# print(user_dict)                            # 这个打印 user_dict 字典是为了查看存入字典后得到的结果，得到的结果就是字典的形式。