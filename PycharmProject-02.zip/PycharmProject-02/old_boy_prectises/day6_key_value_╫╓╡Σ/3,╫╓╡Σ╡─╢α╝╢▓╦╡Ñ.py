#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
# 2017-02-18  21：31
# #“列表”和“字典”之间的对比；列表可以存少量的数据；而字典则可以存更多的数据；“字典”是“列表”的升级版 存储方式
# # 字典的特性： 1：字典 （dictionary ）是无序的   2：key必须是唯一的,so 天生去重（  打印出来无顺序；可以通过key来寻找value  ）；
# # 列表是有序的，因为它有 “下标 ” ，通过下标来取值；字典无下标，但可以通过 key-value 来取值
# #( 一 )创建 key - value  多个 key - value 就用 逗号 隔开 ；
# # 可以做“多级菜单” ； 菜单的名称 尽量不用中文 。以免发生编码问题，导致乱码

# 备注：“多级字典嵌套”及其操作：这个 dictionary_more 脚本里我就开始讲：一个 key 对应 多个 value 的单级写法 的 “增”“删”“改”“查”
# www.youporn.com   www.pornhub.com   letmedothistoyou.com  x-art.com  1024
a_catalog = {
    "欧美":{                                      # 第一个 二级菜单的 key - value
        "www.yyy.com": ["世界最大","质量1"],   # 一个 key 对应 多个 value ；这里有两个 value 分别是 "世界最大","质量1" ；多个value 所以用 中括号 括起来。
        "www.ppp.com": ["世界最小","质量2"],
        "www.let.com": ["世界很大","质量3"],
        "www.xxx.com": ["世界很小","质量4"]
    },
    "日韩":{                                      # 第二个 二级菜单的 key - value
        "www.tok.com": ["世界较大","质量5"]
    },
    "大陆":{                                      # 第三个 二级菜单的 key - value
        "2048": ["世界不大","质量6"]
    }
}

# （ 一 ）“改”也就是“替换”
#a_catalog["大陆"]["2048"][1] = "质量超级好"      #改 大陆 这级菜单 2048 这个 key  对应的第二个值 "质量6" 为 "质量超级好"
#print(a_catalog)
#print(a_catalog["大陆"]["2048"])      # 打印 二级菜单 的 key 然后展示 二级菜单的 value；这里的二级菜单是 大陆 ；其 value 就是 ["世界不大","质量6"]
a_catalog.setdefault("taiwan",{"www.taitai.com":["雷好","好耶"]})   # 新添加一个 key  和 两个 value  ；两个 value 已经用 中括号 了；所以 整段value 必须得用 大括号。
print(a_catalog)

