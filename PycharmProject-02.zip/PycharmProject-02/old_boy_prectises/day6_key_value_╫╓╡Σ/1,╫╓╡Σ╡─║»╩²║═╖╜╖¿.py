#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:

# python 字典的内置 函数 & 方法
#---------------------------------------------------------------(一)函数-----------------------------------------------------------
# python 字典的内置 函数；一共有四种：---> 1 ：cmp(dict1, dict2) ---> 比较两个字典元素。
#                                     ---> 2 ：len(dict)  ---> 计算字典元素个数，即键的总数。
#                                     --->  3	：str(dict)  ---> 输出字典可打印的字符串表示。
#                                     ---> 4	：type(variable) --->  返回输入的变量类型，如果变量是字典就返回字典类型。

# ---> 4 # Python 字典(Dictionary) str() 函数将值转化为适于人阅读的形式，以可打印的字符串表示。
# 语法; type()方法语法：type(dict)
# 参数  dict -- 字典。  返回值   ; 返回输入的变量类型。
#dict = {'Name': 'Zara', 'Age': 7}
#print ("Equivalent String : %s"  % str(dict))
#print(type(dict))                                   # 打印变量类型 第一种表示
#print "Variable Type : %s" %  type (dict)           # 打印变量类型 第二种表示

#===============================================================（二）方法=========================================================
# python 字典的内置 方法；一共有10 种：
#---> 1 ：radiansdict.clear()                         删除字典内所有元素
#---> 2 ：radiansdict.copy()                          返回一个字典的浅复制
#---> 3 ：radiansdict.fromkeys()                      创建一个新字典，以序列seq中元素做字典的键，val为字典所有键对应的初始值
#---> 4 ：radiansdict.get(key, default=None)          返回指定键的值，如果值不在字典中返回default值
#---> 5 ：radiansdict.has_key(key)                    如果键在字典dict里返回true，否则返回false
#---> 6 ：radiansdict.items()                         以列表返回可遍历的(键, 值) 元组数组
#---> 7 ：radiansdict.keys()                          以列表返回一个字典所有的键
#---> 8 ：radiansdict.setdefault(key, default=None)   和get()类似, 但如果键不存在于字典中，将会添加键并将值设为default
#---> 9 ：radiansdict.update(dict2)                   把字典dict2的键/值对更新到dict里
#---> 10：1radiansdict.values()                       以列表返回字典中的所有值


#---> 1 ：radiansdict.clear()                         删除字典内所有元素
#dict = {'Name': 'Zara', 'Age': 7}
#print( "Start Len : %d" %  len(dict))
#dict.clear()
#print ("End Len : %d" %  len(dict))

#---> 2 ：radiansdict.copy()                          返回一个字典的浅复制
#dict1 = {'Name': 'Zara', 'Age': 7};
#dict2 = dict1.copy()
#print "New Dictinary : %s" %  str(dict2)

#---> 3 ：radiansdict.fromkeys()                      创建一个新字典，以序列seq中元素做字典的键，val为字典所有键对应的初始值
#seq = ('name', 'age', 'sex')
#dict = dict.fromkeys(seq)                            # 字典的键（分别是：'name', 'age', 'sex'）对应的初始值为 空 即 None
#print "New Dictionary : %s" %  str(dict)
#dict = dict.fromkeys(seq, 10)                       # 字典的键（分别是：'name', 'age', 'sex'）对应的初始值为 空 即 10
#print "New Dictionary : %s" %  str(dict)

#---> 4 ：radiansdict.get(key, default=None)          返回指定键的值，如果值不在字典中返回default值
#dict = {'Name': 'Zara', 'Age': 27}
#print "Value : %s" %  dict.get('Age')
#print "Value : %s" %  dict.get('Sex', "Never")

#---> 5 ：radiansdict.has_key(key)                    Python 字典(Dictionary) has_key() 函数用于判断键是否存在于字典中，如果键在字典dict里返回true，否则返回false   ‘可判断返回值来赋值。
#dict = {'Name':'Zara','Age':7}
#print("Value:%s" % dict.has_key('Age'))           # 该键 Age 在字典dict里有；所以返回 True
#print("Value:%s" % dict.has_key('Sex'))           # 该键 Sex 在字典dict里无（没有）；所以返回 False

#---> 6 ：radiansdict.items()                         以列表返回可遍历的(键, 值) 元组数组
#dict = {'Name':'Zara','Age':7}
#print("Value:%s" % dict.items())

#---> 7 ：radiansdict.keys()                          以列表返回一个字典所有的键
#dict = {'Name':'Zara','Age':7}
#print("Value:%s" % dict.keys())

#---> 8 ：radiansdict.setdefault(key, default=None)   和get()类似, 但如果键不存在于字典中，将会添加键并将值设为default
#dict = {'Name':'Zara','Age':7}
#print("Value:%s" % dict.setdefault("Age"))         # 该键 Age 在字典dict里有；所以返回 7
#print("Value:%s" % dict.setdefault("Sex"))         # 该键 Sex 在字典dict里无（没有）；所以返回 None

#---> 9 ：radiansdict.update(dict2)                 增加； 把字典dict2的键/值对更新到dict里
#dict = {'Name': 'Zara', 'Age': 7}
#dict2 = {'Sex': 'male'}
#dict.update(dict2)
#print("Value:%s" % dict)

#---> 10：1radiansdict.values()                       以列表返回字典中的所有值
dict = {'Name': 'Zara', 'Age': 7}
print( "Value : %s" %  dict.get(1))
#print(dict.get(1))