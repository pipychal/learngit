#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinw
# Date:
import sys
count = 0
user_info = { "zhangsan":"123","lisi":"456","wangwu":"678" }
username = input("Please input your username>>>:")
if username in user_info:
    lock_list = ['zhangsan']
    if user_info in lock_list:
        print('您的账号已经被锁定')
        sys.exit('您的账户以及被锁定，请联系管理员')
    else:
        while count < 3:
            password = input('Please input your password:')
            if password == user_info[username]:
                print('登录成功，欢迎%s!' % username)
                sys.exit()
            else:
                count +=1
                if count == 3:
                    print('用户被锁定...')
                    sys.exit()
                else:
                    print('密码错误！请重新输入。还有%s次机会' % (3-count))
else:
    print('用户名不存在!')