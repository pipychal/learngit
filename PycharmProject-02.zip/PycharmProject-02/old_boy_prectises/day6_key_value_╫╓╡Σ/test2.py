#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinw
# Date:
import sys,os
BASE_DIR = os.path.dirname(__file__)
DB_DIR = os.path.join(BASE_DIR,'db')
# print(BASE_DIR)
# print(DB_DIR)
# 让用户输入用户名和密码；然后开始循环（无线循环）

def new_user(name, password):  # 把新用户的信息保存到文件
    # 如下是字典的形式
    user = {
        'password': password,
        'balance': 15000,
        'shopping_log': [],
    }
    new_user_file = os.path.join(DB_DIR, name)
    with open(new_user_file, 'w') as f:
        f.write(str(user))
        # 写入这 new_user_file 文件的之前是个字典，现在用 str() ，把用户
        # 输入转换成字符串。就不报错了。

new_user('alex', '123')

def load_user_info(username):   # 加载用户信息，需要读取函数 new_user 里生产的 new_user_file 这个文件
    user_file = os.path.join(DB_DIR, username)
    with open(user_file,'r') as f:
        data = f.read()         # 读取出来的时候是个字符串，那么转换成用户的字典呢？
    user = eval(data)           ###### eval 函数转换 字符串成为字典。
    print(type(user),user)      ### 经过 eval 转换之后呢，就变成了用户字典类型
    return user

load_user_info('alex')

# def register(name):  # 新用户注册            ### 函数传递参数
#     print("您是新用户：", name)
#     while True:
#         password = input("请输入新密码：")
#         if len(password.strip()) >0:
#             # 用户输入的密码不为空或全空格,且大于 0 ；
#             new_user(name,password)
#             return True
#             pass
#         else:
#             print('密码不能为空，')
