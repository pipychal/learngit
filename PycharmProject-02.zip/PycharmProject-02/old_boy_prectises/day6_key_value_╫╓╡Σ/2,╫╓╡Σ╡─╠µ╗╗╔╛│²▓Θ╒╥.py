#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
# date: 2017-02-18
# #“列表”和“字典”之间的对比；列表可以存少量的数据；而字典则可以存更多的数据；“字典”是“列表”的升级版 存储方式
# # 字典的特性： 1：字典 （dictionary ）是无序的   2：key必须是唯一的,so 天生去重（  打印出来无顺序；可以通过key来寻找value  ）；
# # 列表是有序的，因为它有 “下标” ，通过下标来取值；字典无下标，但可以通过 key-value 来取值
# #( 一 )创建 key - value  多个 key - value 就用 逗号 隔开 ；
# # 可以做“多级菜单” ； 菜单的名称 尽量不用中文 。以免发生编码问题，导致乱码

# （  打印出来无顺序；可以通过key来寻找value  ）；用 中括号{ } 表示;表 key 和 value 一起存入；并且赋值给一个变量 info
# 备注：这个 dictionary 脚本里我就开始讲：一个 key 对应 一个 value 的单级写法 的 “增”“删”“改”“查”
info = {
    'stu1101':"Tenglan Wu",
    'stu1102':"LongZe Luola",
    'stu1103':"XiaoZe Maliya",
}
#print(info)
#（ 二 ）添加+替换
print(info["stu1101"])  # 打印 key （stu1101）;就可以出 value（Tenglan Wu）； 格式：print(变量名["key"])
info['stu1101'] = "藤兰" # stu1101 的key 对应的值 Tenglan Wu 替换成 藤兰
info["stu1104"]="蓝蓝"   # 新添加一个key - value  ；存在则修改；不存在则添加。
print(info)

# （ 三 ）删除 的三种表达  1： del + 变量["key"]  2： 变量.pop("key") ；3： 变量.popitem()   --这叫随机删除
#del info["stu1101"]     # 1
#print(info)
#info.pop("stu1102")     # 2
#info.popitem()           # 3 随机删除
#print(info)

# （ 四 ）查找 两种方式，分别是：1 确定有某个值（才可用此种方法）  ；2 不确定是否有这个值（此种方法不会出错）
#print(info['stu1104'])      # 1 确定有某个值（才可用此种方法）;有个弊端：查找的值不存在就会报错
#print(info.get("stu1104"))  # 2 不确定是否有这个值（此种方法不会出错）; 不管你存不存在，安全的查找永远都不会报错
#print('stu1104' in info)  # py2.x 存在的写法 info.has_key("stu1103")  但在 py3.x 里没有这种写法了
                            # 判断 stu1103 这个 key 是否在 info 这个变量里；存在在返回 True  ；不存在则返回 False



