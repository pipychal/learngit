#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
# date : 2017-02-19  01:58
# #  哪个有“红色下划线” 则是出错的地方。切记！！！
# #  光标变黑色，按 insert 按键即可。
menu = {
    '北京':{
        '海淀':{
            '五道口':{
                'soho':{},
                '网易':{},
                'google':{}
            },
            '中关村':{
                '爱奇艺':{},
                '汽车之家':{},
                'youku':{},
            },
            '上地':{
                '百度':{},
            },
        },
        '昌平':{
            '沙河':{
                '老男孩':{},
                '北航':{},
            },
            '天通苑':{},
            '回龙观':{},
        },
        '朝阳':{},
        '东城':{},
    },
    '上海':{
        '闵行':{
            "人民广场":{
                '炸鸡店':{}
            }
        },
        '闸北':{
            '火车战':{
                '携程':{}
            }
        },
        '浦东':{},
    },
    '山东':{},
}

exit_flag = False

while not exit_flag:
    for i in menu:
        print(i)

    chioce = input("选择进入1>>:")

    if chioce in menu:
        while not exit_flag:                 # 在这层还是一直在这层输入；然后我们就给个死循环
            for i2 in menu[chioce]:
                print("\t",i2)
            chioce2 = input("选择进入2>>:")

            if chioce2 in menu[chioce]:
                while not exit_flag:        # 在这层还是一直在这层输入；然后我们就给个死循环
                    for i3 in menu[chioce][chioce2]:
                        print("\t\t", i3)
                    chioce3 = input("选择进入3>>:")

                    if chioce3 in menu[chioce][chioce2]:
                        for i4 in menu[chioce][chioce2][chioce3]:
                            print("\t\t",i4)
                        chioce4 = input("最后一层，按 b 返回>>:")
                        if chioce4 == "b":
                            pass
                        elif chioce4 == "q":
                            exit_flag = True
                    if chioce3 == "b":
                        break
                    elif chioce3 == "q":
                        exit_flag = True
            if chioce2 == "b":
                        break
            elif chioce2 == "q":
                exit_flag = True