#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:PP
# 2017-02-18
# # “列表”和“字典”之间的对比；列表可以存少量的数据；而字典则可以存更多的数据；“字典”是“列表”的升级版 存储方式
# # 字典的特性： 1：字典 （dictionary ）是无序的   2：key必须是唯一的,so 天生去重（  打印出来无顺序；可以通过key来寻找value  ）；
# # 列表是有序的，因为它有 “下标” ，通过下标来取值；字典无下标，但可以通过 key-value 来取值
# #( 一 )创建 key - value  多个 key - value 就用 逗号 隔开 ；
# # 可以做“多级菜单” ； 菜单的名称 尽量不用中文 。以免发生编码问题，导致乱码

# 1：单独打印 key  和  value
# 2：某字典 作为一个参数，传给 另一个字典  格式 ： 变量1.update(变量2)
# 3：把“字典” 转换成 “列表”
# 4：dict.formkeys(key,value)  初始化一个 “字典”；key-value 可以是一个或者多个  ；
     #  注意：当用 dict.formkeys(key,value) 初始化一个字典的时候；一层数据方便；因为其公用一个内存地址；一变则都变；当多层数据时候，你只想改变某个key对应的value ,最好不要这种方式，理由是“一变则都变”
# 5：循环一个字典  ：用法 1: for i(key) in 变量:                |    2: for i(key) in 变量.items():     方法 1 高效 ，         理由：只通过索引循环
#                                print(i(key),变量[i(key)])     |           print(key,value)            方法 2 比较 1 低效些， 理由：“字典”要转换成“列表”，数据量大的话，转换就需要大量时间，机器就崩了

# 1

# 2
info = {                            # 字典 1 ：
    'stu1101': "TengLan Wu",
    'stu1102': "LongZe Luola",
    'stu1103': "XiaoZe Maliya",
}

info2 = {                           # 字典 2 ； 这是新的字典 ;该字典多了三个 key-value
    'stu1101':"Alex",
    '1':'3',
    '2':'5'
}
# info.update(info2)     # 把第二个字典 info2 作为 一个参数 传给 字典1 即 info 这个变量
# print(info)            # 把 字典1 传给 字典2 之后；再打印 字典1   ；
                       # 两个字典得 key  stu1101 是相同；值不同；所有 字典1 的值(TengLan Wu)就换成 字典2 的 (Alex) ；同时耶增加了 1  2 的key-value
# 3
print(info.items())    ### 把一个 “字典” 转换成一个  “列表”  形式是：  变量1.item() 的方式。

# 4
#info3 = info.fromkeys([6,7,8])              # key 分别是 6 7 8 ；value 是 空值
#info3 = dict.fromkeys([6,7,8],"zhangsan") # key 分别是 6 7 8 ；value 都是 zhangsan

#info3 = dict.fromkeys([6,7,8],[1,{"name":"alex"},444])   # 初始化新的字典
#print(info3)
#info3[7][2]= "Jack Chen"                 # 把 变量 info3 中的 这个 7 (这是key) 中的 第三个值（444）改成 "Jack Chen"
#info3[7][1]["name"]= "Jack Chen"        # 把 变量 info3 中的 这个 7 (这是key) 中的 第二个值（name 这个 key 对应的value (alex)）改成 "Jack Chen"
#print(info3)

# 5
# 方法 1 （高效）：
#for i in info:                          # 只是打印 key
#    print(i)

#for i in info:                          # 只是打印 value
#    print('',info[i])

# for i in info:                         # key 和 value 都打印出来了
#     print(i,info[i])

# 方法 2 （低效，不建议用）：
#for key,value in info.items():                 # “字典”转换成“列表” ；慢了
#    print(key,value)
