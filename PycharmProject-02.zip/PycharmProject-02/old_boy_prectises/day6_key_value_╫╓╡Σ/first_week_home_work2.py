#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date : 2017-02-19
#!/usr/bin/env python
# -*- conding:utf-8 -*-
# Author : QiuMeng
'''
模拟登陆
1.用户输入账号密码进行登陆
2.用户信息存在文件内
3.用户密码输错三次后锁定用户
'''
try_times = 0
forbidden_user = []

file = open("lock","r")
for line in file:
    forbidden_user.append(line.strip())
file.close()

username = input("Please input your username:")
if username in forbidden_user:
    print("You are locked!")
else:
    while try_times < 3:
        password = input("Please input your password:")
        status = False
        user_info = open("db","r")
        for line in user_info:
            if username == line.strip().split()[0] and password == line.strip().split()[1]: #用户密码匹配,去除换行符影响
                status = True
                break
            else:
                status = False
                continue # 当行判断失败后判断下一行
        if status:
            print("Welcome login {name}".format(name=username))
            break #成功后跳出while
        else:
            print("username or password invalid!Please try again..")
        try_times += 1 #尝试次数累计
        user_info.close()
    else:
        file = open("lock","a")
        file.write(username+'\n')
        file.close()
        print("You tried so many times,locked")