#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
import time
def bar():
    time.sleep(3)
    print('in the bar')

def test2(func):
    print(func)
    return func

print(test2(bar))