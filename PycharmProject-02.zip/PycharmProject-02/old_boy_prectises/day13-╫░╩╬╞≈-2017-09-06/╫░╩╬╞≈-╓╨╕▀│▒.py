#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:
#   装饰器可以传递很多参数
# 装饰函数式 timmer  ; 被装饰函数有： _ttest1  和  _ttest2
import time

### （一）：装饰函数式 timmer
######### 整体是一个高阶函数 （） ############(一个函数作为一个参数传递到另一个函数里)
####  写了一个新的函数 timmer  ； 来描述 _ttest1 函数 ，顺便把 _ttest1 函数作为一个参数传递到 timmer 函数里
### （1 ） 嵌套函数  #####(一个函数内再次定义一个 函数)
def timmer(func):                 # func  指的是传递的参数是“一个函数”；也可以是多个变量（函数）
    def warpper(*args,**kwargs):   #  warpper 函数并不返回，只是在下面返回了该函数的内存地址。
        start_time=time.time()
        func(*args,**kwargs)             #传形参     # run test1  ；把 test1 作为一个参数传递；执行func 即执行函数 test1
        stop_time=time.time()
        print('the func run time is %s' %(stop_time-start_time))
    return warpper                # 返回 warpper 的内存地址

@timmer            # 开始装饰 _ttest1        ###  等同于 _ttest1=timmer(_ttest1)

### （二）被装饰函数式 _ttest1
def _ttest1():                      # _ttest1 并没有传递参数
    time.sleep(3)
    print('in the test1')
_ttest1()

@timmer         # 开始装饰 _ttest2  #  @timmer  等同于  _ttest2=timmer(_ttest2) ；_ttest2 其实等于 warpper ,给 _ttest2 加括号等同于给warpper 加括号
                            #   _ttest2()  等同于 warpper()  ; 这里 _ttest2 传递了参数 name ；但在代码执行到 warpper 函数的时候，并没有传递参数；所以会报错

### （三）被装饰函数式 _ttest2
def _ttest2(name,age):                  # _ttest2 传递参数 name 和 age
    time.sleep(3)
    print("in the test2:",name,age)

_ttest2("qinwang",22)                  ## 传实参


### 可以是多个装饰函数；也可以是多个被装饰函数。


