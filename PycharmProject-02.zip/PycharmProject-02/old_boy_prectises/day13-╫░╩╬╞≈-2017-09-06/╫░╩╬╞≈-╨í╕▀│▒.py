#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:
import time

######### 整体是一个高阶函数 （） ############(一个函数作为一个参数传递到另一个函数里)

####  写了一个新的函数 timmer  ； 来描述 test1 函数 ，顺便把 test1 函数作为一个参数传递到 timmer 函数里

### （1 ） 嵌套函数  #####(一个函数内再次定义一个 函数)
def timmer(func):                 # func  指的是传递的参数是“一个函数”
    def warpper(*args,**kwargs):
        start_time=time.time()
        func()                    # run test1  ；把 test1 作为一个参数传递；执行func 即执行函数 test1
        stop_time=time.time()
        print('the func run time is %s' %(stop_time-start_time))
    return warpper                # 返回 warpper 的内存地址

def test1():
    time.sleep(2)
    print('in the test1')

test1=timmer(test1)
test1()