#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:

import time

def test1():
    time.sleep(3)
    print('in the test1')

test1()