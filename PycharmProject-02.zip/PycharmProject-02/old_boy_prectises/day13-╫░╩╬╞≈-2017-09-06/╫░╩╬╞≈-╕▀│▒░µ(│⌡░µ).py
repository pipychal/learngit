#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Qinwang
# Date:
#  写一个网站，一个网站有很多页面；一个页面代表一个函数。有三个页面，每个页面都需要登录才可以写东西和发帖
#  之前每个页面都没有验证，现在我们需要写验证模块，这个模块是装饰器，不改变原先各个页面的代码和调用方式
# 列出三个函数； auth 函数作为装饰器；
import time

user,passwd = 'alex','abc123'

def auth(func):
    def wrapper(*args,**kwargs):
        username = input("Username:").strip()
        password = input("Password:").strip()

        if user == username and passwd == password:
            print("\033[32;1mUser passwd authentication\033[0m")
            func(*args,**kwargs)
        else:
            exit("\033[31;1mInvalid username or password\033[0m")
    return wrapper

def index():
    pass

@auth
def home():
    print("welcome to home page")
    return "from home"
    pass

@auth
def bbs():
    pass

index()
home()
bbs()
