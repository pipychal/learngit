#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
# 程序从上往下执行；bar 和 foo 函数 都是一个变量了，并在内存空间创建了一个内存空间位置地址块；
# 只要在被调用之前被定义了，最后都被调用,均能正常展示
##############（1）bar函数被调用可执行###################
# def bar():
#     print('in the bar')
# def foo():
#     print('in the foo')
#     bar()
# foo()     # 调用foo ；当中调用了变量（函数）bar  ；执行的时候 bar 函数（变量）已经被定义了

#################（2）bar函数被调用可执行#################
# def foo():
#     print('in the foo')
#     bar()
#
# def bar():
#     print('in the bar')
# foo()     # 调用foo ；当中调用了变量（函数）bar ；执行的时候 bar 函数（变量）已经被定义了

##################（3）bar函数不被调用####################
# def foo():
#     print('in the foo')
#     bar()
# foo()       # 调用foo ；当中调用了变量（函数）bar；但执行的时候 bar 函数（变量）还没被定义
# def bar():
#     print('in the bar')

#######################################################
#
# def bar():
#     print('in the bar')
#
# def test1(func):
#     print(func)
#     func()
#
# test1(bar)

########################################################
# 这个不能实现 装饰器的作用，理由是改变了被装饰函数的调用方式。
# 我还是搞不懂这里这里的调用方式哪里不一样了？得问老师
import time
def bar():
    time.sleep(2)
    print('in the bar')

def test1(func):
    start_time=time.time()
    func()                      # run bar
    stop_time=time.time()
    print('the func run time is %s' %(stop_time-start_time))

test1(bar)      # 把 bar 函数作为变量调用
#bar()