#!/usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Qw"
# Date:
# 在一个函数内“再次定义一个函数”，这叫嵌套函数
def foo():
    print('in the foo')
    def bar():
        print('in the bar')
    bar()

foo()